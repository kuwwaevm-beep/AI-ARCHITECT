# Run inside Autodesk 3ds Max Python environment (pymxs required).
# Imports AIARCH-BIM-1.0 architectural geometry as editable scene objects.
import json, math
from pymxs import runtime as rt

def point(x, y, z):
    # AIARCH XY plan -> Max X/Z; building elevation -> Max Y.
    return rt.Point3(float(x), float(z), float(y))

def import_project(path):
    with open(path, "r", encoding="utf-8") as f: data=json.load(f)
    model=data.get("architecturalModel") or data.get("bimModel") or data
    if model.get("schema") != "AIARCH-BIM-1.0": raise RuntimeError("Unsupported AIARCH model schema")
    created=[]
    for el in model.get("elements", []):
        g=el.get("geometry", {}); typ=g.get("type")
        name="AIARCH_"+str(el.get("id","element")).replace("-","_")
        if typ=="WallSegment":
            a,b=g["start"],g["end"]; dx,dz=b[0]-a[0],b[1]-a[1]
            length=math.hypot(dx,dz); thick=float(g.get("thicknessM",0.2)); height=float(g.get("heightM",3.0))
            obj=rt.Box(length=length,width=thick,height=height,name=name)
            obj.pos=point((a[0]+b[0])/2,(a[1]+b[1])/2,float(g.get("baseElevationM",0))+height/2)
            obj.rotation=rt.eulerAngles(0,0,math.degrees(math.atan2(dz,dx)))
            created.append(obj)
        elif typ=="ExtrudedPolygon":
            poly=g.get("polygon",[])
            if len(poly)<3: continue
            shp=rt.SplineShape(name=name+"_profile"); rt.addNewSpline(shp)
            for p in poly: rt.addKnot(shp,1,rt.Name("corner"),rt.Name("line"),point(p[0],p[1],float(g.get("elevationM",0))))
            rt.close(shp,1); ext=rt.Extrude(); ext.amount=float(g.get("thicknessM",g.get("depthM",0.2)))
            rt.addModifier(shp,ext); created.append(shp)
        elif typ=="RoofFootprint":
            pts=g.get("polygon",[])
            if len(pts)>=3:
                shp=rt.SplineShape(name=name+"_outline"); rt.addNewSpline(shp)
                for p in pts: rt.addKnot(shp,1,rt.Name("corner"),rt.Name("line"),point(p[0],p[1],float(g.get("elevationM",0))))
                rt.close(shp,1); created.append(shp)
        elif typ=="MeshSurface":
            vertices=g.get("vertices",[]); faces=g.get("faces",[])
            if not vertices or not faces: continue
            if any(not isinstance(v,list) or len(v)!=3 or not all(math.isfinite(float(c)) for c in v) for v in vertices):
                raise RuntimeError("{}: MeshSurface vertices XYZ noto'g'ri".format(name))
            if any(not isinstance(f,list) or len(f)!=3 or any(not isinstance(i,int) or i<0 or i>=len(vertices) for i in f) for f in faces):
                raise RuntimeError("{}: MeshSurface faces indekslari noto'g'ri".format(name))
            # AIARCH/Three.js XYZ (Y-up) -> 3ds Max X/Y/Z (Z-up).
            max_vertices=[point(v[0],v[2],v[1]) for v in vertices]
            max_faces=[rt.Point3(f[0]+1,f[1]+1,f[2]+1) for f in faces]
            obj=rt.mesh(vertices=max_vertices,faces=max_faces); obj.name=name
            created.append(obj)
    return created

path=rt.getOpenFileName(caption="AIARCH project.json tanlang",types="AIARCH JSON (*.json)|*.json|JSON (*.json)|*.json|")
if path:
    nodes=import_project(path)
    rt.messageBox("{} ta scene obyekt yaratildi. Material va detalizatsiya alohida sozlanadi.".format(len(nodes)),title="AIARCH Import")
