#!/usr/bin/env python3
"""Wrap native AIARCH project JSON in the cross-tool SI interchange contract."""
import json,sys
from pathlib import Path

def prepare(source,target):
    raw=json.loads(Path(source).read_text(encoding='utf-8'))
    model=raw.get('bimModel') or raw.get('architecturalModel') or (raw if raw.get('schema')=='AIARCH-BIM-1.0' else None)
    if not model or model.get('schema')!='AIARCH-BIM-1.0':
        raise ValueError('Native JSON ichida BIM Core snapshot yo\'q. Ilovani ochib, bino parametrlarini saqlang va qayta eksport qiling.')
    out={'schemaVersion':'1.0','units':{'length':'m','mass':'kg','force':'N','time':'s','acceleration':'m/s2'},'architecturalModel':model}
    if isinstance(raw.get('structuralModel'),dict): out['structuralModel']=raw['structuralModel']
    Path(target).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    return out
if __name__=='__main__':
    if len(sys.argv)!=3: raise SystemExit('Usage: prepare_project.py loyiha.aiarch.json project.json')
    result=prepare(sys.argv[1],sys.argv[2]); print('Prepared interchange project. Structural model:', 'present' if 'structuralModel' in result else 'MISSING (FEM disabled until engineer provides it)')
