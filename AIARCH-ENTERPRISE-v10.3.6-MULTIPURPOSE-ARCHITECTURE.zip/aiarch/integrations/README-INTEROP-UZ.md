# AIARCH — Autodesk / BIM / FEM interoperability (v10 foundation)

## Muhim holat
Bu papka AIARCH uchun haqiqiy fayl va API integratsiyasi asosini beradi. Bu AutoCAD,
3ds Max yoki Revit dasturlarining o'rnini bosuvchi klon emas. Autodesk dasturlari,
litsenziya va tegishli SDK/API versiyasi alohida o'rnatilishi kerak. Bu muhitda Autodesk
ilovalari yo'qligi sababli ularning ichidagi runtime sinovi bajarilmagan.

## Bitta ma'lumot manbai
`schemas/aiarch-project.schema.json` — almashinuv loyihasi shartnomasi.
`project.json` ichida `architecturalModel` (AIARCH BIM Core) va `structuralModel`
(muhandis kiritgan/tasdiqlagan analitik karkas) saqlanadi. Birliklar SI: koordinata m,
massa kg, kuch N, vaqt s, tezlanish m/s².

Arxitektura konturidan avtomatik ravishda ustun armaturasi yoki tasdiqlangan karkas
hosil qilinmaydi. Bunday parametrlar muhandis tomonidan alohida belgilanadi.

## Umumiy loyiha faylini tayyorlash
AIARCH ichida loyihani JSON qilib eksport qiling (`loyiha.aiarch.json`), keyin:
`python integrations/prepare_project.py loyiha.aiarch.json project.json`
Bu mavjud `bimModel` snapshot'ni umumiy SI birlikli almashinuv fayliga o'raydi. Agar BIM snapshot yo'q bo'lsa, skript xato qaytaradi.

## AutoCAD
1. `project.json` tayyorlang.
2. `python integrations/autocad/export_dxf.py project.json floor-plan.dxf` bajaring.
3. `floor-plan.dxf` ni AutoCAD'da `OPEN` qiling. DXF — tahrirlanadigan CAD almashinuv formati;
   DWG native format emas. DWG sifatida saqlash AutoCAD ichida bajariladi.
4. `AIARCH_IMPORT.lsp` ni `APPLOAD` bilan yuklang; `AIARCHOPEN` komandasi DXF tanlaydi.

DXF eksport hozir plan konturi, devor o'qlari, qatlamlar va birliklarni beradi. To'liq
AutoCAD .NET/ObjectARX parametrik vositalar to'plami hali yozilmagan.

## 3ds Max
3ds Max'da Scripting > Run Script orqali `integrations/3dsmax/import_aiarch.py` ni
ishga tushiring va `project.json` ni tanlang. Skript `pymxs` orqali sahna obyektlarini
quradi: devor segmentlari, extruded slab/foundation va roof footprint. Bu render
material kutubxonasi yoki 3ds Max'ning barcha modeling vositalari emas; material va
me'moriy detalizatsiya keyingi bosqichda sozlanadi. Autodesk 3ds Max Python API
(`pymxs`) talab qilinadi; oddiy Python'da ishlamaydi.

## Revit / IFC
Revit uchun tavsiya etilgan almashinuv — IFC. Revit IFC'ni open/link qila oladi.
AIARCH v9 IFC eksporti IFC4 STEP yozadi, ammo ayrim geometriya
`IfcBuildingElementProxy` sifatida chiqadi. Revit'da ochgach klassifikatsiya,
geometriya, property set va koordinatalarni tekshiring. Bu Revit native `.rvt` writer emas.

## Haqiqiy seysmik FEM
`seismic/run_opensees.py` OpenSeesPy transient time-history adapteridir. U faqat
`structuralModel` va accelerogramma CSV berilganda ishlaydi. Structural model ichida
tugunlar, elementlar, E/G/A/J/Iy/Iz, massalar va tayanchlar bo'lishi shart. CSV birinchi
ustuni vaqt (s), ikkinchisi tezlanish (m/s²). Skript PGA'ni ballga taxminiy aylantirmaydi,
x40 animatsiya koeffitsienti ishlatmaydi va ma'lumot yetishmasa hisobni rad etadi.

Natija tugunlar bo'yicha siljish vaqt qatorlarini JSON'da beradi. Natijani AIARCH 3D oynasida ko'rsatish uchun `bimMapping` ishlatiladi: `WallSegment` start/end tayanchlari yoki `MeshSurface` vertexlari analitik tugunlarga aniq bog'lanadi. Mesh sirt va qirralari deformatsiyalangan holda overlay sifatida ko'rsatiladi; avtomatik FEM mesh yaratish yoki parametrik binoning barcha elementlarini avtomatik deformatsiya qilish hali qo'llanmaydi. Natija muhandis
tekshiruvisiz qurilish qarori emas.

## Sinov
`python integrations/tests/test_interop.py
python integrations/tests/test_bim_results.py
python integrations/tests/test_opensees_adapter.py  # mocked contract only; real solver test requires OpenSeesPy`

OpenSeesPy uchun `python -m pip install -r integrations/seismic/requirements.txt`.

## Hali bajarilmagan
- DWG native writer yo'q (DXF eksport bor).
- AutoCAD .NET/ObjectARX add-in compile va AutoCAD runtime test yo'q.
- Revit native `.rvt` writer yo'q; IFC almashinuvi ishlatiladi.
- 3ds Max importer Autodesk runtime ichida sinovdan o'tmagan.
- Avtomatik BIM mesh yaratish, parametrik modelning barcha meshlarini FEM tugunlariga avtomatik bog‘lash va mapping UI yo‘q; `MeshSurface` uchun qo‘lda yoziladigan aniq mapping qo‘llanadi.
- Geologiya, material sinovlari, seysmik spektr va mahalliy SHNQ kombinatsiyalari
  bo'lmasa natija normativ muvofiq deb belgilanmaydi.

## Android va desktop rollari
Android Capacitor ilovasi mobil ko'rish, parametr kiritish, loyiha almashish va backend bilan ishlash uchun. U Android ichida to'liq AutoCAD, 3ds Max yoki Revit desktop authoring engine'larini ishga tushirmaydi. Professional native CAD/rendering ishlari Windows desktop'dagi litsenziyali Autodesk ilovasida bajariladi; Android shu loyiha ma'lumotini ko'radi va almashadi.

## Test fixture haqida
`examples/project.example.json` faqat parser va solver adapterining ma'lumot tuzilmasini ko'rsatadigan sun'iy fixture. Undagi material/kesim/massa qiymatlari real loyiha uchun tavsiya emas. Haqiqiy accelerogramma va tasdiqlangan strukturaviy modelni muhandis tayyorlashi kerak.


## AutoCAD chizma QA va ehtiyotkor tozalash (v10.1)
`autocad/AIARCH_QA_CLEAN.lsp` faylini `APPLOAD` bilan yuklang. `AIARCHQA` hisobot,
`AIARCHLAYERS` qatlam/lineweight andozasi, `AIARCHCLEAN` backup + AUDIT/PURGE,
`AIARCHJOIN` esa faqat ko'rsatilgan qatlamdagi LINE obyektlariga PEDIT JOIN bajaradi.
Qo'llanma: `autocad/AUTOCAD-QA-GUIDE-UZ.md`. Bu skript AutoCAD runtime'da hali sinovdan
o'tmagan; asl DWG nusxasida emas, backup nusxada sinang. Global weld/overkill ataylab yo'q.

## Seysmik loyihani ko'rib chiqish varaqasi
`seismic/STRUCTURAL_REVIEW_TEMPLATE_UZ.md` zarur geologiya, seysmik input, analitik
model, torsion/drift, armaturalash va BIM↔FEM mapping tekshiruvlarini yig'adi. Ustun
kesimi, xomut qadami yoki chok kengligini avtomatik tayinlamaydi; bular hisob va amaldagi
normativ bandlari bilan konstruktor tomonidan belgilanadi.


## OpenSees natijasini BIM geometriyasiga qo'llash (yangi)

`structuralModel.bimMapping` orqali tugunlarni BIM elementining aniq tayanch nuqtasiga bog'lang. Birinchi versiyada faqat `WallSegment` geometriyasining `start` va `end` nuqtalari qo'llanadi. Masalan:

```json
"bimMapping": [
  {"nodeId": 3, "elementId": "wall-1", "anchor": "start"},
  {"nodeId": 4, "elementId": "wall-1", "anchor": "end"}
]
```

Hisob tugagach, OpenSees natijasi va loyiha JSON faylidan deformatsiyalangan BIM nusxasini yarating:

```bash
python integrations/seismic/apply_bim_results.py project.json result.json deformed-bim.json --step -1 --scale 1
```

`--scale 1` haqiqiy fizik siljish masshtabidir; kattaroq qiymat faqat ko'rinish uchun deformatsiyani oshiradi. Asl model o'zgarmaydi. Natija `AIARCH-BIM-DEFORMED-1.0` formatida alohida JSON bo'ladi. Hozircha bu eksport AIARCH 3D oynasiga avtomatik ulanmagan; faqat aniq mapping kiritilgan nuqtalar ko'chiriladi. Bu vizualizatsiya muhandislik tasdig'i emas.
