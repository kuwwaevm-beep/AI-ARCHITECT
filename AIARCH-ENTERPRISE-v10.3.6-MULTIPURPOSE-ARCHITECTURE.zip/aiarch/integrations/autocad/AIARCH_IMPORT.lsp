;;; AIARCH helper. DXF geometry remains native/editable AutoCAD entities.
(defun c:AIARCHOPEN (/ f)
  (setq f (getfiled "AIARCH DXF faylini tanlang" "" "dxf" 0))
  (if f (command "_.OPEN" f))
  (princ))
(princ "\nAIARCH AutoCAD helper loaded. Command: AIARCHOPEN")
(princ)
