#!/usr/bin/env python3
"""Export AIARCH-BIM-1.0 plan geometry as editable ASCII DXF (R12-compatible)."""
import json, sys
from pathlib import Path

def pair(code, value): return f"{code}\n{value}\n"
def line(x1,y1,x2,y2,layer):
    return "0\nLINE\n"+pair(8,layer)+pair(10,f"{x1:.6f}")+pair(20,f"{y1:.6f}")+pair(30,"0")+pair(11,f"{x2:.6f}")+pair(21,f"{y2:.6f}")+pair(31,"0")
def poly(points, layer):
    # Classic POLYLINE/VERTEX sequence keeps the file compatible with AutoCAD R12.
    s="0\nPOLYLINE\n"+pair(8,layer)+pair(66,1)+pair(70,1)+pair(10,"0")+pair(20,"0")+pair(30,"0")
    for x,y in points:
        s += "0\nVERTEX\n"+pair(8,layer)+pair(10,f"{x:.6f}")+pair(20,f"{y:.6f}")+pair(30,"0")
    return s+"0\nSEQEND\n"+pair(8,layer)
def txt(x,y,value):
    value=str(value).replace("\n"," ")[:120]
    return "0\nTEXT\n"+pair(8,"AIARCH-TEXT")+pair(10,f"{x:.6f}")+pair(20,f"{y:.6f}")+pair(30,"0")+pair(40,"0.18")+pair(1,value)
def export(project, output):
    model=project.get("architecturalModel") or project.get("bimModel") or project
    if model.get("schema")!="AIARCH-BIM-1.0": raise ValueError("architecturalModel.schema AIARCH-BIM-1.0 bo'lishi kerak")
    b=model.get("building") or {}; footprint=b.get("footprint")
    if not isinstance(footprint,list) or len(footprint)<3: raise ValueError("building.footprint poligoni yo'q")
    entities=[poly(footprint,"AIARCH-FOOTPRINT")]
    for el in model.get("elements",[]):
        g=el.get("geometry") or {}; typ=g.get("type")
        if typ=="WallSegment":
            a,z=g.get("start"),g.get("end")
            if a and z: entities.append(line(a[0],a[1],z[0],z[1],"AIARCH-WALL-AXIS"))
        elif typ in ("Polygon","ExtrudedPolygon","RoofFootprint"):
            pts=g.get("coordinates") or g.get("polygon")
            if pts and len(pts)>=3: entities.append(poly(pts,"AIARCH-"+str(el.get("type","ELEMENT")).upper()))
    entities.append(txt(footprint[0][0],footprint[0][1],f"AIARCH | {b.get('floors','?')} qavat | units: m"))
    layers=["AIARCH-FOOTPRINT","AIARCH-WALL-AXIS","AIARCH-SLAB","AIARCH-FOUNDATION","AIARCH-ROOF","AIARCH-LAND","AIARCH-TEXT"]
    header="0\nSECTION\n2\nHEADER\n9\n$ACADVER\n1\nAC1009\n9\n$INSUNITS\n70\n6\n0\nENDSEC\n"
    tables="0\nSECTION\n2\nTABLES\n0\nTABLE\n2\nLAYER\n70\n"+str(len(layers))+"\n"
    for i,name in enumerate(layers): tables+="0\nLAYER\n"+pair(2,name)+pair(70,0)+pair(62,3 if i==0 else 7)+pair(6,"CONTINUOUS")
    tables+="0\nENDTAB\n0\nENDSEC\n"
    Path(output).write_text(header+tables+"0\nSECTION\n2\nENTITIES\n"+"".join(entities)+"0\nENDSEC\n0\nEOF\n",encoding="ascii")
if __name__=="__main__":
    if len(sys.argv)!=3: raise SystemExit("Usage: export_dxf.py project.json output.dxf")
    export(json.loads(Path(sys.argv[1]).read_text(encoding="utf-8")),sys.argv[2])
