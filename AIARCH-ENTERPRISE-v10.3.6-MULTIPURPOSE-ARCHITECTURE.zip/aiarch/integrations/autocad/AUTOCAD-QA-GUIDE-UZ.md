# AutoCAD QA/cleanup — ishga tushirish

1. DWG faylning alohida nusxasini yarating. LISP hech qachon yagona original ustida ishlatilmasin.
2. AutoCAD'da `APPLOAD` → `AIARCH_QA_CLEAN.lsp` ni yuklang.
3. `AIARCHQA` — qatlamlar va obyektlar soni bo'yicha matnli audit hisobotini chiqaradi.
4. `AIARCHLAYERS` — AIA/ISO-ga yaqin nomlash uslubidagi AIARCH qatlamlarini yaratadi yoki ularning lineweight qiymatini o'rnatadi. Mavjud obyektlarni qatlamlar orasida avtomatik ko'chirmaydi.
5. `AIARCHCLEAN` — backup nusxa yaratib, `AUDIT` va `-PURGE` ishga tushiradi. Global `OVERKILL` yoki barcha geometriyaga JOIN qilmaydi.
6. `AIARCHJOIN` — faqat foydalanuvchi ko'rsatgan qatlamdagi LINE obyektlarini tanlangan tolerance bilan `PEDIT JOIN` qiladi. Avval kichik nusxada sinang; natijada yopiq polilayn hosil bo'lganini tekshiring.

## Muhim texnik cheklovlar
- AutoCAD'da 3ds Max'dagi `Weld` modifikatori bilan bir xil universal `WELD` buyrug'i yo'q. CAD chiziqlarini birlashtirish uchun `PEDIT JOIN` ishlatiladi; vertexlarni birlashtirish esa topologiya va tolerance'ga bog'liq.
- Barcha devorlarni avtomatik yopiq polilaynga aylantirish xavfli: eshik/deraza teshiklari, kesishmalar va ustma-ust chiziqlar noto'g'ri birikishi mumkin.
- Qatlam nomi va lineweight standartlari loyiha BEP/CAD standardiga moslashtirilishi kerak. AIARCH qatlamlari mavjud elementlarning semantikasini o'zi aniqlamaydi.
- Annotative text/dimension, viewport scale, CTB/STB, xref, font va koordinata origin tekshiruvi chizma hamda plot preview orqali qo'lda tasdiqlanadi.
- LISP fayli bu muhitda AutoCAD ichida bajarilmadi; real AutoCAD runtime testi talab etiladi.
