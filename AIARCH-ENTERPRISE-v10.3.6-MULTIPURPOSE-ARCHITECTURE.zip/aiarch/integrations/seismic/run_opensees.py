#!/usr/bin/env python3
"""OpenSeesPy 3D transient time-history adapter. SI units only; no synthetic PGA scaling."""
import csv, json, math, sys
from pathlib import Path

REQUIRED = ("E_Pa", "G_Pa", "A_m2", "J_m4", "Iy_m4", "Iz_m4")

def validate(project):
    if not isinstance(project, dict) or project.get("schemaVersion") != "1.0":
        raise ValueError("schemaVersion 1.0 bo'lishi kerak")
    units=project.get("units", {})
    expected={"length":"m","mass":"kg","force":"N","time":"s","acceleration":"m/s2"}
    if not isinstance(units, dict) or any(units.get(k)!=v for k,v in expected.items()):
        raise ValueError("Faqat SI birliklari qabul qilinadi: m, kg, N, s, m/s2")
    sm=project.get("structuralModel")
    if not isinstance(sm,dict): raise ValueError("structuralModel yo'q: arxitektura konturi FEM karkas o'rnini bosa olmaydi")
    if sm.get("ndm",3)!=3 or sm.get("ndf",6)!=6: raise ValueError("Faqat 3D frame modeli (ndm=3, ndf=6) qo'llanadi")
    nodes=sm.get("nodes",[]); members=sm.get("members",[])
    if not isinstance(nodes,list) or len(nodes)<4 or not isinstance(members,list) or not members:
        raise ValueError("Kamida 4 tugun va 1 element kerak")
    ids=set(); xyz_by_id={}; supports=[]; total_mass=0.0
    for n in nodes:
        if not isinstance(n,dict) or not isinstance(n.get("id"),int) or isinstance(n.get("id"),bool) or n["id"] in ids:
            raise ValueError("Node ID integer va takrorlanmas bo'lishi kerak")
        ids.add(n["id"])
        xyz=n.get("xyz")
        if not isinstance(xyz,list) or len(xyz)!=3: raise ValueError("Node xyz 3 ta koordinatadan iborat bo'lishi kerak")
        coords=tuple(float(v) for v in xyz)
        if not all(math.isfinite(v) for v in coords): raise ValueError("Node xyz NaN/Inf bo'lmasligi kerak")
        xyz_by_id[n["id"]]=coords
        m=float(n.get("massKg",-1))
        if not math.isfinite(m) or m<0: raise ValueError("massKg manfiy yoki noto'g'ri")
        total_mass += m
        fix=n.get("fixity",[0,0,0,0,0,0])
        if not isinstance(fix,list) or len(fix)!=6 or any(v not in (0,1) for v in fix):
            raise ValueError("fixity 6 ta 0/1 qiymatdan iborat bo'lishi kerak")
        if all(v == 1 for v in fix): supports.append(n["id"])
    if not supports: raise ValueError("Kamida bitta to'liq mahkamlangan tayanch (6 DOF) kerak")
    if total_mass<=0: raise ValueError("Umumiy massa nol: massalarni kiriting")

    member_ids=set(); adjacency={node_id:set() for node_id in ids}
    for e in members:
        if not isinstance(e,dict) or e.get("type")!="elasticBeamColumn":
            raise ValueError("Hozircha faqat elasticBeamColumn elementi qo'llanadi")
        member_id=e.get("id")
        if member_id is None or isinstance(member_id,(dict,list)) or str(member_id).strip()=="":
            raise ValueError("Member ID bo'sh bo'lmasligi kerak")
        if str(member_id) in member_ids: raise ValueError("Member ID takrorlangan")
        member_ids.add(str(member_id))
        i,j=e.get("iNode"),e.get("jNode")
        if i not in ids or j not in ids or i==j: raise ValueError("Element tugunlari mavjud emas yoki bir xil")
        axis=tuple(xyz_by_id[j][k]-xyz_by_id[i][k] for k in range(3))
        axis_len=math.sqrt(sum(v*v for v in axis))
        if axis_len < 1e-9: raise ValueError("Element uzunligi nol bo'lmasligi kerak: {}".format(member_id))
        adjacency[i].add(j); adjacency[j].add(i)
        for k in REQUIRED:
            try: v=float(e.get(k,0))
            except (TypeError,ValueError): raise ValueError("{} son bo'lishi kerak: {}".format(k,member_id))
            if not math.isfinite(v) or v<=0: raise ValueError("{} musbat bo'lishi kerak: {}".format(k,member_id))
        vec=e.get("vecxz")
        if not isinstance(vec,list) or len(vec)!=3: raise ValueError("vecxz 3 ta qiymatdan iborat bo'lishi kerak")
        vec=tuple(float(x) for x in vec)
        if not all(math.isfinite(x) for x in vec): raise ValueError("vecxz NaN/Inf bo'lmasligi kerak")
        vec_len=math.sqrt(sum(x*x for x in vec))
        cross=(axis[1]*vec[2]-axis[2]*vec[1], axis[2]*vec[0]-axis[0]*vec[2], axis[0]*vec[1]-axis[1]*vec[0])
        cross_len=math.sqrt(sum(x*x for x in cross))
        if vec_len < 1e-9 or cross_len/(axis_len*vec_len) < 1e-8:
            raise ValueError("vecxz element o'qiga parallel bo'lmasligi kerak: {}".format(member_id))

    # All structural nodes must belong to the supported connected frame.
    reached=set(supports); stack=list(supports)
    while stack:
        current=stack.pop()
        for neighbor in adjacency[current]:
            if neighbor not in reached: reached.add(neighbor); stack.append(neighbor)
    if reached != ids:
        raise ValueError("Barcha tugunlar mahkamlangan karkas bilan bog'langan bo'lishi kerak")
    return sm

def read_motion(path):
    rows=[]
    with open(path,newline="",encoding="utf-8-sig") as f:
        for row in csv.reader(f):
            if not row or row[0].strip().startswith("#"): continue
            try: t,a=float(row[0]),float(row[1])
            except (ValueError,IndexError): continue  # optional header
            if not math.isfinite(t) or not math.isfinite(a): raise ValueError("Accelerogrammada NaN/Inf bor")
            rows.append((t,a))
    if len(rows)<3: raise ValueError("Kamida 3 ta (time_s, acceleration_m_s2) namuna kerak")
    dts=[rows[i+1][0]-rows[i][0] for i in range(len(rows)-1)]
    if any(x<=0 for x in dts): raise ValueError("Vaqt qatorlari qat'iy o'sib borishi kerak")
    dt=sum(dts)/len(dts)
    if max(abs(x-dt) for x in dts)>max(1e-7,dt*1e-3): raise ValueError("OpenSees Path uchun accelerogramma bir xil dt oralig'ida bo'lishi kerak")
    if abs(rows[0][0])>1e-8: raise ValueError("Accelerogramma vaqti 0 sekunddan boshlanishi kerak")
    return dt,[r[1] for r in rows]

def run(project_path,motion_path,out_path,direction=1):
    project=json.loads(Path(project_path).read_text(encoding="utf-8")); sm=validate(project)
    dt,accel=read_motion(motion_path)
    if direction not in (1,2,3): raise ValueError("direction 1, 2 yoki 3 bo'lishi kerak")
    try: import openseespy.opensees as ops
    except ImportError as exc: raise RuntimeError("OpenSeesPy o'rnatilmagan. pip install -r integrations/seismic/requirements.txt") from exc
    result=None
    try:
        ops.wipe(); ops.model("basic","-ndm",3,"-ndf",6)
        for n in sm["nodes"]:
            ops.node(n["id"],*map(float,n["xyz"]))
            m=float(n.get("massKg",0)); ops.mass(n["id"],m,m,m,0,0,0)
            ops.fix(n["id"],*n.get("fixity",[0,0,0,0,0,0]))
        for idx,e in enumerate(sm["members"],start=1):
            ops.geomTransf("Linear",idx,*map(float,e["vecxz"]))
            ops.element("elasticBeamColumn",idx,e["iNode"],e["jNode"],float(e["A_m2"]),float(e["E_Pa"]),float(e["G_Pa"]),float(e["J_m4"]),float(e["Iy_m4"]),float(e["Iz_m4"]),idx)
        ops.timeSeries("Path",1,"-dt",dt,"-values",*accel)
        ops.pattern("UniformExcitation",1,direction,"-accel",1)
        ops.constraints("Plain"); ops.numberer("RCM"); ops.system("BandGeneral")
        ops.test("NormDispIncr",1e-9,30); ops.algorithm("Newton"); ops.integrator("Newmark",0.5,0.25); ops.analysis("Transient")
        histories={str(n["id"]):[] for n in sm["nodes"]}; times=[]
        for step in range(len(accel)):
            ok=ops.analyze(1,dt)
            if ok!=0: raise RuntimeError("OpenSees transient analysis convergence failed at step {} (t={:.6f}s)".format(step,step*dt))
            times.append((step+1)*dt)
            for n in sm["nodes"]:
                values=list(ops.nodeDisp(n["id"]))
                if len(values)<6 or not all(math.isfinite(float(v)) for v in values):
                    raise RuntimeError("OpenSees nodeDisp noto'g'ri yoki NaN/Inf: node {}".format(n["id"]))
                histories[str(n["id"])].append([float(v) for v in values[:6]])
        max_trans=max((math.sqrt(sum(v[i]**2 for i in range(3))) for hist in histories.values() for v in hist),default=0)
        result={"engine":"OpenSeesPy","analysis":"3D transient time-history","units":{"displacement":"m","time":"s","input_acceleration":"m/s2"},"direction":direction,"dt_s":dt,"steps":len(times),"max_translation_m":max_trans,"times_s":times,"node_displacements_m_rad":histories,"status":"analysis-completed-needs-engineer-review","source_motion":str(motion_path)}
    finally:
        try: ops.wipe()
        except Exception: pass
    Path(out_path).write_text(json.dumps(result,indent=2),encoding="utf-8")
    return result

if __name__=="__main__":
    if len(sys.argv) not in (4,5): raise SystemExit("Usage: run_opensees.py project.json accelerogram.csv result.json [direction:1|2|3]")
    result=run(sys.argv[1],sys.argv[2],sys.argv[3],int(sys.argv[4]) if len(sys.argv)==5 else 1)
    print("OpenSeesPy completed: {} steps, max translation {:.6g} m".format(result["steps"],result["max_translation_m"]))
