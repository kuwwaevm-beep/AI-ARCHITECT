# AIARCH BIM deformatsiyasini 3D oynada ko‘rish

1. AIARCH loyihasi uchun mos `project.json` va konstruktiv modeldagi `structuralModel.bimMapping` ni tayyorlang. Har bir mapping `nodeId`, `elementId`, `anchor` (`start` yoki `end`) bilan aniq ko‘rsatilishi shart.
2. OpenSeesPy natijasini `node_displacements_m_rad` formatida oling.
3. Deformatsiya JSON faylini yarating:

```bash
python integrations/seismic/apply_bim_results.py project.json opensees-results.json deformed-bim.json --step -1 --scale 10
```

4. Asosiy AIARCH ilovasini oching, 3D oynadagi **FEM natijasini yuklash** tugmasini bosing va `deformed-bim.json` ni tanlang.
5. Qizil chiziqlar — aniq mapping qilingan devor segmentlari; moviy chiziqlar — boshlang‘ich nuqtadan siljigan tayanch nuqtaga vektorlar. **Tozalash** overlayni olib tashlaydi.

Koordinata tizimi: OpenSees XYZ → AIARCH X/Y/Z; AIARCH plan koordinatalari X/Z, vertikal koordinata Y. `--scale` faqat ko‘rgazmali masshtab; haqiqiy siljishlar JSON ichida `displacementM` da saqlanadi.

**Mesh deformatsiyasi:** foydalanuvchi `MeshSurface` elementining har bir kerakli vertexini `vertexIndex` orqali OpenSees tuguniga aniq bog‘lashi mumkin. Vertexlar XYZ koordinatalarida, yuzalar esa uchburchak indekslari bilan beriladi; 3D oynada deformatsiyalangan sirt va qirralar ko‘rsatiladi. Bog‘lanmagan vertexlar o‘zgarmaydi. `WallSegment` start/end overlay ham saqlanadi. Bu avtomatik FEM mesh yaratish yoki mavjud parametrik bino geometriyasini o‘z-o‘zidan meshga aylantirish degani emas. Hisob natijasi konstruktiv xavfsizlik xulosasi yoki loyiha tasdig‘i emas.
