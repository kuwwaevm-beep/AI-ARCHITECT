# AIARCH — seysmik konstruktiv tekshiruv varaqasi

**Maqsad:** muhandis tomonidan tasdiqlanishi kerak bo'lgan kirish ma'lumotlari va tekshiruvlarni tizimlashtirish. Bu tayyor loyiha, hisob yoki KMK/ShNK muvofiqlik xulosasi emas.

## 1. Loyiha va normativ asos
- [ ] Bino manzili, koordinata va mas'ul muhandis qayd etildi.
- [ ] Amaldagi normativ hujjatlarning rasmiy nashri, tahriri va tegishli bandlari tekshirildi.
- [ ] Seysmik rayonlashtirish/hazard parametrlari rasmiy manbadan olindi (ballning o'zi yetarli emas).
- [ ] Mas'ul konstruktor loyiha uchun qabul qilingan hisob usulini tasdiqladi.

## 2. Geologiya va poydevor
- [ ] Muhandislik-geologik hisobot va grunt qatlamlari mavjud.
- [ ] Gruntning hisobiy qarshiligi, deformatsiya modullari, yerosti suvi va suyulish xavfi baholandi.
- [ ] Poydevor turi, qattiqligi, bog'lovchi to'sinlar va grunt–konstruksiya o'zaro ta'siri asoslandi.

## 3. Analitik model uchun majburiy ma'lumotlar
- [ ] 3D tugun koordinatalari va element connectivity.
- [ ] Ustun, rigel, diafragma va plita kesimlari; material E, G, zichlik, mustahkamlik.
- [ ] Elementlarning A, Iy, Iz, J parametrlari yoki hisobiy kesim xususiyatlari.
- [ ] Tugun birikmalari, rigid-zone/offset va diafragma cheklovlari.
- [ ] Tayanch shartlari, poydevor qattiqligi va zarur bo'lsa grunt prujinalari.
- [ ] Doimiy, foydali, tom, fasad va muhandislik jihozlari yuklari; mass source.
- [ ] Seysmik ta'sirning ikki gorizontal yo'nalishi, zarur bo'lsa vertikal komponent.
- [ ] Vaqt yozuvi (accelerogramma), dt, birlik, stansiya, komponent, baseline correction va scaling hujjati.

## 4. Global seysmik xulq
- [ ] Modal tahlil: davrlar, modalar, ishtirok etuvchi massa ulushi.
- [ ] Tasodifiy/haqiqiy ekssentrisitet va torsion sezgirligi tekshirildi.
- [ ] Qavatlararo siljishlar (drift) va umumiy siljishlar tekshirildi.
- [ ] P–Delta / ikkilamchi tartib effektlari baholandi.
- [ ] Yumshoq/qattiq qavat, zaif qavat, reja va balandlik bo'yicha notekisliklar ko'rildi.
- [ ] Diafragma uzluksizligi, kollektorlar va shear-wall joylashuvi tekshirildi.
- [ ] Deformatsiya choklari har bir blok uchun hisobiy nisbiy siljish va normativ talab bilan asoslandi.

## 5. Temir-beton detallash
- [ ] Ustun–rigel tugunlari va kuch uzatish mexanizmi tekshirildi.
- [ ] Chekka (plastik sharnir) zonalaridagi ko'ndalang armatura qadami hisob bilan belgilandi.
- [ ] Ustun bo'ylama armaturasi, splice/lap joylari va confinement tekshirildi.
- [ ] Rigel kesimi, kesuvchi kuch, ankraj va tugun ichidagi armatura tiqilinchligi tekshirildi.
- [ ] Ustunlarning kuchli/zaif yo'nalishi va strong-column/weak-beam talabi tegishli normativga muvofiq baholandi.
- [ ] Diafragma devorlari, chegara elementlari va coupling-beam detallari tekshirildi.

## 6. AIARCH BIM ↔ FEM bog'lanishi
- [ ] Har bir analitik elementga BIM element GUID/ID biriktirilgan.
- [ ] Analitik tugunlar BIM geometriyasiga koordinata transformatsiyasi bilan bog'langan.
- [ ] Birliklar m–kg–N–s va global/local o'qlar tekshirildi.
- [ ] FEM natijalarining tugun siljishi mos BIM vertex/meshga to'g'ri interpolatsiya qilinadi.
- [ ] Deformatsiya ko'rsatish masshtabi alohida ko'rsatiladi; hisobiy natija va vizual kuchaytirish farqlanadi.
- [ ] Natija muhandis tomonidan tekshirilib, model versiyasi va solver log saqlandi.

## 7. Qarorlar
| Tekshiruv | Natija | Dalil/fayl | Muhandis izohi |
|---|---|---|---|
| Modal/torsion | Kutilmoqda | | |
| Drift | Kutilmoqda | | |
| Ustun/tugun detal | Kutilmoqda | | |
| Chok | Kutilmoqda | | |
| Diafragma | Kutilmoqda | | |
| Poydevor/grunt | Kutilmoqda | | |

**Muhim:** 400×400 yoki 500×500 mm ustun, 100 mm xomut qadami yoki 50–100 mm chok universal tayinlov emas. Ular faqat loyiha hisoblari, materiallar, bino balandligi, grunt, seysmik parametrlar va amaldagi normativ bandlari bilan aniqlanadi.
