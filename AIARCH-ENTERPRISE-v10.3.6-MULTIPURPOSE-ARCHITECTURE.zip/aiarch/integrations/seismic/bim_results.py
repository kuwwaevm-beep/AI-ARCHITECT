#!/usr/bin/env python3
"""Apply explicitly mapped OpenSees nodal displacements to AIARCH BIM geometry.

Supports explicitly mapped WallSegment endpoints and MeshSurface vertices. Mapping is
user-authored; no automatic inference from architectural geometry is performed.
"""
from copy import deepcopy
import math


def _finite_number(value, label):
    try:
        number = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{label} son bo'lishi kerak")
    if not math.isfinite(number):
        raise ValueError(f"{label} NaN/Inf bo'lmasligi kerak")
    return number


def apply_displacements(project, results, step=-1, scale=1.0):
    if not isinstance(project, dict) or project.get("schemaVersion") != "1.0":
        raise ValueError("AIARCH project schemaVersion 1.0 bo'lishi kerak")
    arch = project.get("architecturalModel")
    structural = project.get("structuralModel")
    if not isinstance(arch, dict) or not isinstance(arch.get("elements"), list):
        raise ValueError("architecturalModel.elements topilmadi")
    if not isinstance(structural, dict):
        raise ValueError("structuralModel topilmadi")
    if not isinstance(results, dict) or results.get("engine") != "OpenSeesPy":
        raise ValueError("Natija OpenSeesPy formatida emas")
    histories = results.get("node_displacements_m_rad")
    if not isinstance(histories, dict) or not histories:
        raise ValueError("node_displacements_m_rad bo'sh yoki noto'g'ri")
    scale = _finite_number(scale, "scale")
    if scale <= 0 or scale > 10000:
        raise ValueError("Vizual masshtab 0 dan katta va 10000 dan kichik bo'lishi kerak")

    nodes = structural.get("nodes", [])
    if not isinstance(nodes, list) or not nodes:
        raise ValueError("structuralModel.nodes bo'sh yoki noto'g'ri")
    node_ids = {str(n.get("id")) for n in nodes if isinstance(n, dict) and n.get("id") is not None}
    mapping = structural.get("bimMapping")
    if not isinstance(mapping, list) or not mapping:
        raise ValueError("structuralModel.bimMapping kerak: tugunlarni BIM tayanch nuqtalariga aniq bog'lang")

    frames = {k: v for k, v in histories.items() if isinstance(v, list) and v}
    if not frames:
        raise ValueError("OpenSees displacement history mavjud emas")
    lengths = {len(v) for v in frames.values()}
    if len(lengths) != 1:
        raise ValueError("Node displacement history uzunliklari mos emas")
    count = lengths.pop()
    idx = step if step >= 0 else count + step
    if idx < 0 or idx >= count:
        raise IndexError(f"step 0..{count-1} oralig'ida bo'lishi kerak")

    elements = {str(e.get("id")): e for e in arch["elements"]}
    deformed = deepcopy(arch)
    deformed_elements = {str(e.get("id")): e for e in deformed["elements"]}
    seen = set()
    seen_anchors = set()
    seen_vertices = set()
    applied = []
    for item in mapping:
        if not isinstance(item, dict):
            raise ValueError("bimMapping elementi object bo'lishi kerak")
        node_id = str(item.get("nodeId"))
        element_id = str(item.get("elementId"))
        anchor = item.get("anchor")
        vertex_index = item.get("vertexIndex")
        key = (node_id, element_id, anchor, vertex_index)
        if key in seen:
            raise ValueError(f"Takroriy BIM mapping: {key}")
        seen.add(key)
        if node_id not in node_ids or node_id not in frames:
            raise ValueError(f"Node {node_id} structural model yoki natijada yo'q")
        if element_id not in elements:
            raise ValueError(f"BIM element {element_id} topilmadi")
        original = elements[element_id]
        target = deformed_elements[element_id]
        geom = original.get("geometry", {})
        disp = frames[node_id][idx]
        if not isinstance(disp, list) or len(disp) < 3:
            raise ValueError(f"Node {node_id} displacement kamida 3 DOF bo'lishi kerak")
        dx, dy, dz = (_finite_number(disp[i], f"node {node_id} disp[{i}]") for i in range(3))
        if geom.get("type") == "WallSegment" and anchor in ("start", "end") and vertex_index is None:
            anchor_key = (element_id, anchor)
            if anchor_key in seen_anchors:
                raise ValueError(f"BIM tayanch nuqtasi bir nechta tugunga bog'langan: {anchor_key}")
            seen_anchors.add(anchor_key)
            point = geom.get(anchor)
            if not isinstance(point, list) or len(point) != 2:
                raise ValueError(f"{element_id}.{anchor} 2D nuqta bo'lishi kerak")
            target["geometry"][anchor] = [point[0] + dx * scale, point[1] + dz * scale]
            target.setdefault("analysisDisplacements", {})[anchor] = {
                "dxM": dx, "dyM": dy, "dzM": dz,
                "visualScale": scale, "verticalOffsetM": dy * scale
            }
            applied.append({"nodeId": int(node_id), "elementId": element_id, "anchor": anchor,
                            "displacementM": [dx, dy, dz],
                            "visualDisplacementM": [dx * scale, dy * scale, dz * scale]})
        elif geom.get("type") == "MeshSurface" and anchor is None and isinstance(vertex_index, int) and not isinstance(vertex_index, bool):
            vertices = geom.get("vertices")
            faces = geom.get("faces")
            if not isinstance(vertices, list) or not vertices or not isinstance(faces, list) or not faces:
                raise ValueError(f"{element_id} MeshSurface vertices/faces bo'sh yoki noto'g'ri")
            if any(not isinstance(v, list) or len(v) != 3 for v in vertices):
                raise ValueError(f"{element_id} MeshSurface vertex XYZ uchlik bo'lishi kerak")
            for vi, v in enumerate(vertices):
                for axis, value in enumerate(v): _finite_number(value, f"{element_id}.vertices[{vi}][{axis}]")
            for fi, face in enumerate(faces):
                if not isinstance(face, list) or len(face) != 3 or any(not isinstance(k, int) or isinstance(k, bool) or k < 0 or k >= len(vertices) for k in face):
                    raise ValueError(f"{element_id}.faces[{fi}] uchta yaroqli vertex indeksidan iborat bo'lishi kerak")
            if vertex_index < 0 or vertex_index >= len(vertices):
                raise ValueError(f"{element_id} vertexIndex diapazondan tashqarida")
            vertex_key = (element_id, vertex_index)
            if vertex_key in seen_vertices:
                raise ValueError(f"Mesh vertex bir nechta tugunga bog'langan: {vertex_key}")
            seen_vertices.add(vertex_key)
            point = vertices[vertex_index]
            target["geometry"]["vertices"][vertex_index] = [point[0] + dx * scale, point[1] + dy * scale, point[2] + dz * scale]
            target.setdefault("analysisDisplacementsByVertex", {})[str(vertex_index)] = {
                "displacementM": [dx, dy, dz], "visualScale": scale
            }
            applied.append({"nodeId": int(node_id), "elementId": element_id, "vertexIndex": vertex_index,
                            "displacementM": [dx, dy, dz],
                            "visualDisplacementM": [dx * scale, dy * scale, dz * scale]})
        else:
            raise ValueError("Mapping WallSegment start/end yoki MeshSurface vertexIndex bo'lishi kerak")

    if not applied:
        raise ValueError("Hech qanday BIM nuqtasiga siljish qo'llanmadi")
    times = results.get("times_s")
    if times is not None:
        if not isinstance(times, list) or len(times) != count:
            raise ValueError("times_s uzunligi displacement history bilan mos emas")
        time_value = _finite_number(times[idx], "times_s")
    else:
        time_value = None

    return {
        "schema": "AIARCH-BIM-DEFORMED-1.0",
        "sourceSchema": arch.get("schema"),
        "analysisEngine": "OpenSeesPy",
        "analysisStatus": results.get("status", "unknown"),
        "stepIndex": idx,
        "timeS": time_value,
        "visualScale": scale,
        "isVisualizationOnly": True,
        "deformedArchitecturalModel": deformed,
        "mappingApplied": applied,
        "warnings": [
            "Bu vizualizatsiya; konstruktiv loyihani tasdiqlash yoki xavfsizlik xulosasi emas.",
            "Faqat foydalanuvchi aniq bog'lagan WallSegment tayanchlari va MeshSurface vertexlari siljitildi.",
            "OpenSees XYZ koordinatalari AIARCH X/Y/Z ga o'tkazildi; BIM plan koordinatalari X/Z, vertikal siljish Y sifatida saqlandi.",
            "VizualScale fizik siljishni kattalashtirishi mumkin; haqiqiy siljishlar displacementM maydonida saqlangan."
        ]
    }
