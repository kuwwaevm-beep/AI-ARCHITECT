#!/usr/bin/env python3
"""CLI: apply OpenSees result JSON to explicitly mapped AIARCH BIM anchors."""
import argparse, json
from pathlib import Path
from bim_results import apply_displacements

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('project_json')
p.add_argument('results_json')
p.add_argument('output_json')
p.add_argument('--step', type=int, default=-1, help='0-based result step; default is last')
p.add_argument('--scale', type=float, default=1.0, help='visual displacement scale (1 = true scale)')
a = p.parse_args()
project = json.loads(Path(a.project_json).read_text(encoding='utf-8'))
results = json.loads(Path(a.results_json).read_text(encoding='utf-8'))
out = apply_displacements(project, results, a.step, a.scale)
Path(a.output_json).write_text(json.dumps(out, indent=2), encoding='utf-8')
print(f"BIM deformation visualization exported: {len(out['mappingApplied'])} mapped anchors, step {out['stepIndex']}")
