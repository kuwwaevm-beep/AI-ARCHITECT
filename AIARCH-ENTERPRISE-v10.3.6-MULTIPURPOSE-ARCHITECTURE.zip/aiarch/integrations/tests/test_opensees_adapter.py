"""Mocked adapter contract test; does NOT replace a real OpenSeesPy solver run."""
import csv, json, pathlib, sys, tempfile, types
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'integrations'/'seismic'))
import run_opensees
project=json.loads((ROOT/'integrations'/'examples'/'project.example.json').read_text())
class FakeOps(types.ModuleType):
    def __init__(self): super().__init__('openseespy.opensees'); self.calls=[]; self.nodes=[]; self.step=0
    def __getattr__(self,name):
        def fn(*args):
            self.calls.append((name,args))
            if name=='node': self.nodes.append(args[0])
            if name=='analyze': self.step+=1; return 0
            if name=='nodeDisp': return [self.step*0.001,0.0,0.0,0.0,0.0,0.0]
        return fn
fake=FakeOps(); pkg=types.ModuleType('openseespy'); pkg.opensees=fake
sys.modules['openseespy']=pkg; sys.modules['openseespy.opensees']=fake
with tempfile.TemporaryDirectory() as td:
    td=pathlib.Path(td); p=td/'project.json'; p.write_text(json.dumps(project))
    m=td/'motion.csv'; m.write_text('time_s,acceleration_m_s2\n0,0\n0.01,0.1\n0.02,-0.1\n')
    out=td/'result.json'
    result=run_opensees.run(p,m,out,1)
    assert result['steps']==3 and result['engine']=='OpenSeesPy'
    assert result['node_displacements_m_rad']['3'][-1][0]==0.003
    assert out.exists() and json.loads(out.read_text())['direction']==1
    assert any(c[0]=='element' for c in fake.calls) and any(c[0]=='analyze' for c in fake.calls)
print('OpenSees adapter mocked contract: PASS (model setup, transient loop, displacement collection, JSON output)')
print('NOTE: Real OpenSeesPy numerical solve remains unverified; this test uses a mock engine.')
# Reject structurally invalid frame definitions before calling the solver.
import copy
for mutate, expected in [
    (lambda p: p['structuralModel']['members'][0].update({'vecxz':[0,1,0]}), 'parallel'),
    (lambda p: p['structuralModel']['members'][0].update({'jNode':1}), 'bir xil'),
    (lambda p: p['structuralModel']['nodes'][0].update({'fixity':[1,1]}), 'fixity'),
]:
    bad=copy.deepcopy(project); mutate(bad)
    try: run_opensees.validate(bad)
    except ValueError as exc: assert expected in str(exc), str(exc)
    else: raise AssertionError('invalid structural model was accepted: '+expected)
print('OpenSees model validation: PASS (parallel local axes, zero-length member, malformed fixity rejected)')
