import json, pathlib, sys, tempfile
HERE=pathlib.Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path.insert(0,str(ROOT/'integrations'/'seismic'))
sys.path.insert(0,str(ROOT/'integrations'/'autocad'))
sys.path.insert(0,str(ROOT/'integrations'))
from run_opensees import validate, read_motion
from export_dxf import export
from prepare_project import prepare

p=json.loads((ROOT/'integrations'/'examples'/'project.example.json').read_text())
json.loads((ROOT/'integrations'/'schemas'/'aiarch-project.schema.json').read_text())
# AutoCAD LISP is statically inspected here; Autodesk runtime is not available.
lsp=(ROOT/'integrations'/'autocad'/'AIARCH_QA_CLEAN.lsp').read_text()
for command_name in ['AIARCHLAYERS','AIARCHQA','AIARCHCLEAN','AIARCHJOIN']:
    assert '(defun c:'+command_name in lsp
assert '_.AUDIT' in lsp and '_.-PURGE' in lsp and '_.PEDIT' in lsp
assert '_.WELD' not in lsp.upper()
# Balanced AutoLISP parentheses, ignoring comments and quoted strings.
depth = 0
in_string = False
escaped = False
for line in lsp.splitlines():
    if not in_string and line.lstrip().startswith(';'):
        continue
    for ch in line:
        if in_string:
            if escaped:
                escaped = False
            elif ch == '\\':
                escaped = True
            elif ch == '"':
                in_string = False
        else:
            if ch == ';':
                break
            elif ch == '"':
                in_string = True
            elif ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                assert depth >= 0, 'AutoLISP extra closing parenthesis'
assert depth == 0 and not in_string, 'AutoLISP parentheses/string not balanced'

assert (ROOT/'integrations'/'seismic'/'STRUCTURAL_REVIEW_TEMPLATE_UZ.md').exists()
max_script=(ROOT/'integrations'/'3dsmax'/'import_aiarch.py').read_text()
compile(max_script, 'import_aiarch.py', 'exec')
assert 'elif typ=="MeshSurface"' in max_script and 'rt.mesh(vertices=max_vertices,faces=max_faces)' in max_script
# IFC4 exporter remains present in the browser application; this is a static check, not a Revit runtime test.
client=(ROOT/'client'/'index.html').read_text()
assert 'function downloadIFC()' in client and "FILE_SCHEMA(('IFC4'))" in client
assert 'IFCTRIANGULATEDFACESET' in client and 'IFCBUILDINGELEMENTPROXY' in client
assert validate(p)['ndm']==3
with tempfile.TemporaryDirectory() as td:
    native=pathlib.Path(td)/'native.json'; native.write_text(json.dumps({'bimModel':p['architecturalModel']}))
    prepared=pathlib.Path(td)/'project.json'; wrapped=prepare(native,prepared)
    assert wrapped['architecturalModel']['schema']=='AIARCH-BIM-1.0' and 'structuralModel' not in wrapped
    out=pathlib.Path(td)/'sample.dxf'
    export(p,out)
    raw=out.read_text()
    assert raw.startswith('0\nSECTION\n2\nHEADER') and 'AIARCH-WALL-AXIS' in raw and 'POLYLINE' in raw
    assert raw.rstrip().endswith('0\nEOF')
    try:
        import ezdxf
        doc=ezdxf.readfile(out); assert len(doc.modelspace()) >= 3
    except ImportError:
        pass
try:
    validate({"schemaVersion":"1.0","units":p['units'],"architecturalModel":p['architecturalModel']})
except ValueError as e:
    assert 'structuralModel' in str(e)
else: raise AssertionError('FEM adapter must reject architecture-only model')
with tempfile.TemporaryDirectory() as td:
    motion=pathlib.Path(td)/'motion.csv'
    motion.write_text('time_s,acceleration_m_s2\n0,0\n0.01,0.1\n0.02,-0.1\n')
    dt,values=read_motion(motion)
    assert abs(dt-0.01)<1e-10 and len(values)==3
print('interop tests: PASS (native-project bridge, DXF export, AutoCAD LISP static checks, seismic checklist, SI/FEM input validation, accelerogram parser)')
