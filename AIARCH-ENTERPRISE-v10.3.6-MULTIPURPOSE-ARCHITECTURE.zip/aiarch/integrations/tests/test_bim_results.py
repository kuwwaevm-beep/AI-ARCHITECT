import copy, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'integrations'/'seismic'))
from bim_results import apply_displacements
project=json.loads((ROOT/'integrations'/'examples'/'project.example.json').read_text())
results={"engine":"OpenSeesPy","status":"analysis-completed-needs-engineer-review","times_s":[0.01,0.02],"node_displacements_m_rad":{"1":[[0,0,0,0,0,0],[0,0,0,0,0,0]],"2":[[0,0,0,0,0,0],[0,0,0,0,0,0]],"3":[[0.01,0.02,0.03,0,0,0],[0.02,0.04,0.06,0,0,0]],"4":[[0.01,0.02,0.03,0,0,0],[0.02,0.04,0.06,0,0,0]]}}
original=copy.deepcopy(project['architecturalModel']['elements'][0]['geometry'])
out=apply_displacements(project,results,step=1,scale=10)
wall=next(e for e in out['deformedArchitecturalModel']['elements'] if e['id']=='wall-1')
assert wall['geometry']['start']==[0.2,0.6] and wall['geometry']['end']==[4.2,0.6]
assert wall['analysisDisplacements']['start']['verticalOffsetM']==0.4
assert project['architecturalModel']['elements'][0]['geometry']==original
assert out['isVisualizationOnly'] and out['timeS']==0.02 and len(out['mappingApplied'])==2
for bad in [None, []]:
    p=copy.deepcopy(project); p['structuralModel']['bimMapping']=bad
    try: apply_displacements(p,results)
    except ValueError: pass
    else: raise AssertionError('missing explicit mapping must be rejected')
try: apply_displacements(project,results,step=9)
except IndexError: pass
else: raise AssertionError('invalid step must be rejected')
print('BIM deformation mapping tests: PASS (explicit anchors, scale, immutable source, invalid mapping/step rejection)')
# Conflicting anchor mappings and malformed time vectors must be rejected.
conflict=copy.deepcopy(project)
conflict['structuralModel']['bimMapping'].append({'nodeId':1,'elementId':'wall-1','anchor':'start'})
try: apply_displacements(conflict,results)
except ValueError as e: assert 'bir nechta tugunga' in str(e)
else: raise AssertionError('one BIM anchor must not map to multiple analysis nodes')
short_times=copy.deepcopy(results); short_times['times_s']=[0.01]
try: apply_displacements(project,short_times)
except ValueError as e: assert 'times_s uzunligi' in str(e)
else: raise AssertionError('time vector length mismatch must be rejected')
bad_time=copy.deepcopy(results); bad_time['times_s'][1]=float('nan')
try: apply_displacements(project,bad_time)
except ValueError as e: assert 'NaN/Inf' in str(e)
else: raise AssertionError('non-finite time must be rejected')
print('BIM deformation validation extensions: PASS (conflicting anchors, time length, finite time)')
# Explicit triangular BIM mesh vertex mapping: source geometry stays immutable.
mesh_project=copy.deepcopy(project)
mesh_project['architecturalModel']['elements'].append({
    'id':'surface-1','geometry':{'type':'MeshSurface','vertices':[[0,0,0],[1,0,0],[0,1,0]],'faces':[[0,1,2]]}
})
mesh_project['structuralModel']['bimMapping']=[
    {'nodeId':1,'elementId':'surface-1','vertexIndex':0},
    {'nodeId':2,'elementId':'surface-1','vertexIndex':1},
    {'nodeId':3,'elementId':'surface-1','vertexIndex':2}
]
mesh_original=copy.deepcopy(mesh_project['architecturalModel']['elements'][-1]['geometry'])
mesh_out=apply_displacements(mesh_project,results,step=1,scale=10)
mesh_el=next(e for e in mesh_out['deformedArchitecturalModel']['elements'] if e['id']=='surface-1')
assert mesh_el['geometry']['vertices']==[[0,0,0],[1,0,0],[0.2,1.4,0.6]]
assert mesh_project['architecturalModel']['elements'][-1]['geometry']==mesh_original
assert len([m for m in mesh_out['mappingApplied'] if 'vertexIndex' in m])==3
print('BIM mesh deformation tests: PASS (explicit vertex mapping, XYZ displacement, immutable source)')
mesh_conflict=copy.deepcopy(mesh_project)
mesh_conflict['structuralModel']['bimMapping'].append({'nodeId':4,'elementId':'surface-1','vertexIndex':0})
try: apply_displacements(mesh_conflict,results)
except ValueError as e: assert 'vertex bir nechta tugunga' in str(e)
else: raise AssertionError('one mesh vertex must not map to multiple analysis nodes')
mesh_bad=copy.deepcopy(mesh_project)
mesh_bad['architecturalModel']['elements'][-1]['geometry']['faces']=[[0,1,9]]
try: apply_displacements(mesh_bad,results)
except ValueError as e: assert 'faces' in str(e)
else: raise AssertionError('invalid mesh triangle indices must be rejected')
print('BIM mesh validation tests: PASS (duplicate vertex mapping and invalid triangle rejection)')
