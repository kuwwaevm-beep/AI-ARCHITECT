# AIARCH Central BIM Core — v7 integration

## What changed
- Added `client/bim-core.js`, a dependency-free Central BIM Core shared by the browser app and Node tests.
- The Core creates one versioned conceptual model from the same validated footprint used by the existing 2D, 3D and seismic bridge: site, foundation, floor slabs, exterior wall segments and roof footprint.
- BIM element IDs are deterministic, allowing the same logical element to retain its ID across rebuilds.
- The model records SI units, level, geometry, IFC type mapping, derivation source and conceptual status.
- Smeta line items are copied into the model as a linked quantity/cost snapshot. Dimension changes and price edits rebuild the BIM snapshot.
- The current model is saved locally, emitted as `aiarch:bim-updated`, broadcast through `BroadcastChannel`, and posted to the parent suite frame.
- Project JSON export includes a BIM snapshot. Imported model snapshots are not trusted as authoritative: the client regenerates the model from validated project inputs.
- Added `scripts/bim-core.test.js` and static checks in `scripts/verify.js`.
- The single-file web build embeds BIM Core; Capacitor sync copies `client/bim-core.js` together with the rest of `client/`.

## Important scope and limitations
This is a conceptual parametric BIM foundation, not a full IFC4 authoring engine. Current geometry elements include site/foundation/slabs/exterior wall segments/roof footprint. It does not yet model each door, window, room boundary, reinforcement bar, MEP fitting or every interior partition as independent BIM objects. The existing 2D/3D renderers still contain their own view-specific construction code; the Core is now the canonical shared footprint/element snapshot but not yet the sole geometry kernel for every renderer.

IFC type labels in this first Core are mapping metadata, not proof of complete IFC4 schema compliance. Existing IFC export should be opened and checked in a target BIM application before being treated as an exchange deliverable.

The seismic/FEM screen remains a simplified educational screening/visualization path. It is not a validated structural solver and must not be used to approve real construction. Real design requires verified geotechnical inputs, load combinations, material certificates, applicable current Uzbek standards, a validated solver and qualified engineer sign-off.

Material prices remain user/admin supplied or source-fed values. A stored number is not a verified live market quote unless its source, region, currency, unit and update date have been independently checked.

## Verification
Run from `aiarch/`:

```bash
npm test
npm run test:e2e
npm run test:exact
npm run test:quake
npm run test:suite
npm run test:dock
npm run test:modules
npm run test:geo
```

The report in `AIARCH-AUDIT-FINAL.md` records exactly which checks passed in the current package. Browser tests use local fixtures/stubs for some external services and do not verify real hosting, real Android hardware/WebGL performance, a live PostgreSQL deployment, market price feeds, or external BIM application compatibility.
