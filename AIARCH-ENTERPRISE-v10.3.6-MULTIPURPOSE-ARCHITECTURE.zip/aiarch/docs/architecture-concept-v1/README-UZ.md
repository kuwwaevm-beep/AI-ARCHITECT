# AIARCH — Ko‘p maqsadli bino arxitektura konsepsiyasi

Ushbu paket AIARCH asosiy loyihasiga qo‘shilgan dastlabki arxitektura dasturi va sxematik chizmalar to‘plamidir.

- 1-qavat: savdo, kafe, jamoat foye va xizmatlar.
- 2-qavat: ofis, o‘quv xonalari, majlis.
- 3–5-qavatlar: turar joy va umumiy foydalanish zonalari.
- Dastlabki gabarit: 30 × 24 m; 5 qavat.
- Konstruktiv konsepsiya: temir-beton karkas va markaziy qattiqlik yadrosi.

**Muhim:** PDFdagi rejalar funksional zonalash eskizidir; xona o‘lchamlari, eshik-deraza, evakuatsiya, yong‘in, nogironligi bo‘lgan shaxslar uchun qulaylik, konstruksiya, poydevor va seysmik hisoblar loyiha joyi, geologiya va O‘zbekistonning amaldagi me’yorlari bo‘yicha malakali mutaxassislar tomonidan ishlab chiqilishi shart. Bu hujjat qurilish uchun ishchi loyiha yoki ekspertiza xulosasi emas.
