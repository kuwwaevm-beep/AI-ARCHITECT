# AIARCH Earthquake Engineering Studio

Ushbu paket AIARCH Enterprise v10.3.4 manba loyihasi asosida tayyorlangan, zilzila tahliliga yo'naltirilgan maxsus ishchi interfeysni qo'shadi.

## Ishga tushirish
- `AIARCH-EARTHQUAKE-STUDIO.html` faylini zamonaviy Chrome/Edge/Firefox brauzerida oching.
- 3D sahna Three.js modulini CDN orqali yuklaydi, shu sababli birinchi ochishda internet kerak.
- Sichqoncha yoki sensorli ekran bilan 3D binoni aylantiring; `Rang xaritasi`, intensivlik, qavat soni va animatsiya boshqaruvlaridan foydalaning.

## FEM natijasini import qilish
Fayl tanlash oynasi quyidagi shakldagi JSONni qabul qiladi:
```json
{
  "floor_displacements_mm": [5.2, 8.7, 14.6, 21.3, 32.4]
}
```
Bu qavatlar bo'yicha maksimal siljish qiymatlarini millimetrda beradi.

## Muhim muhandislik chegarasi
Interfeysdagi boshlang'ich qiymatlar va animatsiya ko'rgazmali demo profilidir; u OpenSees/FEM hisobini o'zi bajarmaydi. FEM JSON importi faqat qavat siljishlarini vizualizatsiya qiladi. Haqiqiy konstruktiv xulosa uchun muhandis tayyorlagan va tekshirgan model, material/section ma'lumotlari, tayanch shartlari, massa, real accelerogramma, solver hisoboti va me'yoriy tekshiruv talab qilinadi. Rang chegaralari ham xavfsizlik mezoni sifatida talqin qilinmasin.
