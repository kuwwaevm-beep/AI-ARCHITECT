# AI ARCHITECT PRO — v9 ta'mirlash qaydi
Sana: 2026-11-01

## Ushbu paketda bajarilgan ishlar
1. `GET /api/ai/status` endpoint qo'shildi. U API kalitining o'zini bermaydi, faqat serverda konfiguratsiya bor/yo'qligini bildiradi.
2. AI interfeysi endi faqat server Anthropic konfiguratsiyasini tasdiqlaganidan keyin AI'ni tayyor deb ko'rsatadi.
3. Offline rejimdagi noto'g'ri “Anthropic API kalitingizni shu yerga kiriting” yo'riqnomasi tuzatildi. Kalit server `.env` da saqlanishi kerak.
4. Android `mobile/www` sinxronizatsiyasi `AIARCH_API` o'rnatilmagan bo'lsa ham offline build uchun ishlaydi. Keyin foydalanuvchi bulut oynasidan HTTPS server manzilini kiritishi mumkin.
5. Android debug/release Gradle build skriptlari alohida nomlandi.
6. Mobile sync regression testi qo'shildi; AI holati o'zgarganiga mos browser E2E testi yangilandi.
7. `AIARCH-ENTERPRISE-SUITE.html` frontend manbalaridan qayta yig'ildi.

## Sinovlar
- `npm test`: muvaffaqiyatli.
  - statik xavfsizlik va butunlik tekshiruvlari: o'tdi (mobile/www build yo'qligi haqida ogohlantirish normal).
  - project validation: 7/7.
  - viewport regression: 7/7.
  - shared model: 7/7.
  - BIM Core: 9/9.
  - mobile sync: 3/3.
  - backend security: 6/6.
- Browser E2E:
  - client: 29/29.
  - exact contour/DXF/IFC: 27/27.
  - dock/12 modules: 33/33.
  - modules/materials/agents: 27/27.
  - seismic: 20/20.
  - suite bridge: 14/14.
  - geolocation/2D CAD: 24/24.
  - jami: 174/174.
- `node --check server/server.js`: o'tdi.

## Hali bajarilishi shart bo'lgan deploy/qabul ishlari
- Bu muhitda Android SDK/ADB/Gradle va `mobile/android` native project mavjud emas. Shu sabab APK/AAB yig'ilmadi va haqiqiy Android telefonda tekshirilmadi.
- Haqiqiy AI uchun hostingga joylashtirilgan HTTPS server, PostgreSQL, `DATABASE_URL`, `JWT_SECRET` va Anthropic tomonidan berilgan `ANTHROPIC_API_KEY` talab qilinadi. Bu maxfiy ma'lumotlar foydalanuvchi tomonidan serverda sozlanadi.
- `npm test` va E2E brauzer testlari jonli Anthropic so'rovi, PostgreSQL RLS ishga tushishi, Android WebView/GPU yoki Play Store release signing'ni tasdiqlamaydi.
- BIM Core hali konseptual qatlam; to'liq IFC4 authoring/round-trip emas.
- Seysmik/FEM-lite modul screening/vizualizatsiya bo'lib qoladi, sertifikatlangan konstruktiv solver emas. Qurilish uchun mahalliy SHNQ/GOST bo'yicha malakali muhandis tasdig'i shart.

## Android build uchun keyingi amallar
1. Node.js 22+, Android Studio, Android SDK/JDK o'rnating.
2. `cd mobile && npm install && npx cap add android` (faqat bir marta).
3. Backend HTTPS manzili bo'lsa `AIARCH_API=https://api.example.uz npm run sync`; bo'lmasa `npm run sync` offline.
4. `cd mobile && npm run build:android:debug` yoki `npm run open:android`.
5. Haqiqiy qurilmada kamera, sensor, 3D WebGL, ekran aylanishi, klaviatura, offline/online va login/AI qabul sinovlarini bajaring.
