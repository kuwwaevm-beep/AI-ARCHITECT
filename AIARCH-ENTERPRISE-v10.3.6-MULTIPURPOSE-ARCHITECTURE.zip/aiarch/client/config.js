window.AIARCH_CONFIG = { api: "" }; // Veb: bo'sh (o'sha domen). Mobil: scripts/sync-mobile.js avtomatik yozadi.
