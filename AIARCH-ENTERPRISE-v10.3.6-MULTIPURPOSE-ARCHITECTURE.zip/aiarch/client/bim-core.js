/* AIARCH Central BIM Core — deterministic, dependency-free model layer. */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.AIARCHBIM = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const finite = n => typeof n === 'number' && Number.isFinite(n);
  const clone = x => JSON.parse(JSON.stringify(x));
  function stableId(seed) {
    let h1 = 0x811c9dc5, h2 = 0x01000193;
    for (let i = 0; i < seed.length; i++) { const c = seed.charCodeAt(i); h1 = Math.imul(h1 ^ c, 0x01000193); h2 = Math.imul(h2 ^ (c + i), 0x85ebca6b); }
    return 'bim-' + (h1 >>> 0).toString(16).padStart(8, '0') + (h2 >>> 0).toString(16).padStart(8, '0');
  }
  function polygonOK(poly) {
    return Array.isArray(poly) && poly.length >= 3 && poly.length <= 500 && poly.every(p => Array.isArray(p) && p.length === 2 && p.every(finite));
  }
  function area(poly) { let a = 0; for (let i = 0; i < poly.length; i++) { const p = poly[i], q = poly[(i + 1) % poly.length]; a += p[0] * q[1] - q[0] * p[1]; } return Math.abs(a) / 2; }
  function perimeter(poly) { return poly.reduce((s, p, i) => { const q = poly[(i + 1) % poly.length]; return s + Math.hypot(q[0] - p[0], q[1] - p[1]); }, 0); }
  function buildModel(input) {
    if (!input || typeof input !== 'object') throw new TypeError('BIM input kerak');
    const p = input.footprint;
    if (!p || !polygonOK(p.poly)) throw new TypeError('Bino konturi noto‘g‘ri');
    const floors = Math.max(1, Math.min(30, Math.round(Number(input.floors) || 1)));
    const height = Number(input.floorHeight);
    const wallThickness = Number(input.wallThickness);
    const foundationDepth = Number(input.foundationDepth);
    if (![height, wallThickness, foundationDepth].every(finite) || height < 2 || height > 6 || wallThickness < 0.08 || wallThickness > 1 || foundationDepth < 0.2 || foundationDepth > 5) throw new RangeError('BIM o‘lchamlari ruxsat etilgan oraliqda emas');
    const poly = p.poly.map(v => [v[0], v[1]]), elements = [];
    const add = (type, key, geometry, properties, level = null) => elements.push({
      id: stableId(type + ':' + key), ifcType: ({ wall: 'IfcWall', slab: 'IfcSlab', roof: 'IfcRoof', foundation: 'IfcFooting', land: 'IfcSite' })[type] || 'IfcBuildingElementProxy',
      type, level, geometry, properties: Object.assign({ source: 'derived-from-user-input', status: 'conceptual' }, properties)
    });
    if (polygonOK(input.landFootprint)) add('land', 'site', { type: 'Polygon', coordinates: input.landFootprint.map(v => [...v]) }, { areaM2: area(input.landFootprint) });
    add('foundation', 'foundation', { type: 'ExtrudedPolygon', polygon: poly, depthM: foundationDepth }, { perimeterM: perimeter(poly), depthM: foundationDepth });
    for (let f = 0; f < floors; f++) {
      add('slab', 'slab-' + f, { type: 'ExtrudedPolygon', polygon: poly, elevationM: f * height, thicknessM: 0.22 }, { areaM2: area(poly), thicknessM: 0.22 }, f + 1);
      poly.forEach((a, i) => { const b = poly[(i + 1) % poly.length]; add('wall', `wall-${f}-${i}`, { type: 'WallSegment', start: [...a], end: [...b], baseElevationM: f * height, heightM: height - 0.22, thicknessM: wallThickness }, { lengthM: Math.hypot(b[0] - a[0], b[1] - a[1]), heightM: height - 0.22, thicknessM: wallThickness }, f + 1); });
    }
    add('roof', 'roof', { type: 'RoofFootprint', polygon: poly, elevationM: floors * height }, { projectedAreaM2: area(poly) }, floors);
    const estimate = Array.isArray(input.estimateItems) ? input.estimateItems.map(x => ({ name: String(x.name || '').slice(0, 120), quantity: finite(Number(x.qty)) ? Number(x.qty) : 0, unit: String(x.unit || '').slice(0, 20), unitPrice: finite(Number(x.price)) ? Number(x.price) : 0, total: finite(Number(x.total)) ? Number(x.total) : 0 })) : [];
    const model = { schema: 'AIARCH-BIM-1.0', modelId: 'aiarch-central-model', units: { length: 'm', area: 'm2', volume: 'm3' }, version: 1,
      createdAt: new Date().toISOString(), source: 'parametric-concept-model', status: 'conceptual-not-for-construction',
      building: { floors, floorHeightM: height, wallThicknessM: wallThickness, footprintAreaM2: area(poly), perimeterM: perimeter(poly), footprint: poly },
      elements, estimate, warnings: ['Konseptual BIM: geologiya, yuklar, material sertifikatlari va muhandis tasdig‘isiz qurilish uchun ishlatilmaydi.'] };
    return model;
  }
  function validateModel(m) {
    if (!m || m.schema !== 'AIARCH-BIM-1.0' || !Array.isArray(m.elements) || !m.building || !polygonOK(m.building.footprint)) return false;
    const ids = new Set();
    for (const e of m.elements) { if (!e || typeof e.id !== 'string' || ids.has(e.id) || !e.geometry || typeof e.geometry.type !== 'string') return false; ids.add(e.id); }
    return true;
  }
  return Object.freeze({ buildModel, validateModel, stableId, polygonArea: area, polygonPerimeter: perimeter, clone });
});
