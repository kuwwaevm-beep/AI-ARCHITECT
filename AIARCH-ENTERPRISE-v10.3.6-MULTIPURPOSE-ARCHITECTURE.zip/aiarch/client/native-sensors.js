// index.html ichiga native-sensors.js ni script teg'i bilan qo'shing (mobile/www ichida).
// Kamera va giroskop (qurilma og'ishi) — Capacitor plaginlari orqali, brauzerda esa oddiy API orqali.
window.AIARCH_NATIVE = {
  async takePhoto() {
    const cap = window.Capacitor && Capacitor.Plugins;
    if (cap && cap.Camera) {
      const p = await cap.Camera.getPhoto({ quality: 80, resultType: 'dataUrl', source: 'CAMERA' });
      return p.dataUrl;
    }
    return new Promise(res => { const i = document.createElement('input'); i.type = 'file'; i.accept = 'image/*'; i.capture = 'environment';
      i.onchange = () => { const r = new FileReader(); r.onload = () => res(r.result); r.readAsDataURL(i.files[0]); }; i.click(); });
  },
  // Burchak o'lchash (gorizont/vertikal tekshirish) uchun: cb({alpha,beta,gamma})
  async watchTilt(cb) {
    const cap = window.Capacitor && Capacitor.Plugins;
    if (cap && cap.Motion) return cap.Motion.addListener('orientation', cb);
    if (window.DeviceOrientationEvent && DeviceOrientationEvent.requestPermission) await DeviceOrientationEvent.requestPermission();
    window.addEventListener('deviceorientation', e => cb({ alpha: e.alpha, beta: e.beta, gamma: e.gamma }));
  }
};
