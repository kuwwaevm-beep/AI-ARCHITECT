# AIARCH v10 — release status

## Delivered in this archive
- Existing v9 source retained (web client, server, PostgreSQL schema, Capacitor Android setup, tests).
- Native AIARCH JSON -> shared SI project wrapper (`integrations/prepare_project.py`).
- Editable AutoCAD-compatible DXF plan exporter and `AIARCHOPEN` AutoLISP helper.
- Autodesk 3ds Max `pymxs` scene importer.
- OpenSeesPy 3D transient time-history adapter with strict model/accelerogram validation.
- Previous seismic UI's artificial x40 displacement amplification removed; UI now labels the built-in scenario as a simplified screening/modal demo, not FEM or a real earthquake record.

## Tested here
- `npm test`: passed (existing static/unit/backend tests plus interop tests).
- DXF exporter: parsed successfully with ezdxf 1.4.4 as AC1009, including POLYLINE/LINE/TEXT entities.
- Interop contract, native JSON wrapper, SI validation, missing structural model rejection and accelerogram parser: passed.

## Not tested / not complete
- No AutoCAD, 3ds Max, Revit, Android device, or Android SDK is installed in this build environment; no Autodesk runtime or APK test was possible.
- OpenSeesPy is not installed in this environment; transient analysis has not been executed here.
- DXF export is 2D plan exchange, not a DWG writer or full AutoCAD clone.
- 3ds Max importer is a basic scene-geometry importer, not a full Max modeling/render pipeline.
- Revit uses the existing IFC export route; native RVT writing is not implemented and existing IFC proxy classifications need review.
- The BIM architectural mesh is not yet mapped to OpenSees analytical nodes/elements; solver result displacement is not yet driving the AIARCH Three.js building mesh.
- Autodesk desktop authoring cannot run inside Android; Android remains a companion client.

## v10.1 — AutoCAD QA va seysmik review (2026-11-01)

- Added `integrations/autocad/AIARCH_QA_CLEAN.lsp`: layer/lineweight template, QA report, backup + AUDIT/PURGE, layer-scoped PEDIT JOIN.
- Added `integrations/autocad/AUTOCAD-QA-GUIDE-UZ.md` and `integrations/seismic/STRUCTURAL_REVIEW_TEMPLATE_UZ.md`.
- Added static checks for the AutoLISP command definitions and seismic checklist.
- Full `npm test` passed in this environment. AutoCAD runtime and DWG fixture test remain pending; no claim of AutoCAD execution is made.
- No automatic structural redesign, column sizing, confinement spacing, seismic-joint sizing, or BIM↔FEM deformation mapping was introduced.


## v10.2 engineering increment — BIM deformation bridge
- Added explicit `structuralModel.bimMapping` schema for OpenSees node to BIM wall-endpoint links.
- Added `integrations/seismic/bim_results.py` and CLI `apply_bim_results.py` to create a separate deformed BIM JSON from OpenSees nodal displacement histories.
- First supported geometry: `WallSegment.start` and `WallSegment.end` only. Mapping is explicit; no automatic node-to-wall inference.
- Physical displacement is retained in meters; optional visualization scale is clearly marked. Source project is immutable.
- Added regression tests for mapped anchors, visual scale, immutability, invalid mapping and step handling.
- Verification: `npm test` passed, including 2 BIM deformation bridge tests and all existing project/server tests.
- Limitation: the exported deformed BIM JSON is not yet wired into the interactive Three.js viewport; no OpenSees solver run or native Autodesk application validation was performed in this increment.
