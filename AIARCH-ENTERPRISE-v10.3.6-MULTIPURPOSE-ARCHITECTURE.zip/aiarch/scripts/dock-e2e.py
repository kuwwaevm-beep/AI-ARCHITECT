# Pastki panel (12 modul) tekshiruvi.  python3 scripts/dock-e2e.py
import mimetypes, os
from playwright.sync_api import sync_playwright
from e2e_helpers import build_suite_test_html
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'client') + '/'
PRE = "window.tailwind={};const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:mk(),construct:()=>mk(),apply:()=>mk()});window.THREE=mk();"
res = []
def ok(c, m): res.append(bool(c)); print(('  ✓ ' if c else '  ✗ ') + m)
def route(r):
    u = r.request.url
    if u.startswith('http://127.0.0.1:8765/'):
        f = u.split('http://127.0.0.1:8765/')[1].split('?')[0] or 'suite.html'
        h = open(ROOT + f, encoding='utf-8').read()
        if f == 'index.html': h = h.replace('window.onload = function () {', 'window.onload = function () { try{init3dsMaxEngine=function(){};rebuild3dsMaxScene=function(){};}catch(e){}')
        return r.fulfill(body=h, content_type=mimetypes.guess_type(f)[0] or 'text/html')
    r.abort()
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("AIARCH_CHROMIUM_PATH", "/usr/bin/chromium"), args=["--no-sandbox"]); ctx = b.new_context(viewport={'width': 420, 'height': 850}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.route('**/*', lambda r: r.abort())
    pg.set_content(build_suite_test_html(ROOT, PRE)); pg.wait_for_timeout(1800)
    fa = pg.frames[1]; fb = pg.frames[2]
    click = lambda m: (pg.click(f'.dk[data-m="{m}"]'), pg.wait_for_timeout(350))
    ok(pg.locator('.dk').count() == 12, 'pastki panelda 12 ta tugma')
    ok(pg.evaluate("[...document.querySelectorAll('.dk')].map(b=>b.dataset.m).join()") == 'kad,geo,cad,3d,str,mep,est,ust,exp,tam,pro,ens', 'tartib: spetsifikatsiya bo\'yicha 12 modul')
    ok(pg.evaluate("[...document.querySelectorAll('.dk')].every(b=>b.getBoundingClientRect().right<=window.innerWidth+1&&b.getBoundingClientRect().width>20)"), '420px ekranga sig\'adi')
    for m in ['kad','geo','cad','3d','str','mep','est','ust','exp','tam','pro','ens']:
        click(m); ok(pg.evaluate("document.querySelector('.dk.on').dataset.m") == m and pg.locator('.dk.on').count() == 1, f'{m}: faol tugma almashdi')
    click('cad'); ok(fa.evaluate("appState.activeView") == '2d' and not pg.evaluate("document.getElementById('f-arch').classList.contains('off')"), '2: AutoCAD 2D ko\'rinishi ochildi')
    click('3d'); ok(fa.evaluate("appState.activeView") == '3d', '3: 3ds Max 3D ko\'rinishi')
    click('est'); ok(fa.evaluate("appState.activeView") == 'smeta', '6: Smeta ko\'rinishi')
    click('geo'); ok(fb.evaluate("document.querySelector('.screen.active').id") == 'scr-map' and pg.evaluate("document.getElementById('f-arch').classList.contains('off')"), '1: Geologiya (xarita) ochildi')
    click('str'); ok(fb.evaluate("document.querySelector('.screen.active').id") == 'scr-hazards', '4: Konstruktor (seysmika) ochildi')
    click('exp'); ok(pg.evaluate("getComputedStyle(document.getElementById('np')).display") == 'block' and 'Xulosa' in pg.inner_text('#np'), '7: Ekspert xulosa chiqardi')
    ok(pg.evaluate("window.__exp&&window.__exp.n>0"), '7: tekshiruvlar soni > 0')
    click('mep'); ok('Kolliziya topilmadi' in pg.inner_text('#np'), '5: bo\'sh MEP — kolliziya yo\'q')
    pg.click('#mDemo'); pg.wait_for_timeout(200)
    ok('KOLLIZIYA' in pg.inner_text('#np') and 'kesishdi' in pg.inner_text('#np') and pg.evaluate("Suite.mepCollisions().some(c=>c.k==='x')"), '5: Elektr↔Suv kesishishi qizil xato')
    pg.fill('#m1','-1'); pg.fill('#m2','-1'); pg.fill('#m3','1'); pg.fill('#m4','-1'); pg.select_option('#mT','is'); pg.click('#mAdd'); pg.wait_for_timeout(150)
    ok(pg.evaluate("Suite.state().mep.length") == 3, '5: qo\'lda trassa qo\'shildi')
    pg.click('#mClr'); pg.wait_for_timeout(150); ok('Kolliziya topilmadi' in pg.inner_text('#np'), '5: tozalangach kolliziya yo\'q')
    pg.evaluate("(()=>{const c=Suite.model().poly[0];Suite.state().mep.push({t:'su',f:1,x1:c[0]-2,y1:c[1],x2:c[0]+2,y2:c[1]})})()"); click('mep')
    ok(pg.evaluate("Suite.mepCollisions().some(c=>c.k==='c')"), '5: ustunni teshib o\'tgan truba topildi')
    pg.click('#mClr')
    click('pro'); pg.fill('#rD','2026-10-27'); pg.fill('#rT','Poydevor quyildi <b>x</b>'); pg.fill('#rP','40'); pg.click('#rAdd'); pg.wait_for_timeout(200)
    ok('Poydevor quyildi' in pg.inner_text('#np') and pg.evaluate("[...document.querySelectorAll('#np b')].every(b=>b.textContent!=='x')"), '8: hisobot qo\'shildi va XSS ekranlandi')
    pg.fill('[data-q="0"]','10'); pg.dispatch_event('[data-q="0"]','change'); pg.wait_for_timeout(200)
    ok('kam' in pg.inner_text('#np'), '8: ombor qoldig\'i kam ogohlantirishi')
    pg.fill('#pS','2026-11-01'); pg.dispatch_event('#pS','change'); pg.wait_for_timeout(150); ok('Tugash: 2027-02-09' in pg.inner_text('#np'), '8: Gantt tugash sanasi')
    ok(pg.evaluate("!!localStorage.getItem('aiarch.suite.v1')"), 'o\'zgarishlar umumiy loyiha holatiga saqlandi')
    # Browser policy gives srcdoc top-level pages opaque origins; verify the actual BroadcastChannel receiver in this app context.
    pg.evaluate("(()=>{const c=new BroadcastChannel('aiarch-suite');c.postMessage({mod:'test',what:'sinov',P:{reports:[{t:'Devor 1-qator'}]}});c.close()})()"); pg.wait_for_timeout(300)
    ok(pg.evaluate("Suite.state().reports.some(r=>r.t==='Devor 1-qator')"), 'BroadcastChannel hodisasi boshqa modul holatini qabul qildi')
    bad = [e for e in errs if 'tailwind' not in e and 'appendChild' not in e and 'L is not' not in e]
    ok(not bad, 'JS xatolari yo\'q ' + str(bad[:3]))
    b.close()
print(f'\n{sum(res)}/{len(res)}'); raise SystemExit(0 if all(res) else 1)
