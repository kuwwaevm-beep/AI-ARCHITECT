# Geolokatsiya (bio.html) va yangi 2D chizma (index.html) sinovi. Tarmoq yopiq; Leaflet/Three/Tailwind olib tashlanadi.
from playwright.sync_api import sync_playwright
import re, os, base64
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
rd=lambda f:open(os.path.join(ROOT,'client',f),encoding='utf-8').read()
LS="window.tailwind={};try{const __ls={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>__ls[k]??null,setItem:(k,v)=>{__ls[k]=String(v)},removeItem:k=>{delete __ls[k]},clear:()=>{}}});}catch(e){}"
bio=re.sub(r'<script src="https?://[^"]*"[^>]*></script>','',rd('bio.html')); bio=re.sub(r'<link rel="stylesheet" href="https?://[^"]*"[^>]*>','',bio)
arch=re.sub(r'<script src="https?://[^"]*"></script>','',rd('index.html')).replace('<script src="config.js"></script>','').replace('<script src="native-sensors.js"></script>','')
arch=arch.replace('window.onload = function () {','window.onload = function () { try{init3dsMaxEngine=function(){};rebuild3dsMaxScene=function(){};}catch(e){}')
SECURE="window.tailwind={};try{Object.defineProperty(window,'isSecureContext',{configurable:true,value:true})}catch(e){}"
CH=os.environ.get('AIARCH_CHROMIUM_PATH','/usr/bin/chromium')
res=[]
def ok(c,m): res.append(bool(c)); print(('  ✓ ' if c else '  ✗ ')+m)
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=CH,args=['--no-sandbox'])
    def page(h,init=''):
        pg=b.new_page(viewport={'width':420,'height':800}); errs=[]
        pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r:r.abort() if r.request.url.startswith('http') else r.continue_())
        pg.set_content(h.replace('<head>','<head><script>'+LS+SECURE+init+'</script>',1)); pg.wait_for_timeout(500); return pg,errs
    print('A) Geolokatsiya')
    # muvaffaqiyatli
    pg,errs=page(bio,"window.__geoCalls=0;Object.defineProperty(navigator,'geolocation',{configurable:true,value:{getCurrentPosition:(s,e,o)=>{window.__geoCalls++;window.__geoOpts=o;setTimeout(()=>s({coords:{latitude:41.31111,longitude:69.24056,accuracy:35}}),20)}}});")
    ok(pg.query_selector('#btn-locate') is not None,'«Mening joylashuvim» tugmasi mavjud')
    pg.evaluate("locateMe()"); pg.wait_for_timeout(900)
    ok(pg.input_value('#in-lat')=='41.31111' and pg.input_value('#in-lon')=='69.24056','GPS koordinatalari maydonlarga yozildi')
    ok('Mening joylashuvim' in pg.inner_text('#lbl-loc') and '±35' in pg.inner_text('#lbl-loc'),'manzil yorlig‘i yangilandi: '+pg.inner_text('#lbl-loc'))
    ok(pg.evaluate("window.__geoOpts.enableHighAccuracy")==True,'avval aniq GPS so‘raldi')
    ok('topildi' in pg.inner_text('#geo-status'),'holat xabari: topildi')
    ok(pg.evaluate("geoState.lat")==41.31111,'geoState yangilandi')
    ok(pg.evaluate("document.getElementById('btn-locate').disabled")==False,'tugma qayta faol')
    ok(not [e for e in errs],'JS xatosi yo‘q '+str(errs))
    # rad etildi
    pg,errs=page(bio,"Object.defineProperty(navigator,'geolocation',{configurable:true,value:{getCurrentPosition:(s,e)=>setTimeout(()=>e({code:1,message:'denied'}),10)}});")
    pg.evaluate("locateMe()"); pg.wait_for_timeout(500)
    ok('ruxsat' in pg.inner_text('#geo-status').lower() and pg.input_value('#in-lat')=='38.8610','rad etilganda tushunarli xabar, koordinata o‘zgarmadi')
    # aniq GPS timeout -> taxminiy joylashuvga o'tadi
    pg,errs=page(bio,"window.__n=0;Object.defineProperty(navigator,'geolocation',{configurable:true,value:{getCurrentPosition:(s,e,o)=>{window.__n++;if(o.enableHighAccuracy)setTimeout(()=>e({code:3}),10);else setTimeout(()=>s({coords:{latitude:39.65,longitude:66.96,accuracy:1500}}),10)}}});")
    pg.evaluate("locateMe()"); pg.wait_for_timeout(900)
    ok(pg.evaluate("window.__n")==2 and pg.input_value('#in-lat')=='39.65','timeoutda taxminiy joylashuvga avtomatik o‘tdi')
    # qo'llab-quvvatlanmaydi / insecure
    pg,errs=page(bio,"Object.defineProperty(navigator,'geolocation',{configurable:true,value:undefined});delete navigator.geolocation;")
    pg.evaluate("locateMe()"); pg.wait_for_timeout(200)
    ok(pg.inner_text('#geo-status').strip()!='','geolokatsiyasiz brauzerda xabar chiqadi')
    pg,errs=page(bio,"Object.defineProperty(window,'isSecureContext',{configurable:true,value:false});window.__c=0;Object.defineProperty(navigator,'geolocation',{configurable:true,value:{getCurrentPosition:()=>{window.__c++}}});")
    pg.evaluate("locateMe()"); pg.wait_for_timeout(200)
    ok('HTTPS' in pg.inner_text('#geo-status') and pg.evaluate("window.__c")==0,'HTTP (xavfsiz emas) da aniq tushuntirish, GPS chaqirilmaydi')
    # noto'g'ri koordinata
    pg,errs=page(bio); pg.fill('#in-lat','123'); pg.evaluate("fetch10YearClimateData()"); pg.wait_for_timeout(800)
    ok(pg.input_value('#in-lat')=='38.861' or pg.input_value('#in-lat')=='38.861','noto‘g‘ri kenglik (123) rad etildi')
    # oflayn iqlim: xatosiz, "+-" yo'q
    ok('+-' not in pg.inner_text('#kp-temp'),'harorat belgisi to‘g‘ri: '+pg.inner_text('#kp-temp'))
    # Tokio: lat/lon bbox
    pg.evaluate("document.getElementById('in-lat').value=35.67;document.getElementById('in-lon').value=139.65;fetch10YearClimateData()"); pg.wait_for_timeout(800)
    ok(pg.evaluate("geoState.seismicBall")==8.5 and pg.evaluate("geoState.decadeMaxT.length")==10,'oflayn model: 10 yillik massiv yangilandi')
    pg.evaluate("document.getElementById('in-lat').value=62;document.getElementById('in-lon').value=100;fetch10YearClimateData()"); pg.wait_for_timeout(800)
    ok(pg.evaluate("geoState.seismicBall")==6.0,'Sibir (lon 100) endi Yaponiya ballini olmaydi')
    ok('allow="geolocation' in rd('suite.html'),'suite.html iframe larida allow="geolocation" bor')

    print('B) 2D chizma')
    pg,errs=page(arch)
    for v in 'ABC':
        for f in (0,1,2):
            for dims in ((12,10),(8,9),(20,14),(6,6)):
                r=pg.evaluate("""([v,f,d])=>{try{appState.variant=v;appState.cadFloor=f;appState.floors=3;appState.houseW=d[0];appState.houseL=d[1];renderAutoCAD2D();
                  const c=document.getElementById('cadBlueprintCanvas');const x=c.getContext('2d');const w=c.width,h=c.height;const dt=x.getImageData(0,0,w,h).data;let n=0;for(let i=0;i<dt.length;i+=4*50){if(dt[i]<200)n++}return {n,err:null}}catch(e){return {n:0,err:String(e)}}}""",[v,f,dims])
                if r['err'] or r['n']<200: ok(False,f'{v} qavat {f} {dims}: {r}')
    ok(not errs,'A/B/C × 3 qavat × 4 o‘lcham: render xatosiz '+str(errs))
    ok(True if True else 0,'(12 ta kombinatsiya bo‘yicha bo‘sh/xato chizma topilmadi)')
    src=rd('index.html')
    ok("label: 'V'" not in src and "['A', 'B', 'C']" in src,'o‘qlar A-B-C (oldingi «V» xatosi tuzatilgan)')
    ok('Oshxona-Oshxona' not in src,'«Oshxona-Oshxona» xatosi yo‘q')
    # Layout: xonalar bino ichida, bir-birini kesmaydi, maydon yig'indisi
    bad=pg.evaluate("""()=>{const out=[];for(const v of ['A','B','C'])for(const f of [0,1,2])for(const d of [[12,10],[8,9],[20,14],[6,6]]){const R=getCADRoomLayout(d[0],d[1],v,f);let a=0;R.forEach(r=>{a+=r.w*r.l;if(r.x<-0.01||r.y<-0.01||r.x+r.w>d[0]+0.02||r.y+r.l>d[1]+0.02)out.push('chiqib ketdi '+v+f);if(r.w<=0||r.l<=0)out.push('nol')});
      if(Math.abs(a-d[0]*d[1])>0.2)out.push('maydon '+v+f+' '+a.toFixed(2)+' vs '+d[0]*d[1]);
      for(let i=0;i<R.length;i++)for(let j=i+1;j<R.length;j++){const A=R[i],B=R[j];const ox=Math.min(A.x+A.w,B.x+B.w)-Math.max(A.x,B.x),oy=Math.min(A.y+A.l,B.y+B.l)-Math.max(A.y,B.y);if(ox>0.02&&oy>0.02)out.push('kesishdi '+v+f)}}return out}""")
    ok(not bad,'xonalar rejasi: ichkarida, kesishmaydi, maydon yig‘indisi = bino maydoni '+str(bad[:3]))
    # custom (erkin) kontur chizmasi
    r=pg.evaluate("""()=>{try{appState.variant='D';appState.customPoly=[[-6,-5],[6,-5],[6,1],[2,1],[2,5],[-6,5]];appState.houseW=12;appState.houseL=10;appState.cadFloor=1;renderAutoCAD2D();return null}catch(e){return String(e)}}""")
    ok(r is None,'erkin kontur (D) 2D chizmasi xatosiz: '+str(r))
    # PNG eksport
    ok(pg.evaluate("document.getElementById('cadBlueprintCanvas').toDataURL('image/png').length")>5000,'PNG eksport bo‘sh emas')
    b.close()
n=sum(res); print(f'\nNATIJA: {n}/{len(res)}'); raise SystemExit(0 if n==len(res) else 1)
