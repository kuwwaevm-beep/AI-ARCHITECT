# Yagona fayl (suite-webapp.html) yig'ish: python3 scripts/build-webapp.py [chiqish_fayli]
import re,html,os,sys
D=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','client')
rd=lambda f:open(os.path.join(D,f),encoding='utf-8').read()
arch=rd('index.html'); bio=rd('bio.html'); suite=rd('suite.html')
arch=arch.replace('<script src="config.js"></script>','<script>'+rd('config.js')+'</script>').replace('<script src="native-sensors.js"></script>','<script>'+rd('native-sensors.js')+'</script>').replace('<script src="bim-core.js"></script>','<script>'+rd('bim-core.js')+'</script>')
em={'robot':'🤖','layer-group':'🗂','compass-drafting':'📐','circle':'●','xmark':'✕','keyboard':'⌨','file-invoice-dollar':'🧾','cubes':'🧱','copy':'📋','circle-check':'✔','wand-magic-sparkles':'✨','video':'🎥','vector-square':'⬚','trowel-bricks':'🧱','triangle-exclamation':'⚠','rotate-left':'↩','print':'🖨','paper-plane':'➤','palette':'🎨','moon':'🌙','image':'🖼','file-contract':'📄','eye-slash':'🙈','download':'⬇','diagram-project':'🗺','cube':'🧊','check':'✔','calculator':'🧮','building':'🏢','arrows-rotate':'⟳'}
css='<style>.fa-solid,.fa-regular,.fa-brands{font-style:normal;display:inline-block}'+''.join('.fa-%s::before{content:"%s"}'%(k,v) for k,v in em.items())+'</style>'
arch,n=re.subn(r'<link rel="stylesheet" href="https://cdnjs[^>]*font-awesome[^>]*>',css,arch); assert n==1
old="(window.self !== window.top && !(function () { try { return !!window.top.document; } catch (e) { return false; } })());"
assert old in arch; arch=arch.replace(old,"true;")
assert 'cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js' in bio  # Leaflet (xarita) saqlanadi: internet bo'lsa xarita ishlaydi, bo'lmasa oflayn zaxira
q=lambda s: html.escape(s,quote=True)
suite=suite.replace('src="index.html"','srcdoc="'+q(arch)+'"').replace('src="bio.html"','srcdoc="'+q(bio)+'"')
out=sys.argv[1] if len(sys.argv)>1 else 'suite-webapp.html'
open(out,'w',encoding='utf-8').write(suite); print(out,len(suite)//1024,'KB')
