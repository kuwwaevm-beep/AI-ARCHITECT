"""Offline HTML fixtures for Playwright. Uses srcdoc so browser policy does not need network navigation."""
import html as htmlmod, os, re

def build_suite_test_html(client_root, pre):
    def read(name):
        with open(os.path.join(client_root, name), encoding='utf-8') as f: return f.read()
    shim = "try{const __ls=(window.top.__AIARCH_LS||(window.top.__AIARCH_LS={}));Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>__ls[k]??null,setItem:(k,v)=>{__ls[k]=String(v)},removeItem:k=>{delete __ls[k]},clear:()=>{Object.keys(__ls).forEach(k=>delete __ls[k])}}});}catch(e){}"
    inject = '<script>'+shim+pre+'</script>'
    arch = read('index.html')
    arch = re.sub(r'<script src="https?://[^\"]*"></script>', '', arch)
    arch = arch.replace('<script src="config.js"></script>', '<script>window.AIARCH_CONFIG={api:"https://api.test.uz"};</script>')
    arch = arch.replace('<script src="native-sensors.js"></script>', '')
    arch = arch.replace('window.onload = function () {', 'window.onload = function () { try{init3dsMaxEngine=function(){};rebuild3dsMaxScene=function(){};}catch(e){}')
    arch = arch.replace('<head>', '<head>'+inject, 1)
    bio = read('bio.html')
    bio = re.sub(r'<link rel="stylesheet" href="https?://unpkg[^\"]*">', '', bio)
    bio = re.sub(r'<script src="https?://unpkg[^\"]*"></script>', '', bio)
    bio = bio.replace('<head>', '<head>'+inject, 1)
    suite = read('suite.html')
    suite = suite.replace('src="index.html"', 'srcdoc="'+htmlmod.escape(arch, quote=True)+'"')
    suite = suite.replace('src="bio.html"', 'srcdoc="'+htmlmod.escape(bio, quote=True)+'"')
    suite = suite.replace('<head>', '<head><script>'+shim+pre+'</script>', 1)
    return suite
