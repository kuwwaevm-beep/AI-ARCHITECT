#!/usr/bin/env python3
"""Real OpenSeesPy smoke test; exits nonzero if the solver is unavailable or fails."""
import csv, json, math, pathlib, tempfile, sys
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'integrations' / 'seismic'))
from run_opensees import run

project = json.loads((ROOT / 'integrations' / 'examples' / 'project.example.json').read_text(encoding='utf-8'))
with tempfile.TemporaryDirectory() as tmp:
    tmp = pathlib.Path(tmp)
    motion = tmp / 'motion.csv'
    with motion.open('w', newline='', encoding='utf-8') as f:
        w = csv.writer(f); w.writerow(['time_s', 'acceleration_m_s2'])
        dt = 0.01
        for i in range(201):
            t = i * dt
            envelope = min(1.0, t / 0.15, (2.0 - t) / 0.2)
            a = 0.35 * max(0.0, envelope) * math.sin(2 * math.pi * 2.0 * t)
            w.writerow([f'{t:.8f}', f'{a:.10f}'])
    out = tmp / 'result.json'
    result = run(ROOT / 'integrations' / 'examples' / 'project.example.json', motion, out, 1)
    assert result['engine'] == 'OpenSeesPy'
    assert result['steps'] == 201
    assert result['max_translation_m'] > 0 and math.isfinite(result['max_translation_m'])
    assert out.is_file() and json.loads(out.read_text())['status'] == 'analysis-completed-needs-engineer-review'
    print('REAL OPENSEESPY SOLVER: PASS')
    print(f"steps={result['steps']}, dt={result['dt_s']:.5f}s, max_translation={result['max_translation_m']:.8g}m")
