# AI Architect 3D konturi -> zilzila bo'limiga O'ZGARISHSIZ uzatilishini tekshiradi.  python3 scripts/exact-e2e.py
import mimetypes, os, json, math
from playwright.sync_api import sync_playwright
from e2e_helpers import build_suite_test_html
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'client') + '/'
PRE = "window.tailwind={};const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:mk(),construct:()=>mk(),apply:()=>mk()});window.THREE=mk();"
# bio.html 3D qurilishini yozib oluvchi yengil THREE o'rniga qo'yiladigan stub
STUB = """(()=>{class O{constructor(){this.children=[];this.position={x:0,y:0,z:0,set(x,y,z){this.x=x;this.y=y;this.z=z}};this.rotation={x:0,y:0,z:0,set(x,y,z){this.x=x;this.y=y;this.z=z}}}add(o){this.children.push(o);return this}remove(o){this.children=this.children.filter(c=>c!==o)}}
window.__T={Group:O,Mesh:class extends O{constructor(g,m){super();this.geometry=g;this.material=m}},BoxGeometry:class{constructor(w,h,d){this.k='box';this.w=w;this.h=h;this.d=d}},
MeshStandardMaterial:class{constructor(o){Object.assign(this,o||{})}},Shape:class{constructor(){this.pts=[]}moveTo(x,y){this.pts.push([x,y])}lineTo(x,y){this.pts.push([x,y])}closePath(){}},
ExtrudeGeometry:class{constructor(s,o){this.k='extrude';this.shape=s;this.depth=o.depth}rotateX(){}},EllipseCurve:class{getPoints(){return []}},BufferGeometry:class{setFromPoints(){return this}},Line:class extends O{},LineBasicMaterial:class{},Vector3:class{}};})()"""
res = []
def ok(c, m): res.append(bool(c)); print(('  ✓ ' if c else '  ✗ ') + m)
def route(r):
    u = r.request.url
    if u.startswith('http://127.0.0.1:8765/'):
        f = u.split('http://127.0.0.1:8765/')[1].split('?')[0] or 'suite.html'
        h = open(ROOT + f, encoding='utf-8').read()
        if f == 'index.html': h = h.replace('window.onload = function () {', 'window.onload = function () { try{init3dsMaxEngine=function(){};rebuild3dsMaxScene=function(){};}catch(e){}')
        return r.fulfill(body=h, content_type=mimetypes.guess_type(f)[0] or 'text/html')
    r.abort()
def same(a, b, eps=1e-9): return len(a) == len(b) and all(abs(x - y) <= eps for p, q in zip(a, b) for x, y in zip(p, q))
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("AIARCH_CHROMIUM_PATH", "/usr/bin/chromium"), args=["--no-sandbox"]); pg = b.new_page(viewport={'width': 420, 'height': 850}); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e)))
    pg.route('**/*', lambda r: r.abort())
    pg.set_content(build_suite_test_html(ROOT, PRE)); pg.wait_for_timeout(1800)
    fa = pg.frames[1]; fb = pg.frames[2]
    bad = lambda: [e for e in errs if 'tailwind' not in e and 'appendChild' not in e]
    def sync(): pg.evaluate("Suite.sync()"); pg.wait_for_timeout(250)
    def exact_check(name):
        M = fa.evaluate("getSeismicModel()"); E = fb.evaluate("ExtPlan.state()")
        ok(E is not None and same(M['poly'], E['poly']) and same(M['outer'], E['outer']), name + ': AI Architect konturi == zilzila bo\'limi konturi (nuqtama-nuqta, o\'zgarishsiz)')
        ok(fb.evaluate("document.getElementById('b-shape').value") == 'ext' and fb.evaluate("document.getElementById('b-w').disabled"), name + ': zilzila bo\'limi shakli = AI Architect konturi, qo\'lda o\'zgartirib bo\'lmaydi')
        return M, E
    print('=== 1) Standart (variant A, 10×12) ===')
    ok(not bad(), 'yuklanishda JS xatosi yo\'q ' + str(bad()[:2]))
    M, E = exact_check('A')
    ok(abs(E['A'] - 120) < 1e-6 and abs(E['B'] - 10) < 1e-9 and abs(E['L'] - 12) < 1e-9, 'qavat maydoni %.4f m² (kutilgan 120), %.3f×%.3f' % (E['A'], E['B'], E['L']))
    print('=== 2) Variant C (L-shakl) ===')
    fa.evaluate("selectConceptVariant('C')"); pg.wait_for_timeout(500)
    M, E = exact_check('C'); t = M['t']; W, L = 10, 12; w1, l1 = W * .54, L * .54
    exp = W * L - (W - t - w1) * (L - t - l1)
    ok(len(M['poly']) == 6 and abs(E['A'] - exp) < 1e-6, 'L-kontur maydoni %.4f m² == analitik %.4f' % (E['A'], exp))
    old_box_area = W * L
    ok(abs(E['A'] - old_box_area) > 20, 'eski taxminiy hisob (to\'liq to\'rtburchak %d m²) emas — haqiqiy L maydoni ishlatilmoqda' % old_box_area)
    print('=== 3) Erkin chizilgan kontur (variant D, burchakli) ===')
    fa.evaluate("appState.customPoly=[[-5,-4],[5,-4],[5,0],[2,0],[2,4],[-5,4]];appState.variant='D';onDimensionsChanged&&onDimensionsChanged()"); pg.wait_for_timeout(500); sync()
    M, E = exact_check('D')
    ok(abs(E['A'] - 68) < 1e-6, 'erkin kontur maydoni %.4f m² == 68' % E['A'])
    rows = fb.evaluate("QuakeLab.sweep()")
    ok(len(rows) == 9 and all(math.isfinite(r['Vb']) and r['Vb'] >= 0 for r in rows) and rows[8]['Vb'] > rows[0]['Vb'] * 5, 'zilzila 1–9 ball hisobi shu kontur uchun ishladi: Vb %.0f -> %.0f kN' % (rows[0]['Vb'], rows[8]['Vb']))
    ok('AI Architect 3D konturi' in fb.evaluate("document.getElementById('ql-bld').textContent"), 'zilzila kartasi: ' + fb.evaluate("document.getElementById('ql-bld').textContent"))
    print('=== 4) 3D model aynan shu kontur bo\'yicha quriladi ===')
    fb.evaluate(STUB); fb.evaluate("window.__orig=window.THREE; window.THREE=window.__T; bldGroup=new THREE.Group(); build3DStructure();")
    info = fb.evaluate("""(()=>{const E=ExtPlan.state(),FL=+document.getElementById('b-fl').value;let walls=[],cols=0;
      bldGroup.children.forEach(g=>g.children.forEach(m=>{const k=m.geometry&&m.geometry.k; if(k==='box'&&Math.abs(m.geometry.d-E.t)<1e-9&&Math.abs(m.geometry.h-(+document.getElementById('b-h').value-0.35))<1e-9) walls.push([m.position.x,m.position.z,m.geometry.w]); }));
      bldGroup.children.forEach(g=>g.children.forEach(m=>{const k=m.geometry&&m.geometry.k; if(k==='box'&&Math.abs(m.geometry.w-colMmNow/1000)<1e-9&&Math.abs(m.geometry.d-colMmNow/1000)<1e-9) cols++;}));
      return {walls,cols,FL,edges:E.poly.length,ncols:E.cols.length,poly:E.poly}})()""")
    fb.evaluate("void (window.THREE=window.__orig)")
    n = info['edges']
    ok(len(info['walls']) == n * info['FL'], 'devorlar soni = %d qirra × %d qavat = %d' % (n, info['FL'], n * info['FL']))
    mids = sorted((round((info['poly'][i][0] + info['poly'][(i + 1) % n][0]) / 2, 6), round((info['poly'][i][1] + info['poly'][(i + 1) % n][1]) / 2, 6)) for i in range(n))
    w0 = sorted((round(w[0], 6), round(w[1], 6)) for w in info['walls'][:n]) if False else None
    first = sorted(set((round(w[0], 6), round(w[1], 6)) for w in info['walls']))
    ok(first == sorted(set(mids)), 'har bir devor AI Architect konturining qirrasi o\'rtasida turibdi')
    ok(info['cols'] == info['ncols'] * info['FL'], 'kolonnalar soni = %d × %d qavat' % (info['ncols'], info['FL']))
    print('=== 5) DXF / IFC eksport ===')
    fb.evaluate("window.__dl=null; dl=(n,t)=>{window.__dl={n,t}}"); fb.evaluate("exportDXF()"); dxf = fb.evaluate("__dl&&__dl.t") or ''
    ok(dxf.count('DEVOR') == n, 'DXF: %d devor chizig\'i (kontur qirralari)' % dxf.count('DEVOR'))
    fb.evaluate("window.__dl=null; exportIFC()"); ifc = fb.evaluate("__dl&&__dl.t") or ''
    ok(ifc.count('IFCWALL(') == n * info['FL'], 'IFC: %d devor (%d qirra × %d qavat)' % (ifc.count('IFCWALL('), n, info['FL']))
    print('=== 6) To\'g\'ridan-to\'g\'ri yo\'naltirish tugmasi ===')
    ok(fa.evaluate("document.getElementById('btnToQuake').style.display") == '', 'AI Architect 3D oynasida «🌋 Zilzila ballida sinash» tugmasi ko\'rinadi')
    pg.evaluate("Suite.show('arch')"); fa.evaluate("sendToQuake()"); pg.wait_for_timeout(800)
    ok(not pg.evaluate("document.getElementById('f-bio').classList.contains('off')") and fb.evaluate("document.getElementById('scr-3d').classList.contains('active')") and fb.evaluate("quakeActive"), 'tugma bosilganda 3D loyiha zilzila sinov oynasiga o\'tdi va silkinish yoqildi')
    print('=== 7) Qo\'lda tahrirlash va qayta ulanish ===')
    fb.evaluate("releaseExtPlan()"); sync()
    ok(not fb.evaluate("document.getElementById('b-w').disabled") and fb.evaluate("ExtPlan.active()") is False, 'qo\'lda tahrirlash: maydonlar ochildi, aniq kontur o\'chdi')
    fa.evaluate("appState.customPoly=[[-6,-4],[6,-4],[6,4],[-6,4]];onDimensionsChanged&&onDimensionsChanged()"); pg.wait_for_timeout(400); sync()
    ok(fb.evaluate("ExtPlan.active()") and abs(fb.evaluate("ExtPlan.state().A") - 96) < 1e-6, 'AI Architect konturi o\'zgarganda avtomatik qayta ulandi (96 m²)')
    print('=== 8) Ko\'p qavatli bino (9 qavat) ===')
    fa.evaluate("document.getElementById('inpFloors').value='9';document.getElementById('inpFloors').dispatchEvent(new Event('input',{bubbles:true}))"); pg.wait_for_timeout(500); sync()
    ok(fa.evaluate("appState.floors")==9 and fb.evaluate("document.getElementById('b-fl').value")=='9', '9 qavat kiritildi: AI Architect=%s, zilzila bo\'limi=%s' % (fa.evaluate("appState.floors"), fb.evaluate("document.getElementById('b-fl').value")))
    rows = fb.evaluate("QuakeLab.sweep()")
    ok(len(rows)==9 and all(math.isfinite(r['Vb']) and math.isfinite(r['T1']) and r['T1']>0 for r in rows), '9 qavatli bino uchun 1–9 ball hisobi: T1=%.2f s, Vb(8 ball)=%.0f kN' % (rows[7]['T1'], rows[7]['Vb']))
    fa.evaluate("document.getElementById('aiChatInput').value='uy 12x14 9 etajli'"); fa.evaluate("submitAIChat()"); pg.wait_for_timeout(1000)
    ok(fa.evaluate("appState.floors")==9 or fa.evaluate("appState.floors")>3, 'AI chat «9 etajli» -> %s qavat' % fa.evaluate("appState.floors"))
    fa.evaluate("document.getElementById('inpFloors').value='40';document.getElementById('inpFloors').dispatchEvent(new Event('input',{bubbles:true}))")
    ok(fa.evaluate("appState.floors")==30, 'yuqori chegara 30 qavat')
    ok(not bad(), 'butun jarayonda JS xatosi yo\'q ' + str(bad()[:3]))
    b.close()
print('NATIJA: %d/%d' % (sum(res), len(res)))
