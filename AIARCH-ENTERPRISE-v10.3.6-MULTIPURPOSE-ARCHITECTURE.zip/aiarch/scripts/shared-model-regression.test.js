'use strict';
// Static regression checks for the shared 2D/3D footprint and defensive DXF export.
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'client', 'index.html'), 'utf8');
const checks = [
  ['2D CAD obtains authoritative footprint from computeFootprint()', /function renderAutoCAD2D[\s\S]*?const FP = computeFootprint\(\)/.test(html)],
  ['2D floors/furniture are clipped to the shared inner footprint', /trace\(innerP\); ctx\.clip\(\)/.test(html)],
  ['2D exterior wall is drawn between outer and inner footprint polygons', /trace\(outerP\); trace\(innerP\)/.test(html)],
  ['DXF export validates polygon and floor model', /Array\.isArray\(P\.poly\).*P\.poly\.length < 3.*Array\.isArray\(P\.floors\)/s.test(html)],
  ['DXF export rejects non-finite and degenerate footprint edges', /P\.poly\.every\(finitePoint\).*Math\.hypot\([\s\S]*?< 0\.001/.test(html)],
  ['DXF export skips zero-length wall segments safely', /if \(len < 0\.001\) return; \/\/ skip degenerate wall/.test(html)],
  ['2D and 3D use same footprint function', /function computeFootprint\(\)/.test(html) && /const FP = computeFootprint\(\)/.test(html) && /function renderAutoCAD2D[\s\S]*?const FP = computeFootprint\(\)/.test(html)]
];
let failed = 0;
for (const [name, ok] of checks) { console.log(`${ok ? '✓' : '✗'} ${name}`); if (!ok) failed++; }
console.log(`\n${checks.length - failed}/${checks.length} shared-model regression checks passed`);
process.exit(failed ? 1 : 0);
