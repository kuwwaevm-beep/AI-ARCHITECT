import re,mimetypes,os,sys,json
from playwright.sync_api import sync_playwright
from e2e_helpers import build_suite_test_html
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','client')+'/'
PRE="window.tailwind={};const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:mk(),construct:()=>mk(),apply:()=>mk()});window.THREE=mk();"
res=[]
def ok(c,m): res.append(bool(c)); print(('  ✓ ' if c else '  ✗ ')+m)
def route(r):
    u=r.request.url
    if u.startswith('http://127.0.0.1:8765/'):
        f=u.split('http://127.0.0.1:8765/')[1].split('?')[0] or 'suite.html'
        h=open(ROOT+f,encoding='utf-8').read()
        if f=='index.html': h=h.replace('window.onload = function () {','window.onload = function () { try{init3dsMaxEngine=function(){};rebuild3dsMaxScene=function(){};}catch(e){}')
        return r.fulfill(body=h,content_type=mimetypes.guess_type(f)[0] or 'text/html')
    r.abort()
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get("AIARCH_CHROMIUM_PATH", "/usr/bin/chromium"), args=["--no-sandbox"]); pg=b.new_page(viewport={'width':420,'height':850}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.route('**/*',route); pg.add_init_script(PRE); pg.set_content(build_suite_test_html(ROOT, PRE)); pg.wait_for_timeout(1800)
    fa=pg.frames[1]; fb=pg.frames[2]
    bad=lambda: [e for e in errs if 'tailwind' not in e and 'appendChild' not in e]
    print('=== A) 1–9 ball sinov funksiyasi (v4.0) ===')
    ok(not bad(),'yuklanishda JS xatosi yo\'q '+str(bad()[:2]))
    rows=fb.evaluate("QuakeLab.sweep()")
    ok(len(rows)==9 and [r['ball'] for r in rows]==list(range(1,10)),'9 ta ball (1..9) hisoblandi')
    ok(all(rows[i]['pga']<=rows[i+1]['pga'] for i in range(8)) and rows[8]['pga']>rows[0]['pga'],'PGA ball bilan o\'sadi: %s -> %s g'%(rows[0]['pga'],rows[8]['pga']))
    ok(all(rows[i]['need']<=rows[i+1]['need'] or rows[i]['base']!=rows[i+1]['base'] for i in range(8)),'kerakli kolonna kesimi ball oshgani sari kamaymaydi: '+str([r['need'] for r in rows]))
    ok(rows[8]['Vb']>rows[0]['Vb']*5,'Vb 9 ballda 1 ballga nisbatan ancha katta: %.0f -> %.0f kN'%(rows[0]['Vb'],rows[8]['Vb']))
    # B) runAdvanced bilan moslik
    fb.evaluate("QuakeLab.setBall(null)")
    st=fb.evaluate("QuakeLab.state()"); txt=fb.evaluate("document.getElementById('dyn-box').innerText")
    vb=float(re.search(r'Vb = ([\d.]+) kN',txt).group(1))
    core=fb.evaluate("(()=>{const q=quakeInputs();return seisCore(geoState.seismicBall,q.soil,colMmNow,q.B,q.L,q.FL,q.H).Vb})()")
    ok(abs(vb-core)<1.0,'sof hisob (seisCore) asosiy runAdvanced bilan mos: %.1f vs %.1f kN'%(vb,core))
    print('=== B) qo\'lda ball va loyiha o\'zgarishlari ===')
    out={}
    for n in (1,5,9):
        fb.evaluate(f"QuakeLab.setBall({n})")
        out[n]=fb.evaluate("({ball:geoState.seismicBall,kp:document.getElementById('kp-seis').innerText,smeta:document.getElementById('smeta-total-uzs').innerText,col:colMmNow,btn:document.getElementById('btn-quake-sim').textContent})")
        print('   ',n,out[n])
    ok(all(out[n]['ball']==n for n in out) and 'Ball' in out[1]['kp'] and out[9]['kp'].startswith('9'),'ball qo\'lda 1/5/9 ga o\'rnatildi, KPI yangilandi')
    ok(out[1]['smeta']!=out[9]['smeta'],'smeta ballga qarab o\'zgardi: %s -> %s'%(out[1]['smeta'],out[9]['smeta']))
    ok(out[9]['col']>=out[1]['col'],'kolonna kesimi: %d -> %d mm'%(out[1]['col'],out[9]['col']))
    ok('9' in out[9]['btn'],'3D tugma yozuvi: '+out[9]['btn'])
    fb.evaluate("QuakeLab.setBall(null)"); ok(fb.evaluate("geoState.seismicBall==geoState.regionBall"),'AUTO hudud ballini qaytardi')
    print('=== C) AI Architect -> zilzila sinovi (shu bino) ===')
    pg.wait_for_timeout(300)
    v0=fb.evaluate("QuakeLab.sweep()[7].Vb")
    fa.evaluate("document.getElementById('aiChatInput').value='uy 14x16 3 qavat'"); fa.evaluate("submitAIChat()"); pg.wait_for_timeout(1200)
    q=fb.evaluate("quakeInputs()"); ok((q['B'],q['L'],q['FL'])==(14,16,3),'yangi loyiha v4.0 ga o\'tdi: %s'%q)
    ok(fb.evaluate("document.getElementById('ql-bld').textContent").startswith('14×16'),'zilzila sinovi kartasi shu binoni ko\'rsatdi: '+fb.evaluate("document.getElementById('ql-bld').textContent"))
    v1=fb.evaluate("QuakeLab.sweep()[7].Vb"); ok(abs(v1-v0)>1,'sinov natijalari yangi bino uchun qayta hisoblandi (8 ball Vb %.0f -> %.0f)'%(v0,v1))
    ok(fb.evaluate("document.querySelectorAll('#ql-table tbody tr').length")==9,'jadvalda 9 qator')
    ok('🌋 1–9' in pg.evaluate("document.getElementById('stat').textContent"),'holat qatori: '+pg.evaluate("document.getElementById('stat').textContent")[-95:])
    pg.evaluate("Suite.toQuake()"); pg.wait_for_timeout(700)
    ok(fb.evaluate("document.getElementById('scr-3d').classList.contains('active')") and fb.evaluate("quakeActive"),'«🌋 Zilzila 1–9» tugmasi 3D sinov oynasini ochdi, silkinish yoqildi')
    ok(fb.evaluate("document.querySelectorAll('#quake-bar .chip').length")==10,'3D oynada AUTO + 1..9 tugmalari bor')
    fb.evaluate("QuakeLab.run()"); pg.wait_for_timeout(6200)
    s1=fb.evaluate("QuakeLab.state().ball"); fb.evaluate("QuakeLab.run()")
    ok(s1>=3,'1→9 ketma-ket sinov ishlayapti (6 s dan keyin ball=%s)'%s1)
    ok(not bad(),'butun jarayonda JS xatosi yo\'q '+str(bad()[:2]))
    pg.screenshot(path='/tmp/q.png'); b.close()
print('NATIJA: %d/%d'%(sum(res),len(res)))
