# Mijoz kodining brauzer testi (Playwright kerak: pip install playwright && playwright install chromium)
# Ishlatish: python3 scripts/client-e2e.py   — CDN kutubxonalar (Tailwind/Three) soxtalashtiriladi, tarmoq yopiq.
from playwright.sync_api import sync_playwright
import re, json
import os
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..')
html=open(os.path.join(ROOT,'client','index.html'),encoding='utf-8').read()
html=re.sub(r'<script src="https?://[^"]*"></script>','',html)
html=html.replace('<script src="config.js"></script>','<script>window.AIARCH_CONFIG={api:"https://api.test.uz"};</script>').replace('<script src="native-sensors.js"></script>','')
html=html.replace('window.onload = function () {','window.onload = function () { try{init3dsMaxEngine=function(){};rebuild3dsMaxScene=function(){};}catch(e){}')
PRE='''try{const __ls={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>__ls[k]??null,setItem:(k,v)=>{__ls[k]=String(v)},removeItem:k=>{delete __ls[k]},clear:()=>{Object.keys(__ls).forEach(k=>delete __ls[k])}}});}catch(e){}
window.tailwind={};window.__calls=[];window.__ws=[];
window.WebSocket=function(u){window.__ws.push({url:u,sent:[]});const me=window.__ws[window.__ws.length-1];this.send=m=>me.sent.push(JSON.parse(m));this.close=()=>{};setTimeout(()=>this.onopen&&this.onopen(),0);me.sock=this;};
window.fetch=async(u,o)=>{window.__calls.push({u,o});const p=u.replace('https://api.test.uz','');
 if(p==='/api/ai/status') return {ok:true,json:async()=>({configured:true,provider:'anthropic'})};
  if(p==='/api/ai') return {ok:true,json:async()=>({text:'Bajarildi\\n```json\\n{"set":{"houseW":11}}\\n```'})};
 if(p==='/api/projects') return {ok:true,json:async()=>[{id:'11111111-1111-4111-8111-111111111111',title:'<img src=x onerror=window.__xss=1>',role:'client'}]};
 if(p.startsWith('/api/projects/')) return {ok:true,json:async()=>({id:'x',title:'t',role:window.__role||'client',data:{v:2,inputs:{inpHouseW:"9"},variant:'A',extras:{}}})};
 return {ok:false,json:async()=>({error:'yoq'})};};'''
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get("AIARCH_CHROMIUM_PATH", "/usr/bin/chromium"), args=["--no-sandbox"]); res=[]
    def ok(c,m): res.append((bool(c),m)); print(('  ✓ ' if c else '  ✗ ')+m)
    def page(init='',blocked=False):
        pg=b.new_page(viewport={'width':390,'height':800}); errs=[]; pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.route('**/*',lambda r:r.abort() if r.request.url.startswith('http') else r.continue_())
        test_html=html.replace('<head>', '<head><script>'+PRE+init+'</script>', 1)
        pg.set_content(test_html)
        pg.wait_for_timeout(800); return pg,errs
    # A) oflayn rejim
    pg,errs=page(); 
    ok(not [e for e in errs if 'tailwind' not in e],'yuklanishda JS xatosi yo‘q: '+str([e for e in errs if 'tailwind' not in e]))
    ok('Oflayn' in pg.inner_text('#aiKeyState'),'tokensiz: oflayn rejim')
    pg.evaluate("document.getElementById('aiChatInput').value='uy 13x15 3 qavat'"); pg.evaluate("submitAIChat()"); pg.wait_for_timeout(300)
    ok(pg.evaluate("[appState.houseW,appState.houseL,appState.floors]")==[13,15,3],'oflayn AI buyrug‘i ishladi')
    ok(pg.evaluate("window.__calls.length")==0,'oflayn rejimda tarmoq so‘rovi yo‘q')
    # B) proxy rejimi (token bor) — kalit yuborilmaydi
    pg,errs=page("localStorage.setItem('aiarch_token','T1');")
    ok('AI server tayyor' in pg.inner_text('#aiKeyState'),'tokenli: server AI holati tasdiqlandi')
    pg.evaluate("document.getElementById('aiChatInput').value='uyni kattalashtir'"); pg.evaluate("submitAIChat()"); pg.wait_for_timeout(500)
    c=pg.evaluate("window.__calls"); ai=[x for x in c if x['u'].endswith('/api/ai')]
    ok(len(ai)==1,'AI so‘rovi o‘z serveriga ketdi'); 
    if ai:
        h=ai[0]['o']['headers']; body=json.loads(ai[0]['o']['body'])
        ok('x-api-key' not in {k.lower() for k in h},'sarlavhada API kalit yo‘q'); ok(h['Authorization']=='Bearer T1','JWT yuborildi')
        ok('system' not in body and 'state' in body and body['messages'][0]['role']=='user','tanada system yo‘q, faqat state+messages')
        ok(not any('anthropic.com' in x['u'] for x in c),'api.anthropic.com ga to‘g‘ridan-to‘g‘ri so‘rov yo‘q')
    ok(pg.evaluate("appState.houseW")==11,'AI javobidagi o‘zgarish qo‘llandi')
    ok('```' not in pg.inner_text('#aiChatList'),'JSON blok foydalanuvchiga ko‘rsatilmadi')
    # C) claude.ai (sample) rejimi
    pg,errs=page("window.claude={use:async n=>n==='sample'?Object.assign(async(m)=>{window.__sm=m;return{text:'ok\\n```json\\n{\"set\":{\"houseW\":12}}\\n```'}},{}):null};")
    ok('claude.ai' in pg.inner_text('#aiKeyState'),'sample rejimi aniqlandi')
    ok(pg.evaluate("document.querySelector('button[onclick=\"openCloud()\"]')")is None,'claude.ai ichida bulut tugmasi yo‘q')
    ok(pg.evaluate("!!document.querySelector('button[onclick=\"downloadIFC()\"]')"),'IFC tugmasi bor')
    pg.evaluate("document.getElementById('aiChatInput').value='salom'"); pg.evaluate("submitAIChat()"); pg.wait_for_timeout(500)
    ok(pg.evaluate("window.__sm[0].content.startsWith('Sen ')"),'sample: ko‘rsatma birinchi xabarga qo‘shildi'); ok(pg.evaluate("appState.houseW")==12,'sample javobi qo‘llandi')
    # D) bulut: XSS, rol, WS auth
    pg,errs=page("localStorage.setItem('aiarch_token','T1');window.__role='client';")
    pg.evaluate("openCloud()"); pg.wait_for_timeout(500)
    ok(pg.evaluate("!window.__xss")and pg.evaluate("document.querySelector('#cList img')")is None,'loyiha nomidagi HTML ishlamadi (XSS yo‘q)')
    ok('&lt;img' in pg.evaluate("document.getElementById('cList').innerHTML"),'nom matn sifatida ekranlandi')
    pg.evaluate("document.querySelector('#cList [data-open]').click()"); pg.wait_for_timeout(500)
    ok(pg.evaluate("document.getElementById('inpHouseW').disabled")is True,'buyurtmachi: maydonlar bloklandi')
    ws=pg.evaluate("window.__ws"); ok(len(ws)==1 and ws[0]['url']=='wss://api.test.uz/ws','WS manzili token siz: '+(ws[0]['url'] if ws else ''))
    ok(ws and ws[0]['sent'] and ws[0]['sent'][0]['type']=='auth' and ws[0]['sent'][0]['token']=='T1','token birinchi xabarda yuborildi')
    pg.evaluate("document.getElementById('inpHouseW').disabled=false;document.getElementById('inpHouseW').value=20;saveProject()"); pg.wait_for_timeout(700)
    ok(not any(m['type']=='state' for m in pg.evaluate("window.__ws[0].sent")),'buyurtmachi holat yubormaydi')
    pg.evaluate("applyAIActions({set:{houseW:30}})"); ok(pg.evaluate("applyAIActions({set:{houseW:30}})")is False,'ko‘rish rejimida AI loyihani o‘zgartirmaydi')
    # F) xotira bloklangan (private rejim / ba'zi webview) — ilova baribir ishlaydi
    pg,errs=page(blocked=True); real=[e for e in errs if 'tailwind' not in e and 'localStorage' not in e]
    ok(not real,'xotira bloklanganda ham modul yuklanadi: '+str(real)); ok(pg.evaluate("typeof CLOUD")=='object','CLOUD yaratilgan')
    ok(pg.evaluate("aiMode()")=='local','xotirasiz: oflayn rejim, xatosiz')
    # E) mobil: server manzili sozlanmasa so‘rov yuborilmaydi
    pg,errs=page("window.Capacitor={isNativePlatform:()=>true};localStorage.setItem('aiarch_token','T1');")
    pg.evaluate("window.AIARCH_CONFIG.api=''"); 
    r=pg.evaluate("(async()=>{CLOUD.api='';try{await cApi('/projects');return 'no-error'}catch(e){return e.message}})()")
    ok('sozlanmagan' in r,'mobilda api yo‘q bo‘lsa — aniq xato, noto‘g‘ri host ga so‘rov yo‘q')
    ok(pg.evaluate("cValidApi('http://evil.com')")is False and pg.evaluate("cValidApi('https://api.uz')")is True and pg.evaluate("cValidApi('javascript:alert(1)')")is False,'server manzili tekshiruvi (https majburiy)')
    print('\nJAMI:',sum(1 for r in res if r[0]),'/',len(res)); 

import sys; sys.exit(0 if all(r[0] for r in res) else 1)
