'use strict';
// Regression checks for the 2D/3D viewport fixes. These are static contracts;
// browser/WebGL rendering still requires a real interactive browser environment.
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'client', 'index.html'), 'utf8');
const checks = [
  ['2D canvas scales proportionally on small screens', /canvas\.style\.width = '100%'/.test(html) && /canvas\.style\.height = 'auto'/.test(html) && /canvas\.style\.aspectRatio/.test(html)],
  ['2D canvas caps device-pixel ratio to limit memory use', /Math\.min\(window\.devicePixelRatio \|\| 1, 2\)/.test(html)],
  ['2D wall thickness matches all four wall types', /brick_38: 0\.38, brick_25: 0\.25, gazoblok_30: 0\.30, shlakoblok_40: 0\.40/.test(html)],
  ['3D viewport ignores zero-sized hidden panels', /if \(width < 2 \|\| height < 2\) return/.test(html)],
  ['3D camera fits generated model bounds', /new THREE\.Box3\(\)\.setFromObject\(rootArchGroup\)/.test(html) && /function setCameraPreset\(mode\)/.test(html)],
  ['3D camera supports larger projects', /orbit3D\.maxDistance = 300/.test(html)],
  ['3D rebuild disposes replaced geometries and materials', /geometries\.forEach\(g => g\.dispose\(\)\)/.test(html) && /materials\.forEach\(m => m\.dispose\(\)\)/.test(html)]
];
let failed = 0;
for (const [name, ok] of checks) {
  console.log(`${ok ? '✓' : '✗'} ${name}`);
  if (!ok) failed++;
}
console.log(`\n${checks.length - failed}/${checks.length} viewport regression checks passed`);
process.exit(failed ? 1 : 0);
