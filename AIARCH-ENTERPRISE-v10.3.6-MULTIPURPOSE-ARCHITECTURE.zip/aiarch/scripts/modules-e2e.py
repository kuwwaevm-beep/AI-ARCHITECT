# Yangi modullar (Kadastr, Ustalar, Ta'minot, Ensiklopediya) va Avtonom Agent — hisob-kitob aniqligi.  python3 scripts/modules-e2e.py
import mimetypes, os, math
from playwright.sync_api import sync_playwright
from e2e_helpers import build_suite_test_html
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'client') + '/'
PRE = "window.tailwind={};const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:mk(),construct:()=>mk(),apply:()=>mk()});window.THREE=mk();"
res = []
def ok(c, m): res.append(bool(c)); print(('  ✓ ' if c else '  ✗ ') + m)
def route(r):
    u = r.request.url
    if u.startswith('http://127.0.0.1:8765/'):
        f = u.split('http://127.0.0.1:8765/')[1].split('?')[0] or 'suite.html'
        h = open(ROOT + f, encoding='utf-8').read()
        if f == 'index.html': h = h.replace('window.onload = function () {', 'window.onload = function () { try{init3dsMaxEngine=function(){};rebuild3dsMaxScene=function(){};}catch(e){}')
        return r.fulfill(body=h, content_type=mimetypes.guess_type(f)[0] or 'text/html')
    r.abort()
with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get("AIARCH_CHROMIUM_PATH", "/usr/bin/chromium"), args=["--no-sandbox"]); ctx = b.new_context(viewport={'width': 420, 'height': 850}); pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.route('**/*', lambda r: r.abort())
    pg.set_content(build_suite_test_html(ROOT, PRE)); pg.wait_for_timeout(1800)
    pg.evaluate("localStorage.clear()")
    ev = pg.evaluate
    # --- Armatura: standart jadval (GOST 5781) bilan solishtirish
    ref = {6: .222, 8: .395, 10: .617, 12: .888, 14: 1.21, 16: 1.578, 18: 1.998, 20: 2.466, 22: 2.984, 25: 3.853, 28: 4.834, 32: 6.313, 36: 7.990, 40: 9.865}
    got = ev("Object.fromEntries(Suite.calc.REBAR_D.map(d=>[d,Suite.calc.rebarKgM(d)]))")
    ok(all(abs(got[str(d)] - v) < 0.02 * v + 0.003 for d, v in ref.items()), 'armatura kg/m: 14 ta diametr GOST jadvaliga mos (≤2%)')
    # --- Beton: massa balansi va monotonlik
    C = ev("Suite.calc.CONC"); ks = list(C)
    ok(all(2250 <= sum(v) <= 2450 for v in C.values()), 'beton: har bir markada 1 m³ massasi 2250–2450 kg')
    ok(all(C[ks[i]][0] < C[ks[i + 1]][0] for i in range(len(ks) - 1)) and ks[0] == 'M100' and ks[-1] == 'M600', 'beton: M100→M600, sement miqdori o‘sib boradi')
    # --- Kadastr
    r = ev("Suite.calc.calcPlot([[0,0],[20,0],[20,30],[0,30]],10,12)")
    ok(abs(r['area'] - 600) < 1e-9 and abs(r['sotix'] - 6) < 1e-9, 'kadastr: 20×30 m = 600 m² = 6 sotix')
    ok(ev("Math.abs(Suite.calc.polyA([[0,0],[10,0],[0,10]])-50)<1e-9"), 'kadastr: uchburchak (Gauss formulasi) = 50 m²')
    ok(r['fitsW'] and r['fitsL'] and not ev("Suite.calc.calcPlot([[0,0],[8,0],[8,8],[0,8]],10,12).fitsW"), 'kadastr: chekinish tekshiruvi (sig‘adi / sig‘maydi)')
    pg.evaluate("Suite.dock('kad')"); pg.wait_for_timeout(250)
    t = pg.inner_text('#np'); ok('6.00 sotix' in t and '0/8' in t, 'kadastr ekrani: 6.00 sotix, treker 0/8')
    pg.check('[data-doc="0"]'); pg.wait_for_timeout(200); ok('1/8 (13%)' in pg.inner_text('#np'), 'kadastr: hujjat belgilanganda 1/8 (13%)')
    pg.fill('[data-px="1"]', '40'); pg.dispatch_event('[data-px="1"]', 'change'); pg.wait_for_timeout(200)
    ok(ev("Suite.state().plot[1][0]") == 40 and 'sotix' in pg.inner_text('#np'), 'kadastr: koordinata o‘zgarsa qayta hisoblanadi')
    # --- Kafelchi
    room = dict(w=2.5, l=3, h=2.6, door=1.8); tile = dict(w=30, h=60, j=2, rate=60000)
    t = ev("Suite.calc.calcTiles({w:2.5,l:3,h:2.6,door:1.8},{w:30,h:60,j:2,rate:60000})")
    tw, th = .302, .602; area = 2 * (2.5 + 3) * 2.6 - 1.8
    ok(abs(t['area'] - area) < 1e-9 and t['n'] == math.ceil(area / (tw * th) * 1.1), f'kafelchi: yuza {area:.2f} m², buyurtma {t["n"]} dona (mustaqil hisob bilan teng)')
    rows = math.floor(2.6 / th); full = sum(math.floor(L / tw) * rows for L in (2.5, 3, 2.5, 3))
    ok(t['full'] == full and t['glueBags'] == math.ceil(area * 5 / 25) and t['pay'] == round(area * 60000), f'kafelchi: butun {full}, yelim {t["glueBags"]} qop, ish haqi {t["pay"]}')
    pg.evaluate("Suite.dock('ust')"); pg.wait_for_timeout(200); pg.select_option('#uT', 'kafel'); pg.click('#kGo'); pg.wait_for_timeout(200)
    ok('Butun kafel' in pg.inner_text('#np') and 'qop' in pg.inner_text('#np'), 'ustalar ekrani: kafelchi naryadi')
    pg.select_option('#uT', 'gisht'); pg.wait_for_timeout(200); ok('dona' in pg.inner_text('#np') and 'Armatura setka' in pg.inner_text('#np'), 'ustalar ekrani: g‘isht teruvchi naryadi')
    # --- G'isht
    m = {'poly': [[-5, -6], [5, -6], [5, 6], [-5, 6]], 'floors': 2, 'H': 3.2}
    g = ev("Suite.calc.calcBrick({poly:[[-5,-6],[5,-6],[5,6],[-5,6]],floors:2,H:3.2},'brick_38')")
    area = 44 * 3.2 * 2 * .85
    ok(abs(g['per'] - 44) < 1e-9 and abs(g['area'] - area) < 1e-6 and g['pcs'] == math.ceil(area * 153) and g['rows'] == math.ceil(3200 / 77), f'g‘isht: perimetr 44 m, {g["pcs"]} dona, {g["rows"]} qator')
    # --- Ta'minot
    L = ev("Suite.calc.calcLogistics({poly:[[-5,-6],[5,-6],[5,6],[-5,6]],outer:[[-5,-6],[5,-6],[5,6],[-5,6]]},1.2)")
    exc = 11 * 13 * 1.2
    ok(abs(L['exc'] - exc) < 1e-9 and L['haul'] == math.ceil(exc * 1.25 / 10) and L['mixer'] == math.ceil(L['conc'] / 7), f'ta‘minot: {exc:.0f} m³ tuproq → {L["haul"]} reys KamAZ, {L["mixer"]} reys mikser')
    pg.evaluate("Suite.dock('tam')"); pg.wait_for_timeout(200)
    pg.fill('[data-f="2"]', '999'); pg.dispatch_event('[data-f="2"]', 'change'); pg.wait_for_timeout(200)
    ok('⚠' in pg.inner_text('#np') and ev("Suite.state().flow['2']") == 999, 'ta‘minot: kirim-chiqim og‘ishi >5% ogohlantirish')
    # --- Ensiklopediya
    pg.evaluate("Suite.dock('ens')"); pg.wait_for_timeout(200)
    ok('M600' in pg.inner_text('#np') and '1.578' in pg.inner_text('#np'), 'ensiklopediya: retseptlar va ∅16=1.578 kg/m ko‘rinadi')
    pg.fill('#eQ', 'zina'); pg.wait_for_timeout(200); s = pg.inner_text('#eS'); ok('Zina' in s and 'septik' not in s.lower(), 'ensiklopediya: SHNQ qidiruv («zina») filtrlaydi')
    pg.fill('#eQ', '<img src=x onerror=window.__x=1>'); pg.wait_for_timeout(200); ok(ev("!window.__x") and pg.locator('#np img').count() == 0, 'ensiklopediya: qidiruvda XSS ekranlangan')
    # --- Agent
    mm = ev("Suite.calc.MASTER('Qashqadaryo iqlimiga mos, 6 sotix yerda, 2 qavatli, 6 xonali, yerto‘lasi bor, 8 ballik zilzilaga chidaydigan g‘ishtli uy')")
    ok(mm['reg'] == 'qashqadaryo' and mm['sotix'] == 6 and mm['floors'] == 2 and mm['rooms'] == 6 and mm['ball'] == 8 and mm['basement'] and mm['brick'], 'agent: buyruqdan hudud/sotix/qavat/xona/ball/yerto‘la/g‘isht ajratildi')
    pg.click('#t-agent'); pg.wait_for_timeout(200)
    pg.fill('#agT', 'Qashqadaryo, 6 sotix, 2 qavatli, 6 xonali, yerto‘lali, 8 ballik zilzilaga chidamli g‘ishtli uy'); pg.click('#agGo'); pg.wait_for_timeout(900)
    lg = ev("Suite.state().agent"); names = [x[0] for x in lg]
    ok(names == ['AI-Geolog', 'AI-Arxitektor', 'AI-Dizayner', 'AI-Konstruktor', 'AI-Muhandis (MEP)', 'AI-Smetachi', 'AI-Ekspert'], 'agent: 7 ta mutaxassis aynan ketma-ketlikda ishladi')
    ok('45' in lg[0][1] and '-15' in lg[0][1] and '0.8' in lg[0][1] and '8 ball' in lg[0][1], 'agent: Geolog +45/−15 °C, 0.8 m, 8 ball')
    fa = pg.frames[1]
    ok(fa.evaluate("appState.floors") == 2 and fa.evaluate("appState.wallType") == 'brick_38', 'agent: AI Architect loyihasiga haqiqatan qo‘llandi (2 qavat, g‘isht)')
    ok(ev("Suite.mepCollisions().length") == 0 and ev("Suite.state().mep.length") == 2, 'agent: MEP trassalari kolliziyasiz')
    ok(not any('⚠' in x[1] for x in lg), 'agent: hech bir bosqichda xato yo‘q ' + str([x for x in lg if '⚠' in x[1]]))
    ok('AI-Ekspert' in pg.inner_text('#agL'), 'agent: natija ekranda ko‘rinadi')
    bad = [e for e in errs if 'tailwind' not in e and 'appendChild' not in e and 'L is not' not in e]
    ok(not bad, 'JS xatolari yo‘q ' + str(bad[:3]))
    b.close()
print(f'\n{sum(res)}/{len(res)}'); raise SystemExit(0 if all(res) else 1)
