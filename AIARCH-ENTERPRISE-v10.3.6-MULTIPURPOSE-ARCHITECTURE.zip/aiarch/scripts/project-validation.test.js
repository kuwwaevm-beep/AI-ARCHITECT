'use strict';
// Focused regression tests for imported/shared/local project data.
const fs = require('fs');
const vm = require('vm');
const assert = require('node:assert/strict');
const html = fs.readFileSync(require('node:path').join(__dirname, '..', 'client', 'index.html'), 'utf8');
const match = html.match(/function validateProjectData\(d\) \{[\s\S]*?\n\}\nfunction applyProject\(d\)/);
assert.ok(match, 'validateProjectData must exist before applyProject');
const source = match[0].replace(/\nfunction applyProject\(d\)$/, '');
const ctx = {
  selfIntersects: poly => {
    // Basic segment intersection checker sufficient for regression fixtures.
    const cross = (a,b,c) => (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]);
    const hit = (a,b,c,d) => cross(a,b,c)*cross(a,b,d)<0 && cross(c,d,a)*cross(c,d,b)<0;
    for (let i=0;i<poly.length;i++) for (let j=i+1;j<poly.length;j++) {
      if (Math.abs(i-j)<=1 || (i===0 && j===poly.length-1)) continue;
      if (hit(poly[i],poly[(i+1)%poly.length],poly[j],poly[(j+1)%poly.length])) return true;
    }
    return false;
  },
  appState: { prices: { brick: 1000, cement: 5000 } },
  EXTRA_DEFS: [['trees'], ['flowers'], ['lamps']]
};
vm.createContext(ctx);
vm.runInContext(source, ctx);
const valid = {v:2, inputs:{inpLandW:'16',inpLandL:'22',inpHouseW:'10',inpHouseL:'12',inpFloors:'2',inpCeilingH:'3.2',inpRooms:'6',inpFoundDepth:'0.9',inpPlinthH:'0.5',inpWinCount:'10',inpDoorCount:'8'}, variant:'A', extras:{trees:true}, customPoly:null, landPoly:null, prices:{brick:1200}, priceDate:'2026-10-27'};
assert.equal(ctx.validateProjectData(valid), true, 'valid saved project is accepted');
assert.equal(ctx.validateProjectData({...valid, inputs:{...valid.inputs, inpHouseW:'999999'} }), false, 'out-of-range dimensions are rejected');
assert.equal(ctx.validateProjectData({...valid, variant:'<script>'}), false, 'invalid variant is rejected');
assert.equal(ctx.validateProjectData({...valid, extras:{unknown:true}}), false, 'unknown extras are rejected');
assert.equal(ctx.validateProjectData({...valid, prices:{brick:-1}}), false, 'negative prices are rejected');
assert.equal(ctx.validateProjectData({...valid, customPoly:[[0,0],[5,5],[0,5],[5,0]]}), false, 'self-intersecting custom polygon is rejected');
assert.equal(ctx.validateProjectData({...valid, customPoly:[[0,0],[5,0],[5,5],[0,5]]}), true, 'valid custom polygon is accepted');
console.log('Project validation: 7/7 passed');
