import re,mimetypes,os
from playwright.sync_api import sync_playwright
from e2e_helpers import build_suite_test_html
import os
ROOT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','client')+'/'
PRE="window.tailwind={};const mk=()=>new Proxy(function(){},{get:(t,k)=>k===Symbol.toPrimitive?()=>0:mk(),construct:()=>mk(),apply:()=>mk()});window.THREE=mk();"
res=[]
def ok(c,m): res.append(bool(c)); print(('  ✓ ' if c else '  ✗ ')+m)
def route(r):
    u=r.request.url
    if u.startswith('http://127.0.0.1:8765/'):
        f=u.split('http://127.0.0.1:8765/')[1].split('?')[0] or 'suite.html'
        h=open(ROOT+f,encoding='utf-8').read() if f.endswith('.html') else open(ROOT+f,encoding='utf-8').read()
        if f=='index.html':
            h=h.replace('window.onload = function () {','window.onload = function () { try{init3dsMaxEngine=function(){};rebuild3dsMaxScene=function(){};}catch(e){}')
        return r.fulfill(body=h,content_type=mimetypes.guess_type(f)[0] or 'text/html')
    r.abort()
with sync_playwright() as p:
    b=p.chromium.launch(executable_path=os.environ.get("AIARCH_CHROMIUM_PATH", "/usr/bin/chromium"), args=["--no-sandbox"]); pg=b.new_page(viewport={'width':420,'height':850}); errs=[]
    pg.on('pageerror',lambda e:errs.append(str(e)))
    for fr in []: pass
    pg.route('**/*',route); pg.add_init_script(PRE)
    pg.set_content(build_suite_test_html(ROOT, PRE)); pg.wait_for_timeout(1800)
    A=lambda js: pg.frame_locator('#f-arch').locator('body').evaluate if False else None
    fa=pg.frames[1]; fb=pg.frames[2]
    bad=lambda: [e for e in errs if 'tailwind' not in e and 'L is not' not in e]
    print('=== BOSQICH 2: ko\'prik (sinxronizatsiya) ===')
    ok(not bad(),'ikkala iframe yuklanganda JS xatosi yo\'q: '+str(bad()[:3]))
    ok(pg.evaluate("Suite.ready.arch&&Suite.ready.bio"),'ikkala ilova tayyor, ko\'prik ulandi')
    ok(fa.evaluate("typeof appState")=='object' and fb.evaluate("typeof geoState")=='object','global nomlar alohida (appState / geoState to\'qnashmaydi)')
    ok(fa.evaluate("typeof geoState")=='undefined' and fb.evaluate("typeof appState")=='undefined','bir-birining o\'zgaruvchisini ko\'rmaydi')
    # qo'lda o'zgartirish
    fa.evaluate("document.getElementById('inpHouseW').value='13';document.getElementById('inpHouseW').dispatchEvent(new Event('input',{bubbles:true}));")
    pg.wait_for_timeout(500)
    v=fb.evaluate("[b_w=document.getElementById('b-w').value,document.getElementById('b-l').value,document.getElementById('b-fl').value,document.getElementById('b-h').value,document.getElementById('b-shape').value]")
    ok(v[0]=='13','inpHouseW=13 -> b-w='+v[0])
    fa.evaluate("document.getElementById('inpFloors').value='3';document.getElementById('inpFloors').dispatchEvent(new Event('input',{bubbles:true}));document.getElementById('inpCeilingH').value='3.6';document.getElementById('inpCeilingH').dispatchEvent(new Event('input',{bubbles:true}));")
    pg.wait_for_timeout(500)
    v=fb.evaluate("[document.getElementById('b-fl').value,document.getElementById('b-h').value]")
    ok(v==['3','3.6'],'qavat/balandlik -> b-fl, b-h = '+str(v))
    fa.evaluate("selectConceptVariant('C')"); pg.wait_for_timeout(500)
    ok(fb.evaluate("document.getElementById('b-shape').value")=='ext' and fb.evaluate("ExtPlan.state().poly.length")==6,'variant C -> aniq L-kontur (6 burchak) o\'zgarishsiz uzatildi')
    fa.evaluate("selectConceptVariant('A')"); pg.wait_for_timeout(400)
    ok(fb.evaluate("document.getElementById('b-shape').value")=='ext' and fb.evaluate("ExtPlan.state().poly.length")==4,'variant A -> aniq to\'rtburchak kontur (4 burchak)')
    print('=== BOSQICH 3: AI chat -> 4-bo\'lim (Smeta) ===')
    pg.evaluate("Suite.show('bio')"); pg.evaluate("Suite.toDesign()"); pg.wait_for_timeout(500)
    s0=fb.evaluate("document.getElementById('smeta-total-uzs').innerText")
    ok(fb.evaluate("document.getElementById('scr-design').classList.contains('active')"),'"→ Loyiha/Smeta" tugmasi 4-bo\'limni ochdi')
    pg.evaluate("Suite.show('arch')")
    fa.evaluate("document.getElementById('aiChatInput').value='uy 12x14 2 qavat'"); fa.evaluate("submitAIChat()"); pg.wait_for_timeout(900)
    st=fa.evaluate("[appState.houseW,appState.houseL,appState.floors]")
    ok(st==[12,14,2],'AI chat buyrug\'i AI Architect holatini yangiladi '+str(st))
    v=fb.evaluate("[document.getElementById('b-w').value,document.getElementById('b-l').value,document.getElementById('b-fl').value]")
    ok(v==['12','14','2'],'AI chat -> v4.0 inputlari '+str(v))
    pg.evaluate("Suite.toDesign()"); pg.wait_for_timeout(500)
    s1=fb.evaluate("document.getElementById('smeta-total-uzs').innerText"); area=fb.evaluate("document.getElementById('lbl-b-area').innerText")
    ok(s1!=s0 and s1!='0 so\'m','Smeta yangilandi: '+s0+' -> '+s1+' | maydon '+area)
    ok(not bad(),'butun jarayonda JS xatosi yo\'q: '+str(bad()[:3]))
    hid=pg.evaluate("document.getElementById('f-bio').classList.contains('off')")
    pg.evaluate("Suite.show('arch')")
    ok(pg.evaluate("document.getElementById('f-bio').classList.contains('off')") and not pg.evaluate("document.getElementById('f-arch').classList.contains('off')"),'tab almashtirilganda faqat bitta iframe faol (ikkinchisi display:none -> rAF to\'xtaydi)')
    pg.screenshot(path='/tmp/suite.png'); b.close()
print('NATIJA: %d/%d'%(sum(res),len(res)))
