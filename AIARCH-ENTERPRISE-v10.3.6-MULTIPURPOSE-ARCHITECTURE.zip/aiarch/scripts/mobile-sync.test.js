'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.join(__dirname, '..');
const dst = path.join(root, 'mobile', 'www');
function run(env) {
  return spawnSync(process.execPath, [path.join(__dirname, 'sync-mobile.js')], {
    cwd: root, env: { ...process.env, ...env }, encoding: 'utf8'
  });
}
try {
  let r = run({ AIARCH_API: '' });
  assert.equal(r.status, 0, r.stderr);
  assert.ok(fs.existsSync(path.join(dst, 'index.html')));
  assert.ok(fs.existsSync(path.join(dst, 'suite.html')));
  let cfg = fs.readFileSync(path.join(dst, 'config.js'), 'utf8');
  assert.match(cfg, /\"api\":\"\"/);
  r = run({ AIARCH_API: 'https://api.example.uz' });
  assert.equal(r.status, 0, r.stderr);
  cfg = fs.readFileSync(path.join(dst, 'config.js'), 'utf8');
  assert.match(cfg, /https:\/\/api\.example\.uz/);
  r = run({ AIARCH_API: 'http://bad.example.uz' });
  assert.notEqual(r.status, 0);
  console.log('✓ Mobile sync: offline, API konfiguratsiya va noto‘g‘ri URL tekshirildi (3/3)');
} finally {
  fs.rmSync(dst, { recursive: true, force: true });
}
