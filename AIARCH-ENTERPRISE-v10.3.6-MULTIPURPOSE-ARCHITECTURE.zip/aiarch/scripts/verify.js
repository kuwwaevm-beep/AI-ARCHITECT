'use strict';
// Statik xavfsizlik va butunlik tekshiruvi:  node scripts/verify.js   (npm run verify)
const fs = require('fs'), path = require('path'), vm = require('vm');
const root = path.join(__dirname, '..'), rd = p => fs.readFileSync(path.join(root, p), 'utf8');
let fails = 0, warns = 0;
const ok = (c, msg) => { if (c) console.log('  ✓ ' + msg); else { fails++; console.log('  ✗ ' + msg); } };
const warn = msg => { warns++; console.log('  ! ' + msg); };

const html = rd('client/index.html'), server = rd('server/server.js'), schema = rd('server/schema.sql'), bim = rd('client/bim-core.js');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
const js = scripts.join('\n');

console.log('1) API kalit xavfsizligi');
ok(!/x-api-key|sk-ant-|api\.anthropic\.com|anthropic-dangerous|aiSaveKey|aiarch_key|aiLocalKey|aiGetKey/.test(html), 'client/index.html da API kalit/to‘g‘ridan-to‘g‘ri Anthropic chaqiruvi yo‘q');
ok(!/aiKeyInput/.test(html), 'kalit kiritish maydoni yo‘q');
for (const f of ['client/config.js', 'client/native-sensors.js', 'server/.env.example', 'server/public/admin.html']) ok(!/sk-ant-[A-Za-z0-9_-]{10,}/.test(rd(f)), f + ' da maxfiy kalit yo‘q');
ok(/ANTHROPIC_API_KEY=\s*$/m.test(rd('server/.env.example')) && /JWT_SECRET=\s*$/m.test(rd('server/.env.example')), '.env.example da sirlar bo‘sh');
ok((server.match(/x-api-key/g) || []).length === 1 && /process\.env\.ANTHROPIC_API_KEY/.test(server), 'kalit faqat serverda va env dan olinadi');
ok(/system: AI_INSTRUCTIONS \+ b\.state/.test(server) && !/req\.body\.system/.test(server), 'AI ko‘rsatmasi serverda, mijoz system yubora olmaydi');
const cm = html.match(/const AI_INSTRUCTIONS = `([\s\S]*?)`;\n/);
ok(!!cm, 'client AI_INSTRUCTIONS topildi');
if (cm) ok(new Function('return `' + cm[1] + '`')() === require(path.join(root, 'server/lib/ai-prompt')), 'AI ko‘rsatmasi client va server o‘rtasida AYNAN bir xil');
ok(/app\.get\('\/api\/ai\/status'/.test(server), 'AI server tayyorligini ko‘rsatuvchi xavfsiz status endpoint bor');
ok(/status\.configured === true/.test(html), 'mijoz AI ulangan deb faqat server konfiguratsiyani tasdiqlagach ko‘rsatadi');
ok(!/Anthropic API kalitingizni kiriting/.test(html), 'foydalanuvchiga maxfiy API kalitni frontendga kiritish aytilmaydi');

console.log('2) CORS / HTTP xavfsizligi');
ok(/cors\(\{[\s\S]*?originAllowed/.test(server), 'cors() ruxsat ro‘yxati bilan sozlangan');
ok(!/origin:\s*(true|'\*'|"\*")/.test(server) && !/[^.]cors\(\)/.test(server), 'ochiq (*) CORS yo‘q');
ok(/wsOriginAllowed/.test(server), 'WebSocket origin tekshiriladi');
ok(/verifyToken\(m\.token\)/.test(server) && !/searchParams\.get\('token'\)/.test(server) && !/\?token=/.test(js), 'WS token URL da emas');
ok(/JWT_SECRET kamida 32/.test(server) && /algorithms: \['HS256'\]/.test(server), 'JWT_SECRET majburiy, algoritm qat’iy');
ok(/entity\.parse\.failed/.test(server), 'xato ushlagich stack ni oshkor qilmaydi');

console.log('3) Ma‘lumotlar bazasi izolyatsiyasi (RLS)');
const tables = [...schema.matchAll(/CREATE TABLE IF NOT EXISTS (\w+)/g)].map(m => m[1]);
for (const t of tables) {
  ok(new RegExp('ALTER TABLE ' + t + ' ENABLE ROW LEVEL SECURITY').test(schema), t + ': RLS yoqilgan');
  ok(new RegExp('CREATE POLICY \\w+ ON ' + t + ' ').test(schema), t + ': siyosat bor');
}
ok(/NOSUPERUSER NOBYPASSRLS/.test(schema), 'ilova roli superuser/BYPASSRLS emas');
ok(!/GRANT[^;]*TO PUBLIC/i.test(schema), 'PUBLIC ga huquq berilmagan');
ok(/GRANT UPDATE \(title, data, updated_at\) ON projects/.test(schema) && !/GRANT[^;]*UPDATE[^(;]*ON projects/.test(schema.replace(/GRANT UPDATE \(title, data, updated_at\) ON projects/, '')), 'owner_id o‘zgartirib bo‘lmaydi');
ok((server.match(/pool\.query\(/g) || []).length === 1, 'barcha so‘rovlar db() (RLS konteksti) orqali; pool.query faqat sozlama tekshiruvida');
ok(/assertRlsSafe\(\)/.test(server) && /rolbypassrls/.test(server), 'server noto‘g‘ri DB roli bilan ishga tushmaydi');
ok(!/ADMIN_EMAIL/.test(server), 'admin huquqi ro‘yxatdan o‘tishda berilmaydi');
ok(/escape|cEsc\(p\.title\)/.test(html) && /cEsc\(p\.title\)/.test(html), 'loyiha nomi ekranlanadi (XSS)');

console.log('4) Mijoz kodi butunligi');
let syntaxOk = true; scripts.forEach(s => { try { new vm.Script(s); } catch (e) { syntaxOk = false; console.log('    ' + e.message); } });
ok(syntaxOk, 'barcha inline skriptlar sintaksisi to‘g‘ri');
const defined = new Set([...js.matchAll(/function\s+([A-Za-z_$][\w$]*)/g)].map(m => m[1]));
[...js.matchAll(/^\s*(?:window\.)?([A-Za-z_$][\w$]*)\s*=\s*(?:async\s*)?function/gm)].forEach(m => defined.add(m[1]));
const called = new Set([...html.matchAll(/on(?:click|change|input|submit)="\s*(?:return\s+)?([A-Za-z_$][\w$]*)\(/g)].map(m => m[1]));
const missing = [...called].filter(n => !defined.has(n) && !['event'].includes(n));
ok(!missing.length, 'barcha onclick/onchange funksiyalari mavjud' + (missing.length ? ' — YO‘Q: ' + missing.join(', ') : ''));
const ids = [...js.matchAll(/(?:getElementById|\$c)\('([\w-]+)'\)/g)].map(m => m[1]);
const noId = [...new Set(ids)].filter(i => !new RegExp('id=\\\\?["\']' + i + '\\\\?["\']').test(html));
ok(!noId.length, 'getElementById ishlatilgan barcha id lar mavjud' + (noId.length ? ' — YO‘Q: ' + noId.join(', ') : ''));
ok(/cdn\.tailwindcss\.com\/3\.4\.17/.test(html), 'Tailwind versiyasi qotirilgan');
ok(/IN_CLAUDE/.test(html) && /AI_SAMPLE/.test(html), 'claude.ai rejimi (sample) qo‘llab-quvvatlanadi');

console.log('5) Central BIM Core');
ok(/AIARCHBIM\.buildModel/.test(html), 'frontend BIM modelini yagona Core orqali yaratadi');
ok(/syncCentralBIMModel\(\)/.test(html), 'o‘lcham o‘zgarganda BIM modeli yangilanadi');
ok(/AIARCHBIM/.test(html) && /AIARCHBIM/.test(bim), 'BIM Core frontendga ulangan');
ok(/validateModel/.test(bim) && /stableId/.test(bim), 'BIM elementlari tekshiriladi va barqaror ID oladi');
ok(/aiarch-bim/.test(html) && /AIARCH_BIM_UPDATED/.test(html), 'BIM yangilanishlari broadcast va parent ko‘prigiga uzatiladi');

console.log('6) Mobil sinxronizatsiya');
const pkg = JSON.parse(rd('mobile/package.json')), cap = JSON.parse(rd('mobile/capacitor.config.json'));
ok(cap.webDir === 'www', 'webDir = www');
for (const k of ['sync', 'open:android', 'open:ios', 'build:android']) ok(pkg.scripts && /sync-mobile\.js/.test(pkg.scripts[k] || ''), `mobile "npm run ${k}" oldidan avtomatik nusxalaydi`);
ok(/mobile\/www/.test(rd('.gitignore')), 'mobile/www git da yo‘q (qo‘lda nusxa saqlanmaydi)');
const www = path.join(root, 'mobile/www/index.html');
if (fs.existsSync(www)) ok(fs.readFileSync(www).equals(fs.readFileSync(path.join(root, 'client/index.html'))), 'mobile/www/index.html client bilan bir xil');
else warn('mobile/www hali yaratilmagan — "npm run sync" bilan offline yoki AIARCH_API berib tayyorlanadi');

console.log(`\n${fails ? '✗ ' + fails + ' ta xato' : '✓ Hammasi joyida'}${warns ? ' (' + warns + ' ogohlantirish)' : ''}`);
process.exit(fails ? 1 : 0);
