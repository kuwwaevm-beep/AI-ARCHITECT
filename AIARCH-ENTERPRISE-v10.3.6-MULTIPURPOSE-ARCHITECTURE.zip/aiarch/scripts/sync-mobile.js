'use strict';
// client/ (YAGONA manba) -> mobile/www. Har cap buyrug'idan OLDIN avtomatik ishlaydi (mobile/package.json),
// shuning uchun mobil ilova eski versiyada qolib ketishi mumkin emas.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..'), src = path.join(root, 'client'), dst = path.join(root, 'mobile', 'www');
const api = (process.env.AIARCH_API || '').trim().replace(/\/+$/, '');
if (api && !/^https:\/\/[^\s/]+(:\d+)?$/.test(api)) {
  console.error('AIARCH_API https:// bilan boshlanishi va faqat domen/portdan iborat bo‘lishi kerak');
  process.exit(1);
}
fs.rmSync(dst, { recursive: true, force: true });
fs.cpSync(src, dst, { recursive: true });
fs.writeFileSync(path.join(dst, 'config.js'), 'window.AIARCH_CONFIG = ' + JSON.stringify({ api }) + ';\n');
const a = fs.readFileSync(path.join(src, 'index.html')), b = fs.readFileSync(path.join(dst, 'index.html'));
if (!a.equals(b)) { console.error('Sinxronizatsiya xatosi'); process.exit(1); }
console.log('✓ mobile/www yangilandi (' + (api ? 'API: ' + api : 'offline/local rejim; bulut AI uchun keyin server manzilini kiriting') + ')');
