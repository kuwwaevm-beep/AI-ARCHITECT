'use strict';
const assert = require('node:assert/strict');
const BIM = require('../client/bim-core.js');
const footprint = { poly: [[-4.8,-5.8],[4.8,-5.8],[4.8,5.8],[-4.8,5.8]] };
const input = { footprint, floors: 2, floorHeight: 3.2, wallThickness: 0.38, foundationDepth: 0.9,
  estimateItems: [{name:'Beton',qty:10,unit:'m3',price:680000,total:6800000}] };
const model = BIM.buildModel(input);
assert.equal(BIM.validateModel(model), true);
assert.equal(model.building.footprintAreaM2, 111.36);
assert.equal(model.elements.filter(x => x.type === 'wall').length, 8);
assert.equal(model.elements.filter(x => x.type === 'slab').length, 2);
assert.equal(model.estimate[0].total, 6800000);
assert.equal(BIM.stableId('wall:1'), BIM.stableId('wall:1'));
assert.notEqual(BIM.stableId('wall:1'), BIM.stableId('wall:2'));
assert.throws(() => BIM.buildModel({...input, footprint:{poly:[[0,0],[1,1]]}}));
assert.throws(() => BIM.buildModel({...input, floorHeight:99}));
const duplicate = JSON.parse(JSON.stringify(model)); duplicate.elements[1].id = duplicate.elements[0].id;
assert.equal(BIM.validateModel(duplicate), false);
console.log('✓ Central BIM Core: 9/9 checks passed');
