'use strict';
// Yetkazib beruvchilar JSON-feedlaridan narxlarni yangilaydi. Cron: 0 6 * * *  node sync-prices.js
require('dotenv').config();
const { Pool } = require('pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const KEY = /^[A-Za-z0-9_]{1,40}$/;
(async () => {
  let feeds = []; try { feeds = JSON.parse(process.env.SUPPLIER_FEEDS || '[]'); } catch (e) { console.error('SUPPLIER_FEEDS JSON xato'); process.exit(1); }
  for (const f of feeds) {
    try {
      if (!/^https:\/\//.test(f.url)) throw new Error('faqat https manba');
      const j = await (await fetch(f.url, { signal: AbortSignal.timeout(15000) })).json();
      const c = await pool.connect();
      try {
        await c.query('BEGIN');
        await c.query("SELECT set_config('app.is_admin','true',true)");   // RLS: narx yozish huquqi
        for (const [key, field] of Object.entries(f.map || {})) {
          const v = Number(j[field]);
          if (!KEY.test(key) || !isFinite(v) || v <= 0 || v >= 1e12) continue;
          await c.query(`INSERT INTO prices(key,value,source) VALUES($1,$2,$3)
            ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value,source=EXCLUDED.source,updated_at=now()`, [key, v, f.url]);
        }
        await c.query('COMMIT'); console.log('OK', f.url);
      } catch (e) { await c.query('ROLLBACK'); throw e; } finally { c.release(); }
    } catch (e) { console.error('Xato', f.url, e.message); }
  }
  await pool.end();
})();
