INSERT INTO prices(key,value) VALUES
('concreteM3',680000),('rebarTon',9800000),('formworkM3',2900000),('sandM3',140000),('gravelM3',180000),
('brick',1350),('gazoblok',25000),('shlakoblok',6500),('cementBag',47000),('roofSheetM2',98000),
('woodBeamM3',3300000),('insulationM2',42000),('windowM2',920000),('intDoorUnit',1850000),('extDoorUnit',4800000),
('plasterM2',38000),('gypsumM2',65000),('floorFinishM2',135000),('facadeM2',110000),('elecCableM',9500),
('plumbPoint',450000),('laborM2',650000) ON CONFLICT DO NOTHING;
