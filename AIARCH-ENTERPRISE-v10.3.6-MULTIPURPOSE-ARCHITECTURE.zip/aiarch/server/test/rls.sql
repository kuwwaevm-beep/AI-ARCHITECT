-- RLS izolyatsiyasini HAQIQIY bazada tekshirish (psql, jadval egasi sifatida ishga tushiring):
--   psql "$ADMIN_DATABASE_URL" -v ON_ERROR_STOP=1 -f test/rls.sql
-- Hamma narsa tranzaksiyada va oxirida ROLLBACK — bazaga iz qolmaydi.
BEGIN;
INSERT INTO users(id,email,name,pass_hash) VALUES (9001,'a@t.uz','A','x'),(9002,'b@t.uz','B','x'),(9003,'c@t.uz','C','x');
INSERT INTO projects(id,owner_id,title,data) VALUES ('11111111-1111-4111-8111-111111111111',9001,'A uyi','{"inputs":{}}');
INSERT INTO project_members VALUES ('11111111-1111-4111-8111-111111111111',9001,'architect'),
                                   ('11111111-1111-4111-8111-111111111111',9003,'client');
SET LOCAL ROLE aiarch_app;

DO $$ DECLARE n int; BEGIN
  -- B (a'zo emas) hech narsa ko'rmaydi va o'zgartira olmaydi
  PERFORM set_config('app.user_id','9002',true);
  SELECT count(*) INTO n FROM projects; IF n <> 0 THEN RAISE EXCEPTION 'B boshqa loyihani ko''rdi'; END IF;
  UPDATE projects SET title='hack'; GET DIAGNOSTICS n = ROW_COUNT; IF n <> 0 THEN RAISE EXCEPTION 'B o''zgartirdi'; END IF;
  DELETE FROM projects; GET DIAGNOSTICS n = ROW_COUNT; IF n <> 0 THEN RAISE EXCEPTION 'B o''chirdi'; END IF;
  BEGIN INSERT INTO project_members VALUES ('11111111-1111-4111-8111-111111111111',9002,'architect'); RAISE EXCEPTION 'B o''zini qo''shdi';
  EXCEPTION WHEN insufficient_privilege THEN NULL; END;
  -- C (buyurtmachi) ko'radi, lekin o'zgartira olmaydi
  PERFORM set_config('app.user_id','9003',true);
  SELECT count(*) INTO n FROM projects; IF n <> 1 THEN RAISE EXCEPTION 'C ko''rmadi'; END IF;
  UPDATE projects SET title='hack'; GET DIAGNOSTICS n = ROW_COUNT; IF n <> 0 THEN RAISE EXCEPTION 'C o''zgartirdi'; END IF;
  BEGIN INSERT INTO reports(project_id,user_id,text) VALUES ('11111111-1111-4111-8111-111111111111',9003,'x'); RAISE EXCEPTION 'C hisobot yozdi';
  EXCEPTION WHEN insufficient_privilege THEN NULL; END;
  -- A (arxitektor) o'zgartiradi; egasining rolini o'zgartira olmaydi
  PERFORM set_config('app.user_id','9001',true);
  UPDATE projects SET title='yangi'; GET DIAGNOSTICS n = ROW_COUNT; IF n <> 1 THEN RAISE EXCEPTION 'A o''zgartira olmadi'; END IF;
  UPDATE project_members SET role='client' WHERE user_id=9001; GET DIAGNOSTICS n = ROW_COUNT; IF n <> 0 THEN RAISE EXCEPTION 'egasi roli o''zgardi'; END IF;
  -- kontekstsiz (user_id yo'q) — hech narsa
  PERFORM set_config('app.user_id','',true);
  SELECT count(*) INTO n FROM projects; IF n <> 0 THEN RAISE EXCEPTION 'kontekstsiz ko''rdi'; END IF;
  SELECT count(*) INTO n FROM users; IF n <> 0 THEN RAISE EXCEPTION 'kontekstsiz foydalanuvchilarni ko''rdi'; END IF;
  -- foydalanuvchi faqat o'zini ko'radi
  PERFORM set_config('app.user_id','9002',true);
  SELECT count(*) INTO n FROM users; IF n <> 1 THEN RAISE EXCEPTION 'users izolyatsiyasi buzildi'; END IF;
  -- narxlarni admin bo'lmagan yoza olmaydi
  BEGIN INSERT INTO prices(key,value) VALUES ('t',1); RAISE EXCEPTION 'oddiy foydalanuvchi narx yozdi';
  EXCEPTION WHEN insufficient_privilege THEN NULL; END;
  RAISE NOTICE 'RLS TESTLARI: HAMMASI O''TDI';
END $$;
ROLLBACK;
