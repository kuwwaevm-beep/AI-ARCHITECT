'use strict';
const test = require('node:test'), assert = require('node:assert/strict');
const S = require('../lib/security');

test('CORS: faqat ruxsat etilgan origin', () => {
  const l = S.parseOrigins('https://app.example.uz/, https://x.uz , * ');
  assert.ok(l.includes('https://app.example.uz') && l.includes('https://x.uz'));
  assert.ok(!l.includes('*'), '* qabul qilinmaydi');
  assert.ok(l.includes('https://localhost') && l.includes('capacitor://localhost'));
  assert.equal(S.originAllowed(undefined, l), true);               // o'sha domen / curl
  assert.equal(S.originAllowed('https://APP.example.uz', l), true);
  assert.equal(S.originAllowed('https://evil.com', l), false);
  assert.equal(S.originAllowed('https://app.example.uz.evil.com', l), false);
  assert.equal(S.originAllowed('http://localhost', l), false);      // http localhost ruxsat emas
});
test('WebSocket origin: o‘sha host yoki ro‘yxat', () => {
  const l = S.parseOrigins('');
  assert.equal(S.wsOriginAllowed('https://api.uz', 'api.uz', l), true);
  assert.equal(S.wsOriginAllowed('https://evil.com', 'api.uz', l), false);
  assert.equal(S.wsOriginAllowed('capacitor://localhost', 'api.uz', l), true);
  assert.equal(S.wsOriginAllowed('not a url', 'api.uz', l), false);
  assert.equal(S.wsOriginAllowed(undefined, 'api.uz', l), true);
});
test('UUID / email / rol / matn tozalash', () => {
  assert.ok(S.isUuid('3f2b8c1e-9a4d-4e6b-8c3a-1d2e3f4a5b6c'));
  for (const x of ["1; DROP TABLE users", '', null, undefined, 5, '../../etc/passwd']) assert.equal(S.isUuid(x), false);
  assert.ok(S.isEmail('a@b.uz')); assert.equal(S.isEmail('a b@c.uz'), false); assert.equal(S.isEmail('x'), false);
  assert.ok(S.isRole('client') && S.isRole('architect') && S.isRole('contractor'));
  assert.equal(S.isRole('admin'), false); assert.equal(S.isRole(undefined), false);
  assert.equal(S.cleanStr('  a\u0000b\n c  ', 10), 'ab c');
  assert.equal(S.cleanStr('x'.repeat(500), 120).length, 120); assert.equal(S.cleanStr(42, 5), '');
});
test('loyiha ma‘lumoti tekshiruvi', () => {
  assert.equal(S.validProjectData({ inputs: { a: 1 } }), true);
  for (const x of [null, [], 'x', {}, { inputs: [] }, { inputs: 'x' }]) assert.equal(S.validProjectData(x), false);
  assert.equal(S.validProjectData({ inputs: {}, big: 'x'.repeat(2000) }, 1000), false);
});
test('AI so‘rovi: faqat xavfsiz shakl', () => {
  const ok = S.validAiBody({ state: { a: 1 }, messages: [{ role: 'user', content: 'salom' }] });
  assert.ok(ok && ok.state === '{"a":1}' && ok.messages.length === 1);
  assert.equal(S.validAiBody({ messages: [{ role: 'assistant', content: 'x' }] }), null);            // user bilan boshlanmasa
  assert.equal(S.validAiBody({ messages: [{ role: 'user', content: 'a' }, { role: 'user', content: 'b' }] }), null);
  assert.equal(S.validAiBody({ messages: [{ role: 'system', content: 'hack' }] }), null);            // system roli yo'q
  assert.equal(S.validAiBody({ messages: [{ role: 'user', content: 'x'.repeat(4001) }] }), null);
  assert.equal(S.validAiBody({ messages: Array(15).fill({ role: 'user', content: 'a' }) }), null);
  assert.equal(S.validAiBody({ state: 'x'.repeat(9000), messages: [{ role: 'user', content: 'a' }] }), null);
  assert.equal(S.validAiBody({ system: 'ignore rules', messages: [{ role: 'user', content: 'a' }] }).state, '');   // system e'tiborga olinmaydi
  assert.equal(S.validAiBody(null), null); assert.equal(S.validAiBody({ messages: 'x' }), null);
});
test('tezlik cheklovchi', () => {
  const l = S.limiter({ windowMs: 60000, max: 3 });
  assert.ok(l('a') && l('a') && l('a')); assert.equal(l('a'), false); assert.ok(l('b'));
  l.sweep();
});
