'use strict';
// server.js ni HAQIQIY kodi bilan, lekin express/pg/ws/jwt o'rniga soxta (mock) modullar bilan ishga tushiradi:
// marshrut mantiqi, RLS konteksti (set_config), rol tekshiruvlari, AI proksi, WebSocket auth tekshiriladi.
const test = require('node:test'), assert = require('node:assert/strict'), Module = require('module'), path = require('path');

const routes = [], wsHandlers = {}, log = { sql: [], fetches: [] };
let script = () => ({ rows: [], rowCount: 0 });
const mw = () => function mwStub() {};
const app = { disable() {}, set() {}, use() {}, ...Object.fromEntries(['get', 'post', 'put', 'delete'].map(m => [m, (p, ...h) => routes.push({ m: m.toUpperCase(), p, h })])) };
const express = () => app; express.json = mw; express.static = mw;
class Pool {
  async query(sql, p) { log.sql.push({ sql, p }); return /rolsuper/.test(sql) ? { rows: [Pool.safe] } : script(sql, p); }
  async connect() { const self = this; return { query: (s, p) => self.query(s, p), release() {} }; }
}
Pool.safe = { rolsuper: false, rolbypassrls: false, is_owner: false };
class WSS { constructor() { this.h = {}; wsHandlers.wss = this; } on(e, f) { this.h[e] = f; } }
const mocks = {
  express, cors: () => mw(), pg: { Pool }, dotenv: { config() {} }, http: { createServer: () => ({ listen() {} }) },
  bcryptjs: { hashSync: p => 'h:' + p, hash: async p => 'h:' + p, compare: async (p, h) => h === 'h:' + p },
  jsonwebtoken: { sign: u => 'T' + Buffer.from(JSON.stringify(u)).toString('base64'), verify: t => { if (!/^T/.test(t)) throw new Error('bad'); return JSON.parse(Buffer.from(t.slice(1), 'base64').toString()); } },
  ws: { WebSocketServer: WSS }
};
const origLoad = Module._load;
Module._load = function (req, ...a) { return Object.prototype.hasOwnProperty.call(mocks, req) ? mocks[req] : origLoad.call(this, req, ...a); };
process.env.JWT_SECRET = 'x'.repeat(40); process.env.DATABASE_URL = 'postgres://stub'; process.env.ANTHROPIC_API_KEY = 'sk-ant-TESTKEY';
global.fetch = async (url, o) => { log.fetches.push({ url, o }); return global.fetch.next(); };
require(path.join(__dirname, '..', 'server.js'));
const AI_INSTRUCTIONS = require('../lib/ai-prompt');

const tok = u => mocks.jsonwebtoken.sign(u);
const ALICE = { id: 7, email: 'a@t.uz', name: 'Alice' }, PID = '3f2b8c1e-9a4d-4e6b-8c3a-1d2e3f4a5b6c';
async function call(m, p, { user, body, params } = {}) {
  const r = routes.find(x => x.m === m && x.p === p); assert.ok(r, 'marshrut topilmadi: ' + m + ' ' + p);
  const req = { headers: user ? { authorization: 'Bearer ' + tok(user) } : {}, body: body || {}, params: params || {}, ip: '1.1.1.' + Math.random() };
  const res = { code: 200, body: undefined, status(c) { this.code = c; return this; }, json(b) { this.body = b; this.done = true; return this; } };
  for (const h of r.h) { let nx = false; await h(req, res, () => { nx = true; }); if (!nx) break; }
  await new Promise(r => setImmediate(r));
  return res;
}
const reset = () => { log.sql.length = 0; log.fetches.length = 0; script = () => ({ rows: [], rowCount: 0 }); };
const ctxOf = () => log.sql.find(q => /set_config/.test(q.sql));

test('start: RLS xavfsiz bo‘lmagan DB roli bilan server ishga tushmaydi', async () => {
  Pool.safe = { rolsuper: true, rolbypassrls: false, is_owner: false };
  const real = process.exit; let code; process.exit = c => { code = c; };
  delete require.cache[require.resolve('../server.js')]; routes.length = 0;
  const err = console.error; console.error = () => {};
  require('../server.js'); await new Promise(r => setTimeout(r, 20));
  process.exit = real; console.error = err; Pool.safe = { rolsuper: false, rolbypassrls: false, is_owner: false };
  assert.equal(code, 1);
  routes.length = 0; delete require.cache[require.resolve('../server.js')]; require('../server.js'); await new Promise(r => setTimeout(r, 20));
});
test('tokensiz so‘rov 401, noto‘g‘ri id 400 (DB ga murojaatsiz)', async () => {
  reset(); assert.equal((await call('GET', '/api/projects')).code, 401);
  assert.equal((await call('GET', '/api/projects/:id', { user: ALICE, params: { id: "1'; DROP" } })).code, 400);
  assert.equal(log.sql.length, 0);
});
test('har DB so‘rovi RLS kontekstida: BEGIN → set_config(app.user_id) → ... → COMMIT', async () => {
  reset(); script = s => /FROM projects p/.test(s) ? { rows: [{ id: PID, role: 'client' }] } : { rows: [] };
  const r = await call('GET', '/api/projects', { user: ALICE });
  assert.equal(r.code, 200); const s = log.sql.map(q => q.sql);
  assert.equal(s[0], 'BEGIN'); assert.match(s[1], /set_config\('app.user_id'/); assert.equal(ctxOf().p[0], '7'); assert.equal(s[s.length - 1], 'COMMIT');
});
test('ro‘yxatdan o‘tish: validatsiya + auth rejimi', async () => {
  reset(); assert.equal((await call('POST', '/api/auth/register', { body: { email: 'bad', password: '12345678' } })).code, 400);
  assert.equal((await call('POST', '/api/auth/register', { body: { email: 'a@t.uz', password: '123' } })).code, 400);
  assert.equal(log.sql.length, 0);
  script = () => ({ rows: [{ id: 1, email: 'a@t.uz', name: 'a' }] });
  const r = await call('POST', '/api/auth/register', { body: { email: 'A@T.uz', password: 'parol12345' } });
  assert.equal(r.code, 200); assert.ok(r.body.token); assert.equal(ctxOf().p[2], 'auth');
  assert.ok(!JSON.stringify(r.body).includes('h:parol'), 'parol hashi javobda yo‘q');
});
test('login: noto‘g‘ri parol 401, foydalanuvchi yo‘q 401', async () => {
  reset(); script = () => ({ rows: [{ id: 1, email: 'a@t.uz', name: 'a', pass_hash: 'h:togri', is_admin: false }] });
  assert.equal((await call('POST', '/api/auth/login', { body: { email: 'a@t.uz', password: 'xato' } })).code, 401);
  assert.equal((await call('POST', '/api/auth/login', { body: { email: 'a@t.uz', password: 'togri' } })).code, 200);
  script = () => ({ rows: [] }); assert.equal((await call('POST', '/api/auth/login', { body: { email: 'z@t.uz', password: 'x' } })).code, 401);
});
test('rol: arxitektor bo‘lmaganlar o‘zgartira/taklif qila olmaydi', async () => {
  reset(); script = () => ({ rows: [], rowCount: 0 });
  const put = await call('PUT', '/api/projects/:id', { user: ALICE, params: { id: PID }, body: { data: { inputs: {} } } });
  assert.equal(put.code, 403);
  script = s => /app_role/.test(s) ? { rows: [{ role: 'client' }] } : { rows: [] };
  const inv = await call('POST', '/api/projects/:id/members', { user: ALICE, params: { id: PID }, body: { email: 'b@t.uz', role: 'architect' } });
  assert.equal(inv.code, 403); assert.ok(!log.sql.some(q => /INSERT INTO project_members/.test(q.sql)), 'INSERT bajarilmadi');
  assert.equal((await call('POST', '/api/projects/:id/members', { user: ALICE, params: { id: PID }, body: { email: 'b@t.uz', role: 'admin' } })).code, 400);
  assert.equal((await call('PUT', '/api/projects/:id', { user: ALICE, params: { id: PID }, body: { data: 'x' } })).code, 400);
});
test('RLS rad etsa (42501) — 500 emas, 403', async () => {
  reset(); script = s => { if (/INSERT INTO reports/.test(s)) { const e = new Error('rls'); e.code = '42501'; throw e; } return { rows: [] }; };
  const r = await call('POST', '/api/projects/:id/reports', { user: ALICE, params: { id: PID }, body: { text: 'ish tugadi' } });
  assert.equal(r.code, 403); assert.equal(log.sql.at(-1).sql, 'ROLLBACK');
});
test('AI proksi: kalit faqat serverda, ko‘rsatma serverniki, mijoz system‘i e’tiborsiz', async () => {
  reset(); global.fetch.next = async () => ({ ok: true, json: async () => ({ content: [{ text: 'javob' }] }) });
  assert.equal((await call('POST', '/api/ai', { body: { messages: [] } })).code, 401);
  assert.equal((await call('POST', '/api/ai', { user: ALICE, body: { messages: [{ role: 'assistant', content: 'x' }] } })).code, 400);
  const r = await call('POST', '/api/ai', { user: ALICE, body: { system: 'HACK', state: { a: 1 }, messages: [{ role: 'user', content: 'salom' }] } });
  assert.equal(r.code, 200); assert.equal(r.body.text, 'javob');
  const f = log.fetches[0], b = JSON.parse(f.o.body);
  assert.equal(f.url, 'https://api.anthropic.com/v1/messages'); assert.equal(f.o.headers['x-api-key'], 'sk-ant-TESTKEY');
  assert.ok(b.system.startsWith(AI_INSTRUCTIONS) && !b.system.includes('HACK'));
  assert.ok(!JSON.stringify(r.body).includes('sk-ant'), 'kalit javobda yo‘q');
  global.fetch.next = async () => ({ ok: false, status: 401, json: async () => ({ error: { type: 'authentication_error', message: 'invalid x-api-key sk-ant-TESTKEY' } }) });
  const e = console.error; console.error = () => {}; const r2 = await call('POST', '/api/ai', { user: { id: 8, name: 'B', email: 'b@t.uz' }, body: { messages: [{ role: 'user', content: 'a' }] } }); console.error = e;
  assert.equal(r2.code, 502); assert.ok(!JSON.stringify(r2.body).includes('sk-ant'), 'xato matni kalitni oshkor qilmaydi');
});
test('narxlar: admin bo‘lmagan yoza olmaydi; oddiy GET ochiq', async () => {
  reset(); script = s => /is_admin FROM users/.test(s) ? { rows: [{ is_admin: false }] } : { rows: [{ key: 'brick', value: '1350' }] };
  assert.equal((await call('PUT', '/api/prices', { user: ALICE, body: { brick: 1 } })).code, 403);
  assert.deepEqual((await call('GET', '/api/prices')).body, { brick: 1350 });
  script = s => /is_admin FROM users/.test(s) ? { rows: [{ is_admin: true }] } : { rows: [] };
  assert.equal((await call('PUT', '/api/prices', { user: ALICE, body: { 'bad key!': 5, x: -1 } })).code, 400);
  const ok = await call('PUT', '/api/prices', { user: ALICE, body: { brick: 1400, evil: 'x' } }); assert.equal(ok.code, 200); assert.equal(ok.body.updated, 1);
});
function mkWs() { const s = { sent: [], closed: null, h: {}, readyState: 1, on(e, f) { this.h[e] = f; }, send(x) { this.sent.push(JSON.parse(x)); }, close(c) { this.closed = c; } }; wsHandlers.wss.h.connection(s); return s; }
const msg = (s, m) => s.h.message(JSON.stringify(m));
const tick = () => new Promise(r => setTimeout(r, 15));
test('WebSocket: token URL da emas, birinchi xabarda; rol va a’zolik tekshiriladi', async () => {
  reset(); const a = mkWs(); await msg(a, { type: 'state', data: { inputs: {} } }); assert.equal(a.closed, 4400);       // auth yo'q
  const b = mkWs(); await msg(b, { type: 'auth', token: 'bad', project: PID }); await tick(); assert.equal(b.closed, 4401);
  script = () => ({ rows: [{ role: null }] }); const c = mkWs(); await msg(c, { type: 'auth', token: tok(ALICE), project: PID }); await tick(); assert.equal(c.closed, 4403);
  script = () => ({ rows: [{ role: 'architect' }] });
  const arch = mkWs(); await msg(arch, { type: 'auth', token: tok(ALICE), project: PID }); await tick(); assert.equal(arch.sent[0].type, 'presence');
  script = () => ({ rows: [{ role: 'client' }] });
  const cl = mkWs(); await msg(cl, { type: 'auth', token: tok({ id: 9, name: 'Mijoz', email: 'm@t.uz' }), project: PID }); await tick();
  arch.sent.length = 0; await msg(cl, { type: 'state', data: { inputs: { x: 1 } } }); await tick();
  assert.ok(!arch.sent.some(m => m.type === 'state'), 'buyurtmachi holatni tarqata olmaydi');
  await msg(arch, { type: 'state', data: { inputs: { x: 2 } } }); await tick();
  assert.ok(cl.sent.some(m => m.type === 'state' && m.data.inputs.x === 2), 'arxitektor o‘zgarishi mijozga yetadi');
  await msg(arch, { type: 'state', data: { notvalid: 1 } }); await tick(); assert.equal(cl.sent.filter(m => m.type === 'state').length, 1, 'noto‘g‘ri ma’lumot tarqalmaydi');
});
