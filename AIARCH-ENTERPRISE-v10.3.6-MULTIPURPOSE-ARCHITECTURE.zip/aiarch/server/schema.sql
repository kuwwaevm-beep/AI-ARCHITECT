-- =====================================================================
-- AI Architect Pro — PostgreSQL sxema + Row Level Security (RLS)
-- Ilova "aiarch_app" roli bilan ulanadi (superuser EMAS, jadval egasi EMAS),
-- shuning uchun RLS majburan ishlaydi. Har so'rovda server app.user_id ni o'rnatadi.
-- =====================================================================
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$ BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'aiarch_app') THEN
    CREATE ROLE aiarch_app LOGIN PASSWORD 'aiarch_app_dev' NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
  END IF;
END $$;
-- PRODUCTION: ALTER ROLE aiarch_app PASSWORD '<kuchli-parol>';

CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  email TEXT UNIQUE NOT NULL CHECK (email = lower(email) AND length(email) <= 254),
  name TEXT NOT NULL CHECK (length(name) BETWEEN 1 AND 100),
  pass_hash TEXT NOT NULL,
  is_admin BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title TEXT NOT NULL CHECK (length(title) BETWEEN 1 AND 120),
  data JSONB NOT NULL CHECK (jsonb_typeof(data) = 'object'),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
-- role: client (buyurtmachi) | architect | contractor (usta/pudratchi)
CREATE TABLE IF NOT EXISTS project_members (
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('client','architect','contractor')),
  PRIMARY KEY (project_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_members_user ON project_members(user_id);
CREATE TABLE IF NOT EXISTS reports (
  id SERIAL PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id INT NOT NULL REFERENCES users(id),
  text TEXT NOT NULL CHECK (length(text) BETWEEN 1 AND 2000),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_reports_project ON reports(project_id, created_at DESC);
CREATE TABLE IF NOT EXISTS prices (
  key TEXT PRIMARY KEY CHECK (key ~ '^[A-Za-z0-9_]{1,40}$'),
  value NUMERIC NOT NULL CHECK (value >= 0),
  source TEXT NOT NULL DEFAULT 'admin',
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Kontekst yordamchilari (server har tranzaksiyada set_config qiladi) ----------
CREATE OR REPLACE FUNCTION app_uid() RETURNS int LANGUAGE sql STABLE
  AS $$ SELECT NULLIF(current_setting('app.user_id', true), '')::int $$;
CREATE OR REPLACE FUNCTION app_is_admin() RETURNS boolean LANGUAGE sql STABLE
  AS $$ SELECT COALESCE(current_setting('app.is_admin', true), 'false') = 'true' $$;
CREATE OR REPLACE FUNCTION app_auth_mode() RETURNS boolean LANGUAGE sql STABLE
  AS $$ SELECT COALESCE(current_setting('app.mode', true), '') = 'auth' $$;

-- SECURITY DEFINER: RLS siyosatlari ichida rekursiyasiz tekshirish uchun
CREATE OR REPLACE FUNCTION app_role(pid uuid) RETURNS text LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
  AS $$ SELECT role FROM project_members WHERE project_id = pid AND user_id = app_uid() $$;
CREATE OR REPLACE FUNCTION app_owns(pid uuid) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
  AS $$ SELECT EXISTS (SELECT 1 FROM projects WHERE id = pid AND owner_id = app_uid()) $$;
CREATE OR REPLACE FUNCTION app_is_owner_user(pid uuid, uid int) RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
  AS $$ SELECT EXISTS (SELECT 1 FROM projects WHERE id = pid AND owner_id = uid) $$;
-- Taklif uchun: faqat id qaytaradi (boshqa foydalanuvchi ma'lumoti ochilmaydi)
CREATE OR REPLACE FUNCTION find_user_id(e text) RETURNS int LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
  AS $$ SELECT id FROM users WHERE email = lower(e) AND app_uid() IS NOT NULL $$;
-- Hisobotlar: faqat loyiha a'zosi o'qiy oladi
CREATE OR REPLACE FUNCTION project_reports(pid uuid) RETURNS TABLE(txt text, created_at timestamptz, name text)
  LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
  AS $$ SELECT r.text AS txt, r.created_at, u.name FROM reports r JOIN users u ON u.id = r.user_id
        WHERE r.project_id = pid AND app_role(pid) IS NOT NULL ORDER BY r.created_at DESC LIMIT 50 $$;

REVOKE ALL ON FUNCTION app_role(uuid), app_owns(uuid), app_is_owner_user(uuid,int), find_user_id(text), project_reports(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION app_uid(), app_is_admin(), app_auth_mode(), app_role(uuid), app_owns(uuid), app_is_owner_user(uuid,int), find_user_id(text), project_reports(uuid) TO aiarch_app;

-- ---------- RLS ----------
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE prices ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS users_sel ON users;  DROP POLICY IF EXISTS users_ins ON users;
-- users: faqat o'zini ko'radi; login/ro'yxat (auth rejimi) serverning auth marshrutlarida
CREATE POLICY users_sel ON users FOR SELECT TO aiarch_app USING (id = app_uid() OR app_auth_mode());
CREATE POLICY users_ins ON users FOR INSERT TO aiarch_app WITH CHECK (app_auth_mode());

DROP POLICY IF EXISTS pr_sel ON projects; DROP POLICY IF EXISTS pr_ins ON projects;
DROP POLICY IF EXISTS pr_upd ON projects; DROP POLICY IF EXISTS pr_del ON projects;
CREATE POLICY pr_sel ON projects FOR SELECT TO aiarch_app USING (owner_id = app_uid() OR app_role(id) IS NOT NULL);
CREATE POLICY pr_ins ON projects FOR INSERT TO aiarch_app WITH CHECK (owner_id = app_uid());
CREATE POLICY pr_upd ON projects FOR UPDATE TO aiarch_app USING (app_role(id) = 'architect') WITH CHECK (app_role(id) = 'architect');
CREATE POLICY pr_del ON projects FOR DELETE TO aiarch_app USING (owner_id = app_uid());

DROP POLICY IF EXISTS pm_sel ON project_members; DROP POLICY IF EXISTS pm_ins ON project_members;
DROP POLICY IF EXISTS pm_upd ON project_members; DROP POLICY IF EXISTS pm_del ON project_members;
CREATE POLICY pm_sel ON project_members FOR SELECT TO aiarch_app USING (user_id = app_uid() OR app_role(project_id) = 'architect');
CREATE POLICY pm_ins ON project_members FOR INSERT TO aiarch_app WITH CHECK (
  app_role(project_id) = 'architect' OR (user_id = app_uid() AND role = 'architect' AND app_owns(project_id)));
-- egasining rolini hech kim o'zgartira/o'chira olmaydi
CREATE POLICY pm_upd ON project_members FOR UPDATE TO aiarch_app
  USING (app_role(project_id) = 'architect' AND NOT app_is_owner_user(project_id, user_id))
  WITH CHECK (app_role(project_id) = 'architect' AND NOT app_is_owner_user(project_id, user_id));
CREATE POLICY pm_del ON project_members FOR DELETE TO aiarch_app
  USING (app_role(project_id) = 'architect' AND NOT app_is_owner_user(project_id, user_id));

DROP POLICY IF EXISTS rp_ins ON reports;
CREATE POLICY rp_ins ON reports FOR INSERT TO aiarch_app
  WITH CHECK (user_id = app_uid() AND app_role(project_id) IN ('architect','contractor'));

DROP POLICY IF EXISTS pc_sel ON prices; DROP POLICY IF EXISTS pc_ins ON prices; DROP POLICY IF EXISTS pc_upd ON prices;
CREATE POLICY pc_sel ON prices FOR SELECT TO aiarch_app USING (true);
CREATE POLICY pc_ins ON prices FOR INSERT TO aiarch_app WITH CHECK (app_is_admin());
CREATE POLICY pc_upd ON prices FOR UPDATE TO aiarch_app USING (app_is_admin()) WITH CHECK (app_is_admin());

-- ---------- Minimal huquqlar ----------
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM aiarch_app;
GRANT USAGE ON SCHEMA public TO aiarch_app;
GRANT SELECT, INSERT ON users TO aiarch_app;
GRANT SELECT, INSERT, DELETE ON projects TO aiarch_app;
GRANT UPDATE (title, data, updated_at) ON projects TO aiarch_app;     -- owner_id o'zgartirib bo'lmaydi
GRANT SELECT, INSERT, DELETE ON project_members TO aiarch_app;
GRANT UPDATE (role) ON project_members TO aiarch_app;
GRANT INSERT ON reports TO aiarch_app;                                  -- o'qish faqat project_reports() orqali
GRANT SELECT, INSERT ON prices TO aiarch_app;
GRANT UPDATE (value, source, updated_at) ON prices TO aiarch_app;
GRANT USAGE ON SEQUENCE users_id_seq, reports_id_seq TO aiarch_app;
