'use strict';
// Admin huquqini FAQAT server egasi beradi (ro'yxatdan o'tishda emas — aks holda birinchi kelgan admin bo'lib olardi).
// Ishlatish: node make-admin.js odam@example.uz
require('dotenv').config();
const { Pool } = require('pg');
const email = (process.argv[2] || '').toLowerCase();
if (!email || !process.env.ADMIN_DATABASE_URL) { console.error('Ishlatish: ADMIN_DATABASE_URL ni .env ga yozing va: node make-admin.js email'); process.exit(1); }
const pool = new Pool({ connectionString: process.env.ADMIN_DATABASE_URL });
pool.query('UPDATE users SET is_admin = TRUE WHERE email = $1', [email])
  .then(r => { console.log(r.rowCount ? 'Admin qilindi: ' + email : 'Foydalanuvchi topilmadi'); return pool.end(); })
  .catch(e => { console.error(e.message); process.exit(1); });
