'use strict';
require('dotenv').config();
const path = require('path'), http = require('http');
const express = require('express'), cors = require('cors');
const { Pool } = require('pg'), bcrypt = require('bcryptjs'), jwt = require('jsonwebtoken');
const { WebSocketServer } = require('ws');
const S = require('./lib/security');
const AI_INSTRUCTIONS = require('./lib/ai-prompt');

/* ---------- Sozlamalar (xavfsiz boshlang'ich tekshiruv) ---------- */
const PROD = process.env.NODE_ENV === 'production';
const SECRET = process.env.JWT_SECRET || '';
if (SECRET.length < 32) { console.error('JWT_SECRET kamida 32 belgi bo‘lishi shart (.env.example ga qarang)'); process.exit(1); }
if (!process.env.DATABASE_URL) { console.error('DATABASE_URL kerak'); process.exit(1); }
const ORIGINS = S.parseOrigins(process.env.ALLOWED_ORIGINS);
const CLIENT_DIR = path.join(__dirname, '..', 'client');   // YAGONA frontend manbasi (nusxa yo'q)
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });

/* ---------- RLS: har so'rov o'z foydalanuvchi konteksti bilan ---------- */
// ctx: { uid, admin, mode }. Barcha DB so'rovlari FAQAT shu orqali o'tadi.
async function db(ctx, fn) {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    await c.query("SELECT set_config('app.user_id',$1,true), set_config('app.is_admin',$2,true), set_config('app.mode',$3,true)",
      [ctx && ctx.uid ? String(ctx.uid) : '', ctx && ctx.admin ? 'true' : 'false', (ctx && ctx.mode) || '']);
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) { try { await c.query('ROLLBACK'); } catch (x) { /* ignore */ } throw e; }
  finally { c.release(); }
}
async function assertRlsSafe() {
  const r = await pool.query(`SELECT r.rolsuper, r.rolbypassrls,
      (SELECT tableowner = current_user FROM pg_tables WHERE schemaname='public' AND tablename='projects') AS is_owner
      FROM pg_roles r WHERE r.rolname = current_user`);
  const x = r.rows[0] || {};
  if (x.rolsuper || x.rolbypassrls || x.is_owner) {
    console.error('XAVFLI SOZLAMA: DATABASE_URL superuser/BYPASSRLS/jadval egasi bilan ulangan — RLS ishlamaydi. aiarch_app rolini ishlating.');
    process.exit(1);
  }
}
const roleOf = async (c, pid) => (await c.query('SELECT app_role($1) AS role', [pid])).rows[0].role;
async function isAdminUser(uid) {
  return db({ uid }, async c => !!(await c.query('SELECT is_admin FROM users WHERE id=$1', [uid])).rows[0]?.is_admin);
}

/* ---------- Express ---------- */
const app = express();
app.disable('x-powered-by');
if (Number(process.env.TRUST_PROXY)) app.set('trust proxy', Number(process.env.TRUST_PROXY));
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(self), microphone=(), geolocation=()', 'Cross-Origin-Opener-Policy': 'same-origin' });
  if (PROD) res.set('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  next();
});
// CORS: faqat ruxsat etilgan origin'lar. Ruxsatsiz origin uchun sarlavha berilmaydi (brauzer o'zi bloklaydi).
app.use('/api', cors({
  origin: (origin, cb) => cb(null, S.originAllowed(origin, ORIGINS)),
  methods: ['GET', 'POST', 'PUT', 'DELETE'], allowedHeaders: ['Content-Type', 'Authorization'], maxAge: 600
}));
app.use('/api', express.json({ limit: '2mb' }));
const ipLimit = S.limiter({ windowMs: 60000, max: 300 }), authLimit = S.limiter({ windowMs: 60000, max: 10 });
const aiLimit = S.limiter({ windowMs: 60000, max: 15 }), inviteLimit = S.limiter({ windowMs: 60000, max: 20 });
app.use('/api', (req, res, next) => ipLimit(req.ip) ? next() : res.status(429).json({ error: 'Juda ko‘p so‘rov' }));
app.use(express.static(CLIENT_DIR, { setHeaders: (res, p) => { if (/\.(html|js)$/.test(p)) res.set('Cache-Control', 'no-cache'); } }));
app.use(express.static(path.join(__dirname, 'public')));

const wrap = fn => (req, res) => fn(req, res).catch(e => {
  if (e && e.code === '42501') return res.status(403).json({ error: 'Ruxsat yo‘q' });   // RLS rad etdi
  console.error(e); res.status(500).json({ error: 'Server xatosi' });
});
const bad = (res, msg) => res.status(400).json({ error: msg });

/* ---------- AUTH (JWT) ---------- */
const sign = u => jwt.sign({ id: u.id, email: u.email, name: u.name }, SECRET, { algorithm: 'HS256', expiresIn: '7d' });
function verifyToken(t) { return jwt.verify(String(t || ''), SECRET, { algorithms: ['HS256'] }); }
function auth(req, res, next) {
  try { req.user = verifyToken((req.headers.authorization || '').replace(/^Bearer /, '')); next(); }
  catch (e) { res.status(401).json({ error: 'Kirish talab qilinadi' }); }
}
const DUMMY_HASH = bcrypt.hashSync('dummy-password', 12);
app.post('/api/auth/register', wrap(async (req, res) => {
  if (!authLimit('reg:' + req.ip)) return res.status(429).json({ error: 'Biroz kutib qayta urining' });
  const email = S.cleanStr(req.body.email, 254).toLowerCase(), name = S.cleanStr(req.body.name, 100) || email.split('@')[0];
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!S.isEmail(email)) return bad(res, 'Email noto‘g‘ri');
  if (password.length < 8 || password.length > 128) return bad(res, 'Parol 8–128 belgi bo‘lishi kerak');
  try {
    const hash = await bcrypt.hash(password, 12);
    const u = await db({ mode: 'auth' }, async c => (await c.query('INSERT INTO users(email,name,pass_hash) VALUES($1,$2,$3) RETURNING id,email,name', [email, name, hash])).rows[0]);
    res.json({ token: sign(u), user: { name: u.name, email: u.email } });
  } catch (e) { if (e.code === '23505') return res.status(409).json({ error: 'Bu email band' }); throw e; }
}));
app.post('/api/auth/login', wrap(async (req, res) => {
  const email = S.cleanStr(req.body.email, 254).toLowerCase();
  if (!authLimit('ip:' + req.ip) || !authLimit('em:' + email)) return res.status(429).json({ error: 'Biroz kutib qayta urining' });
  const u = await db({ mode: 'auth' }, async c => (await c.query('SELECT id,email,name,pass_hash,is_admin FROM users WHERE email=$1', [email])).rows[0]);
  const ok = await bcrypt.compare(typeof req.body.password === 'string' ? req.body.password : '', u ? u.pass_hash : DUMMY_HASH);
  if (!u || !ok) return res.status(401).json({ error: 'Email yoki parol xato' });
  res.json({ token: sign(u), user: { name: u.name, email: u.email, admin: u.is_admin } });
}));

/* ---------- LOYIHALAR + ROLLAR (RLS himoyasida) ---------- */
const pidCheck = (req, res, next) => S.isUuid(req.params.id) ? next() : bad(res, 'Loyiha identifikatori noto‘g‘ri');
app.get('/api/projects', auth, wrap(async (req, res) => {
  res.json(await db({ uid: req.user.id }, async c => (await c.query('SELECT p.id,p.title,p.updated_at,app_role(p.id) AS role FROM projects p ORDER BY p.updated_at DESC LIMIT 200')).rows));
}));
app.post('/api/projects', auth, wrap(async (req, res) => {
  if (!S.validProjectData(req.body.data)) return bad(res, 'Loyiha ma‘lumoti noto‘g‘ri yoki juda katta');
  const title = S.cleanStr(req.body.title, 120) || 'Yangi loyiha';
  const id = await db({ uid: req.user.id }, async c => {
    const p = (await c.query('INSERT INTO projects(owner_id,title,data) VALUES($1,$2,$3) RETURNING id', [req.user.id, title, req.body.data])).rows[0].id;
    await c.query("INSERT INTO project_members(project_id,user_id,role) VALUES($1,$2,'architect')", [p, req.user.id]);
    return p;
  });
  res.json({ id, role: 'architect' });
}));
app.get('/api/projects/:id', auth, pidCheck, wrap(async (req, res) => {
  const r = await db({ uid: req.user.id }, async c => (await c.query('SELECT id,title,data,updated_at,app_role(id) AS role FROM projects WHERE id=$1', [req.params.id])).rows[0]);
  if (!r) return res.status(404).json({ error: 'Loyiha topilmadi' });
  res.json(r);
}));
app.put('/api/projects/:id', auth, pidCheck, wrap(async (req, res) => {
  if (!S.validProjectData(req.body.data)) return bad(res, 'Loyiha ma‘lumoti noto‘g‘ri yoki juda katta');
  const title = S.cleanStr(req.body.title, 120) || null;
  const n = await db({ uid: req.user.id }, async c => (await c.query('UPDATE projects SET data=$1,title=COALESCE($2,title),updated_at=now() WHERE id=$3', [req.body.data, title, req.params.id])).rowCount);
  if (!n) return res.status(403).json({ error: 'Faqat arxitektor o‘zgartira oladi' });
  res.json({ ok: true });
}));
app.delete('/api/projects/:id', auth, pidCheck, wrap(async (req, res) => {
  const n = await db({ uid: req.user.id }, async c => (await c.query('DELETE FROM projects WHERE id=$1', [req.params.id])).rowCount);
  res.status(n ? 200 : 403).json(n ? { ok: true } : { error: 'Faqat loyiha egasi o‘chira oladi' });
}));
app.post('/api/projects/:id/members', auth, pidCheck, wrap(async (req, res) => {
  if (!inviteLimit('inv:' + req.user.id)) return res.status(429).json({ error: 'Biroz kutib qayta urining' });
  const email = S.cleanStr(req.body.email, 254).toLowerCase();
  if (!S.isEmail(email) || !S.isRole(req.body.role)) return bad(res, 'Email yoki rol noto‘g‘ri');
  const out = await db({ uid: req.user.id }, async c => {
    if ((await roleOf(c, req.params.id)) !== 'architect') return 403;
    const uid = (await c.query('SELECT find_user_id($1) AS id', [email])).rows[0].id;
    if (!uid) return 404;
    await c.query('INSERT INTO project_members(project_id,user_id,role) VALUES($1,$2,$3) ON CONFLICT (project_id,user_id) DO UPDATE SET role=EXCLUDED.role', [req.params.id, uid, req.body.role]);
    return 200;
  });
  if (out === 403) return res.status(403).json({ error: 'Faqat arxitektor taklif qila oladi' });
  if (out === 404) return res.status(404).json({ error: 'Bunday foydalanuvchi yo‘q (avval ro‘yxatdan o‘tsin)' });
  res.json({ ok: true });
}));
app.delete('/api/projects/:id/members/:uid', auth, pidCheck, wrap(async (req, res) => {
  const uid = parseInt(req.params.uid, 10); if (!Number.isInteger(uid)) return bad(res, 'Foydalanuvchi noto‘g‘ri');
  const n = await db({ uid: req.user.id }, async c => (await c.query('DELETE FROM project_members WHERE project_id=$1 AND user_id=$2', [req.params.id, uid])).rowCount);
  res.status(n ? 200 : 403).json(n ? { ok: true } : { error: 'Ruxsat yo‘q yoki a’zo topilmadi' });
}));
app.post('/api/projects/:id/reports', auth, pidCheck, wrap(async (req, res) => {
  const text = S.cleanStr(req.body.text, 2000); if (!text) return bad(res, 'Hisobot bo‘sh');
  await db({ uid: req.user.id }, async c => c.query('INSERT INTO reports(project_id,user_id,text) VALUES($1,$2,$3)', [req.params.id, req.user.id, text]));
  broadcast(req.params.id, { type: 'report', from: req.user.name, text });
  res.json({ ok: true });
}));
app.get('/api/projects/:id/reports', auth, pidCheck, wrap(async (req, res) => {
  res.json(await db({ uid: req.user.id }, async c => (await c.query('SELECT txt AS text, created_at, name FROM project_reports($1)', [req.params.id])).rows));
}));

/* ---------- AI HOLATI: kalit hech qachon mijozga berilmaydi ---------- */
app.get('/api/ai/status', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ configured: Boolean(process.env.ANTHROPIC_API_KEY && process.env.ANTHROPIC_API_KEY.trim()),
    provider: 'anthropic' });
});

/* ---------- AI PROXY: kalit va ko'rsatma faqat serverda ---------- */
app.post('/api/ai', auth, wrap(async (req, res) => {
  if (!process.env.ANTHROPIC_API_KEY) return res.status(503).json({ error: 'AI serverda sozlanmagan' });
  if (!aiLimit('ai:' + req.user.id)) return res.status(429).json({ error: 'Juda ko‘p so‘rov, bir daqiqa kuting' });
  const b = S.validAiBody(req.body); if (!b) return bad(res, 'AI so‘rovi noto‘g‘ri');
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), 30000);
  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST', signal: ac.signal,
      headers: { 'Content-Type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6', max_tokens: 1500,
        system: AI_INSTRUCTIONS + b.state, messages: b.messages })
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { console.error('AI xato', r.status, d.error && d.error.type); return res.status(502).json({ error: 'AI vaqtincha ishlamayapti' }); }
    res.json({ text: (d.content || []).map(x => x.text || '').join('') });
  } catch (e) { console.error('AI so‘rov xatosi', e.name); res.status(504).json({ error: 'AI javob bermadi' }); }
  finally { clearTimeout(t); }
}));

/* ---------- NARXLAR (mini-CRM) ---------- */
// Frontend fetchPrices() kutgan format: {"brick":1350,...}
app.get('/api/prices', wrap(async (req, res) => {
  const rows = await db({}, async c => (await c.query('SELECT key,value FROM prices')).rows);
  const o = {}; rows.forEach(x => { o[x.key] = Number(x.value); }); res.json(o);
}));
app.get('/api/prices/detail', auth, wrap(async (req, res) => {
  if (!(await isAdminUser(req.user.id))) return res.status(403).json({ error: 'Faqat admin' });
  res.json(await db({ uid: req.user.id, admin: true }, async c => (await c.query('SELECT key,value,source,updated_at FROM prices ORDER BY key')).rows));
}));
app.put('/api/prices', auth, wrap(async (req, res) => {
  if (!(await isAdminUser(req.user.id))) return res.status(403).json({ error: 'Faqat admin' });
  const entries = Object.entries(req.body || {}).filter(([k, v]) => /^[A-Za-z0-9_]{1,40}$/.test(k) && typeof v === 'number' && isFinite(v) && v >= 0 && v < 1e12);
  if (!entries.length || entries.length > 200) return bad(res, 'Narxlar noto‘g‘ri');
  await db({ uid: req.user.id, admin: true }, async c => {
    for (const [k, v] of entries) await c.query(`INSERT INTO prices(key,value,source) VALUES($1,$2,'admin')
      ON CONFLICT (key) DO UPDATE SET value=EXCLUDED.value,source='admin',updated_at=now()`, [k, v]);
  });
  res.json({ ok: true, updated: entries.length });
}));
app.use('/api', (req, res) => res.status(404).json({ error: 'Topilmadi' }));
// Xato ushlagich: stack trace hech qachon mijozga chiqmaydi
app.use((err, req, res, next) => {   // eslint-disable-line no-unused-vars
  if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'So‘rov juda katta' });
  if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'JSON noto‘g‘ri' });
  console.error(err); res.status(500).json({ error: 'Server xatosi' });
});

/* ---------- WEBSOCKET: real vaqt hamkorlik ---------- */
const server = http.createServer(app);
const wss = new WebSocketServer({
  server, path: '/ws', maxPayload: 2 * 1024 * 1024,
  verifyClient: (info, cb) => cb(S.wsOriginAllowed(info.origin, info.req.headers.host, ORIGINS), 403, 'Origin ruxsat etilmagan')
});
const rooms = new Map();   // projectId -> Set<ws>
function broadcast(pid, msg, except) {
  const s = rooms.get(pid); if (!s) return; const raw = JSON.stringify(msg);
  s.forEach(c => { if (c !== except && c.readyState === 1) c.send(raw); });
}
const peersOf = pid => [...(rooms.get(pid) || [])].map(c => ({ name: c.uname, role: c.role }));
wss.on('connection', ws => {
  ws.authed = false; ws.msgs = []; 
  const authTimer = setTimeout(() => { if (!ws.authed) ws.close(4401, 'Auth vaqti tugadi'); }, 5000);
  ws.on('error', () => {});
  ws.on('message', async raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    const now = Date.now(); ws.msgs = ws.msgs.filter(t => now - t < 1000); if (ws.msgs.length >= 10) return; ws.msgs.push(now);
    try {
      if (!ws.authed) {                                   // TOKEN URL da emas — birinchi xabarda
        if (m.type !== 'auth' || !S.isUuid(m.project)) return ws.close(4400, 'Noto‘g‘ri auth');
        const user = verifyToken(m.token);
        const role = await db({ uid: user.id }, c => roleOf(c, m.project));
        if (!role) return ws.close(4403, 'Ruxsat yo‘q');
        Object.assign(ws, { authed: true, pid: m.project, uid: user.id, role, uname: user.name, roleAt: Date.now() });
        clearTimeout(authTimer);
        if (!rooms.has(ws.pid)) rooms.set(ws.pid, new Set());
        rooms.get(ws.pid).add(ws);
        const presence = { type: 'presence', peers: peersOf(ws.pid) };
        broadcast(ws.pid, presence); ws.send(JSON.stringify(presence));
        return;
      }
      if (Date.now() - ws.roleAt > 30000) {               // rol bekor qilingan bo'lsa — davom ettirmaymiz
        const role = await db({ uid: ws.uid }, c => roleOf(c, ws.pid)); ws.roleAt = Date.now();
        if (!role) return ws.close(4403, 'Ruxsat bekor qilindi');
        if (role !== ws.role) { ws.role = role; ws.send(JSON.stringify({ type: 'role', role })); }
      }
      if (m.type === 'state' && ws.role === 'architect' && S.validProjectData(m.data)) {
        broadcast(ws.pid, { type: 'state', data: m.data, from: ws.uname }, ws);
        clearTimeout(ws.saveT);
        ws.saveT = setTimeout(() => db({ uid: ws.uid }, c => c.query('UPDATE projects SET data=$1,updated_at=now() WHERE id=$2', [m.data, ws.pid])).catch(e => console.error('WS saqlash xatosi', e.code)), 1500);
      }
    } catch (e) { ws.close(4401, 'Token xato'); }
  });
  ws.on('close', () => {
    clearTimeout(authTimer);
    if (!ws.authed) return;
    const s = rooms.get(ws.pid); if (!s) return; s.delete(ws);
    if (!s.size) rooms.delete(ws.pid); else broadcast(ws.pid, { type: 'presence', peers: peersOf(ws.pid) });
  });
});

process.on('unhandledRejection', e => console.error('unhandledRejection', e));
(async () => {
  await assertRlsSafe();
  server.listen(Number(process.env.PORT) || 3000, () => console.log('AI Architect server :' + (process.env.PORT || 3000)));
})().catch(e => { console.error('Ishga tushmadi:', e.message); process.exit(1); });
