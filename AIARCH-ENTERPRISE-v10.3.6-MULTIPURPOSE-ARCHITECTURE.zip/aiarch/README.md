# AI Architect Pro

```
client/    YAGONA frontend manbasi (index.html, config.js, native-sensors.js)
server/    Node + Express + PostgreSQL (RLS) + WebSocket + AI proksi
mobile/    Capacitor (Android/iOS). mobile/www avtomatik yaratiladi — qo'lda tegmang
scripts/   sync-mobile.js, verify.js, client-e2e.py
```
Server `client/` ni to'g'ridan-to'g'ri uzatadi (nusxa yo'q). Mobilga nusxa **har cap buyrug'idan oldin avtomatik** ko'chadi.

## Birlashgan ilova (AI Architect + Bio-Climate v4.0)
`client/suite.html` — ikkala ilovani bitta oynada ochadi (`http://localhost:3000/suite.html`).
- `index.html` = AI Architect Pro, `bio.html` = Bio-Climate & Seismic v4.0; har biri o'z iframe'ida (global nomlar, ID, CSS, Three.js sahnalari to'qnashmaydi).
- Ko'prik `window.Suite` (`syncAIArchitectToV4`): AI Architect'da **3D sahnani qurgan aniq kontur** (`computeFootprint()` → `getSeismicModel()`: devor o'qi poligoni, tashqi yuz poligoni, qavat soni, balandlik) **o'zgarishsiz** v4.0 ga uzatiladi (`ExtPlan.set`). Variant A/B (to'rtburchak), C (L-shakl) va erkin chizilgan kontur (D) — hammasi aniq shaklda; taxminiy box/L/U/T shakli ishlatilmaydi. 3D sahna har qayta qurilganda (`rebuild3dsMaxScene`) kontur avtomatik qayta uzatiladi.
- Zilzila bo'limi shu konturdan oladi: qavat maydoni va massa markazi (analitik), kolonna joylari (burchaklar + har ~4.5 m + ichki to'r), FEM-lite, 3D silkinish modeli, smeta (maydon/perimetr/kolonna soni), DXF va IFC. v4.0 da shu paytda Eni/Bo'yi/Qavat/Balandlik/Shakl maydonlari qulflanadi; «✎ qo'lda tahrirlash» tugmasi qulfni ochadi (kontur o'zgarmaguncha qayta qulflanmaydi).
- AI Architect 3D oynasida «🌋 Zilzila ballida sinash (1–9)» tugmasi: shu 3D loyihani bir bosishda zilzila sinov oynasiga yuboradi (`sendToQuake()` → `Suite.toQuake()`).
- Faol bo'lmagan ilova `display:none` — uning Three.js sikli to'xtaydi.
- **Zilzila sinovi 1–9 ball:** v4.0 → «Seysmika» (jadval) va «3D Poligon» (tugmalar), yoki yuqoridagi «🌋 Zilzila 1–9». AI Architect'dagi bino o'lchamlari avtomatik o'tadi; ball qo'lda tanlanadi (AUTO = hudud balli), kolonna kesimi FEM natijasiga qarab avtomatik kattalashadi, smeta/3D shunga qarab o'zgaradi. «⏩ 1→9 ketma-ket» ballarni birin-ketin sinaydi.
- Sinov: `python3 scripts/suite-e2e.py`, `python3 scripts/quake-e2e.py` va `python3 scripts/exact-e2e.py` (aniq kontur uzatilishi, 23 ta tekshiruv) — Playwright. Bitta fayl: `python3 scripts/build-webapp.py`.

## Ishga tushirish
```bash
cd server && cp .env.example .env
#  .env: JWT_SECRET (>=32 belgi), ANTHROPIC_API_KEY, ALLOWED_ORIGINS (frontend boshqa domenda bo'lsa)
docker compose up -d                   # PostgreSQL + schema.sql (RLS, aiarch_app roli)
npm install && npm start               # http://localhost:3000
psql "$ADMIN_DATABASE_URL" -f seed-prices.sql
npm run make-admin -- sizning@email.uz # admin huquqi faqat shu buyruq bilan (ro'yxatdan o'tishda berilmaydi)
```
Production: `ALTER ROLE aiarch_app PASSWORD '...'`, HTTPS (Nginx/Caddy) ortida, `TRUST_PROXY=1`.

## Mobil (Android telefon)
Node.js 22+, Android Studio, Android SDK va JDK (Android Studio bilan) kerak.
```bash
cd mobile
npm install
npx cap add android                 # faqat birinchi marta
cd ..
npm run sync                        # AIARCH_API bo‘lmasa ham offline demo tayyorlanadi
cd mobile
npm run open:android                # Android Studio'da ochadi
npm run build:android:debug         # sinov APK: android/app/build/outputs/apk/debug/
```
Bulut AI va jamoaviy loyiha uchun avval serverni HTTPS domeniga joylashtiring, so‘ng:
```bash
AIARCH_API=https://api.sizning.uz npm run sync
npm run build:android:debug
```
`AIARCH_API` berilmasa ilova offline rejimda ochiladi; AI chat oddiy buyruqlarni bajaradi. To‘liq AI uchun foydalanuvchi ☁️ Bulut oynasida server manzilini kiritib ro‘yxatdan o‘tadi, server administratori esa `ANTHROPIC_API_KEY` ni faqat server `.env` faylida sozlaydi. Ilova `/api/ai/status` orqali AI tayyorligini tekshiradi; kalit telefonga yuborilmaydi. Release APK uchun `npm run build:android:release` va Android signing keystore sozlamasi talab qilinadi.

## Xavfsizlik (nima qilingan)
1. **API kalit:** brauzerda kalit yo'q (kiritish maydoni ham olib tashlandi). AI faqat `POST /api/ai` orqali; kalit va **AI ko'rsatmasi serverda**, mijoz faqat holat+xabar yuboradi, `system` e'tiborga olinmaydi; foydalanuvchiga 15 so'rov/daqiqa.
2. **CORS:** `ALLOWED_ORIGINS` ro'yxati (`*` rad etiladi), Capacitor origin'lari avtomatik; WebSocket origin tekshiriladi; token URL da emas — birinchi xabarda.
3. **DB izolyatsiyasi:** barcha jadvallarda RLS; ilova `aiarch_app` (superuser emas) bilan ulanadi, har tranzaksiyada `app.user_id` o'rnatiladi; server noto'g'ri rol bilan ishga tushmaydi; ustun darajasidagi huquqlar (`owner_id` o'zgarmaydi); egasining rolini hech kim o'zgartira olmaydi.
4. **Mobil sinxronizatsiya:** `mobile/www` git da yo'q, `npm run sync|open:*|build:*` oldidan avtomatik nusxalanadi.
Qo'shimcha: bcrypt(12), JWT 7 kun (HS256 qat'iy), kirish/ro'yxat tezlik cheklovi, kirish ma'lumotlarini validatsiya, XSS ekranlash, stack trace yashirin.

## AI ulanish holatini tekshirish
- `GET /api/ai/status` faqat `configured: true/false` va provider nomini qaytaradi; maxfiy kalit oshkor qilinmaydi.
- AI chat uchun hisob qaydnomasi kerak: ☁️ Bulut oynasida server manzili, ro‘yxatdan o‘tish/kirish.
- `ANTHROPIC_API_KEY` server `.env` da bo‘lmasa, interfeys endi AI server sozlanmaganini aniq ko‘rsatadi; noto‘g‘ri holatda “AI ulangan” demaydi.
- Kalitni HTML, `config.js`, Android APK yoki chatga kiritmang.

## Tekshiruvlar
```bash
npm run verify            # 40+ statik tekshiruv (kalit, CORS, RLS, id/funksiyalar, mobil)
npm test                  # verify + server testlari (16 ta)
npm run test:e2e          # brauzer testi (29 ta, Playwright)
psql "$ADMIN_DATABASE_URL" -v ON_ERROR_STOP=1 -f server/test/rls.sql   # RLS ni haqiqiy bazada tekshirish
```
## Ma'lum cheklovlar
- JWT `localStorage` da turadi (XSS bo'lsa o'g'irlanishi mumkin); parolni tiklash va email tasdiqlash yo'q; tokenni muddatidan oldin bekor qilish yo'q (7 kun).
- Qat'iy CSP qo'yilmagan (Tailwind CDN va inline skriptlar tufayli).
- IFC elementlari umumiy `IfcBuildingElementProxy` (devor/oyna semantikasi yo'q).

## Pastki panel (Bottom Dock) — 12 modul
`suite.html` pastida 12 tugma: 1 Kadastr · 2 Geolog · 3 AutoCAD 2D · 4 3ds Max 3D · 5 Konstruktor (seysmika) · 6 MEP + kolliziya · 7 Smeta · 8 Ustalar (kafel/g‘isht naryadi) · 9 Texnadzor (SHNQ) · 10 Ta‘minot (texnika, kirim-chiqim) · 11 Prorab (Gantt, hisobot, ombor) · 12 Ensiklopediya. Qo‘shimcha: «🤖 Agent» — matndan 7 ichki mutaxassisni ketma-ket ishlatadi. Har bosishda `Suite.dock(id)` viewport'ni almashtiradi; MEP/Prorab ma'lumotlari umumiy holatga (`Suite.state()`, localStorage) yoziladi va boshqa oynalarga BroadcastChannel orqali uzatiladi (server bilan jonli sinxron — index.html dagi WebSocket, backend kerak). Sinov: `python3 scripts/dock-e2e.py`.

## v7 — Central BIM Core integratsiyasi
- `client/bim-core.js` — deterministik ID va versiya bilan yagona konseptual BIM modelini yaratadi.
- O‘lchamlar yoki smeta narxlari yangilanganda model qayta yig‘iladi; 2D/3D/seysmik ko‘prikdagi mavjud aniq bino konturi asos qilib olinadi.
- Model localStorage, BroadcastChannel va Suite parent-frame hodisasi orqali tarqatiladi; loyiha JSON eksportiga BIM snapshot qo‘shiladi.
- `npm test` ichiga 9 ta yangi BIM Core tekshiruvi qo‘shildi.
- To‘liq chegaralar va hali bajarilmagan ishlar: `docs/BIM_CORE.md`.


## Yakuniy qayta sinov (2026-11-01)
- `npm test` — barcha unit/static/backend testlar o‘tdi (verify ichida faqat `mobile/www` hali build qilinmagani haqida ogohlantirish bor).
- Alohida brauzer E2E to‘plamlari: 29 + 27 + 33 + 27 + 20 + 14 + 24 = **174/174**.
- `AIARCH-ENTERPRISE-SUITE.html` — `scripts/build-webapp.py` orqali qayta yig‘ilgan yagona HTML to‘plam.
- Bu sinovlar real Android qurilma, ishlab turgan PostgreSQL, tashqi AI kaliti, jonli narx manbalari yoki muhandislik sertifikatini tasdiqlamaydi.

## v10 — Autodesk / BIM / OpenSees interoperability foundation
- `integrations/` da yagona almashinuv JSON shartnomasi, AutoCAD uchun tahrirlanadigan DXF eksporti, 3ds Max uchun `pymxs` importer va OpenSeesPy 3D transient time-history adapteri qo'shildi.
- FEM adapteri real accelerogramma (s, m/s²) va muhandis kiritgan 3D karkas (tugun, massa, tayanch, material/section stiffness) talab qiladi; ma'lumot yetishmasa hisobni rad etadi.
- `npm run test:interop` DXF, birliklar, FEM input validatsiyasi va accelerogramma parserini tekshiradi.
- Muhim: AutoCAD/3ds Max/Revit runtime, DWG native, Revit `.rvt`, hamda BIM mesh ↔ FEM mesh vizual bog'lanishi bu paketda hali yakunlanmagan. `integrations/README-INTEROP-UZ.md` dagi cheklovlarni ko'ring.

### v10.1 AutoCAD QA / seismic review
- AutoCAD helper: `integrations/autocad/AIARCH_QA_CLEAN.lsp` (`AIARCHQA`, `AIARCHLAYERS`, `AIARCHCLEAN`, `AIARCHJOIN`). See `integrations/autocad/AUTOCAD-QA-GUIDE-UZ.md`.
- Structural review checklist: `integrations/seismic/STRUCTURAL_REVIEW_TEMPLATE_UZ.md`.
- AutoLISP is statically checked only; it still requires a real AutoCAD runtime test on a copy of a DWG. Structural sizes are not guessed or auto-assigned.

## v10.3.4 validation and build commands

```bash
npm run sync                 # regenerate mobile/www from client/
npm test                     # core/security/BIM/interop tests
npm run test:dock             # dock browser E2E
npm run test:e2e              # client browser E2E
npm run test:exact            # geometry/DXF/IFC E2E
npm run test:modules          # modules E2E
npm run test:geo-cad          # geo/CAD E2E
npm run test:quake            # seismic UI E2E
npm run test:suite            # cross-app bridge E2E
npm run test:opensees-real    # strict real OpenSeesPy solver smoke test
npm run build:android-release # requires mobile dependencies, Android SDK and Gradle
```

A GitHub Actions workflow at `.github/workflows/ci.yml` runs the web/E2E checks, installs
OpenSeesPy for a real transient solve, and builds an unsigned Android release APK. The APK
is published as a workflow artifact after the workflow succeeds. Autodesk desktop runtime
QA remains a manual test on licensed Windows installations; see `integrations/README-INTEROP-UZ.md`.
