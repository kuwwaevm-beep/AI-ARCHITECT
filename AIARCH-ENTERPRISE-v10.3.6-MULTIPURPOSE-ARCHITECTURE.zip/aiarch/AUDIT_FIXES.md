# AIARCH — tuzatishlar va qolgan tekshiruvlar

Sana: 2026-10-27

## Ushbu versiyada bajarilgan tuzatish

- `client/bio.html`: `autoColumn()` endi barcha sinovdan o'tgan ustun kesimlari 0.9 mezonidan o'tmasa, eng katta kesimni muvaffaqiyatli deb qaytarmaydi. `null` qaytaradi.
- `quakeSweep()` endi topilmagan kesim uchun soxta hisob natijasini yaratmaydi.
- Jadvalda `TOPILMADI` va `MUHANDIS TEKSHIRUVI KERAK` ko'rsatiladi. Bu natija konstruktiv xavfsizlik sertifikati emas.

- `client/index.html`: AI takliflari qo‘llanishidan oldin maydon nomlari, raqamlar, diapazonlar, enum qiymatlar, qo‘shimcha parametrlar va poligon koordinatalari tekshiriladi. Noto‘g‘ri qiymat bo‘lsa, o‘zgarishlar qo‘llanmaydi; uchastka o‘lchami faqat ruxsat etilgan chegaralarda avtomatik moslashtiriladi.

## Cheklovlar

Bu o'zgarishlar faqat noto'g'ri ijobiy xulosani kamaytiradi. `seisCore()` soddalashtirilgan skrining modeli bo'lib qoladi; O'zbekiston me'yorlariga muvofiqlik, FEM tahlili yoki bino zilzilaga chidamliligi isbotlanmaydi. Haqiqiy loyiha bo'yicha malakali konstruktor muhandis tekshiruvi zarur.

AI javoblarini loyiha modeliga avtomatik qo'llashdan oldin schema, geometriya va muhandislik qoidalari bo'yicha validatsiya, o'zgarishlarni oldindan ko'rish, foydalanuvchi tasdig'i va bekor qilish mexanizmi hali alohida bajarilishi kerak. Narxlar API mavjudligi jonli bozor narxlarini kafolatlamaydi; narx manbasi, hudud, valyuta, birlik va yangilangan sana mustaqil tekshirilishi lozim.

## Tekshiruv

`npm test` orqali mavjud statik tekshiruv va backend testlari qayta ishga tushirilishi kerak. Playwright/Chromium hamda haqiqiy PostgreSQL muhiti bo'lmasa, brauzer E2E va RLS integratsion sinovlari tasdiqlangan deb hisoblanmaydi.

## Qo‘shimcha bosqich — loyiha fayllarini xavfsiz yuklash

- `applyProject()` endi JSON importi, ulashish havolasi va `localStorage` dan kelgan ma’lumotni o‘zgartirishdan oldin `validateProjectData()` orqali tekshiradi.
- O‘lchamlar, qavatlar, xona/eshik/deraza sonlari va boshqa sonli parametrlar ruxsat etilgan diapazonda bo‘lishi kerak.
- Noma’lum maydonlar, noto‘g‘ri variantlar, noto‘g‘ri material narxlari, yaroqsiz yoki o‘zini kesib o‘tuvchi poligonlar rad etiladi.
- Tekshiruvdan o‘tmagan butun loyiha hech qanday qisman o‘zgarish kiritmasdan rad etiladi.
- `scripts/project-validation.test.js` qo‘shildi: 7 ta regressiya tekshiruvi muvaffaqiyatli.
- E2E skriptlar Chromium yo‘lini `AIARCH_CHROMIUM_PATH` orqali sozlashni qo‘llaydi; bu brauzer yo‘li muhitga qarab farq qiladigan tizimlarda foydali.

## Ushbu bosqich sinovlari

- `npm test`: statik tekshiruvlar, loyiha-validatsiyasi (7/7) va backend xavfsizlik testlari (6/6) o‘tdi.
- Brauzer E2E sinovlari hali to‘liq yakunlanmadi: ushbu muhitdagi `https://app.test` navigatsiyasi brauzer siyosati bilan bloklandi. Shu sababli 2D/3D render natijasi real brauzerda tasdiqlangan deb ko‘rsatilmaydi.

## 2D/3D viewport pass (2026-10-27)
- 2D canvas now keeps its 900:520 drawing ratio while scaling to the available screen width; its backing resolution is capped at 2x device pixel ratio to reduce mobile memory use.
- 2D wall thickness labels and line weights now reflect all four supported wall types (250/300/380/400 mm) instead of treating most wall types as 300 mm.
- 3D viewport resize ignores hidden/zero-sized panels to avoid invalid camera aspect ratios.
- 3D camera presets now fit the generated scene bounds rather than using fixed coordinates, and can zoom farther out for larger lots.
- Rebuilding the 3D scene disposes replaced mesh geometries and materials to reduce GPU memory growth.
- Added `npm run test:viewport` regression checks. These are static checks; real WebGL/browser rendering remains to be confirmed in a normal browser because the current sandbox blocks browser navigation.

## 2026-10-27 — 2D/3D umumiy kontur va DXF himoyasi (v5)
- `renderAutoCAD2D()` endi 3D/seysmik modul bilan umumiy `computeFootprint()` geometriyasidan foydalanadi: xona chizmalari bino konturi ichida clip qilinadi va tashqi kontur shu geometriyadan chiziladi.
- DXF eksporti oldidan bino konturi, qavatlar va o‘lchamlar tekshiriladi; noto‘g‘ri yoki nol uzunlikdagi tashqi qirralarda eksport bekor qilinadi.
- DXF ichidagi devor segmenti koordinatalari tekshiriladi; nol uzunlikdagi segment bo‘lsa, nolga bo‘lishning oldini olish uchun tashlab ketiladi.
- `scripts/shared-model-regression.test.js` qo‘shildi.
- Tekshiruv: `npm test` — verify muvaffaqiyatli (mobile/www bo‘yicha oldindan mavjud ogohlantirish), loyiha validatsiyasi 7/7, viewport 7/7, shared-model 7/7, backend xavfsizlik testlari 6/6.
- Cheklov: brauzerda vizual E2E va haqiqiy CAD dasturida DXF ochish bu muhitda bajarilmadi; bu patch professional BIM yoki konstruktiv muvofiqlik sertifikati emas.
