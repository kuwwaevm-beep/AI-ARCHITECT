# AIARCH Enterprise v10.3.4 — Validation and build-readiness report

Date: 2026-11-01  
Base: AIARCH Enterprise v10.3.3 validation package

## Changes in v10.3.4

- Hardened OpenSeesPy input validation: validates 3D coordinates, fixity shape, positive finite section/material properties, non-zero member lengths, local `vecxz` orientation, unique IDs, and connectivity to a fully fixed support.
- Hardened transient analysis execution: validates every returned six-DOF displacement vector, rejects non-finite solver output, and always wipes the OpenSees model after the run.
- Corrected the sample 3D frame coordinate convention: vertical is OpenSees Y, while the AIARCH plan uses X/Z; local axes in the example now match member directions.
- Added a strict real-engine smoke test (`scripts/opensees-smoke.py`). It fails if OpenSeesPy is missing; it does not silently substitute the mock engine.
- Added GitHub Actions CI jobs for core/E2E checks, real OpenSeesPy transient analysis, and unsigned Android release APK build.
- Added package scripts for real solver smoke test and Android release build.

## Tests run in this environment

- `npm test`: PASS.
- Dock E2E: 33/33 PASS.
- Client E2E: 29/29 PASS.
- Exact geometry E2E: 27/27 PASS.
- Module E2E: 27/27 PASS.
- Geo/CAD E2E: 24/24 PASS.
- Seismic UI E2E: 20/20 PASS.
- Suite bridge E2E: 14/14 PASS.
- Python compile checks: PASS.
- OpenSees adapter mock contract and model-validation tests: PASS.
- Mobile web assets generated and synchronized; core verifier reports no warnings.

## External checks still blocked in this environment

1. **Real OpenSeesPy solver:** not run here. The package index returned no available distribution in this network-restricted environment. The new strict smoke test and CI job will run a real 3D transient solve on a network-enabled runner. The mock contract test is not represented as a real solve.
2. **Android APK:** not built here. Capacitor CLI, Gradle, Android SDK and Android project dependencies are not installed, and package installation is blocked. The new CI job installs these dependencies, generates the Android project, builds an unsigned release APK, and uploads it as an artifact when the workflow runs on GitHub Actions.
3. **Autodesk native runtimes:** AutoCAD, Revit and 3ds Max are proprietary desktop applications and are not installed in this environment. Static/export checks pass, but in-application import and runtime tests remain manual. Revit integration is IFC exchange, not native `.rvt` authoring.
4. **Full automatic BIM/FEM coupling:** explicit mapped `MeshSurface` triangle vertices and `WallSegment` anchors can be deformed. Automatic conversion/mapping of every architectural object into a structural FEM mesh is not implemented and requires engineering rules/model authoring.

## Release status

This is a stronger validated development package with CI build automation. It is **not yet a fully verified native/engineering release** until the real OpenSeesPy job, Android APK workflow, and Autodesk desktop QA have produced successful results. Structural outputs remain engineering-review data and are not a substitute for a licensed structural engineer's design approval.
